import { DatabaseSync } from 'node:sqlite';
import crypto from 'node:crypto';
import path from 'node:path';
import fs from 'node:fs';

const DB_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

const DB_PATH = path.join(DB_DIR, 'mediskin.db');

export class ServerDatabase {
  public db: DatabaseSync;

  constructor() {
    this.db = new DatabaseSync(DB_PATH);
    this.initTables();
    this.seedReferenceData();
  }

  private initTables() {
    this.db.exec(`
      PRAGMA foreign_keys = ON;

      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        password_salt TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'patient',
        phone TEXT,
        avatar_url TEXT,
        is_email_verified INTEGER NOT NULL DEFAULT 0,
        verification_code TEXT,
        reset_code TEXT,
        reset_expires_at INTEGER,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS sessions (
        token TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        expires_at INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS doctors (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        name TEXT NOT NULL,
        title TEXT NOT NULL,
        specialty TEXT NOT NULL,
        sub_specialties TEXT, -- JSON array
        license_number TEXT NOT NULL,
        experience_years INTEGER NOT NULL,
        hospital_affiliation TEXT NOT NULL,
        clinic_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state TEXT NOT NULL,
        consultation_fee REAL NOT NULL,
        rating REAL NOT NULL DEFAULT 5.0,
        review_count INTEGER NOT NULL DEFAULT 0,
        modes TEXT NOT NULL, -- JSON array
        verification_status TEXT NOT NULL DEFAULT 'Verified',
        available_days TEXT NOT NULL, -- JSON array [1,2,3,4,5]
        time_slots TEXT NOT NULL, -- JSON array
        bio TEXT NOT NULL,
        education TEXT NOT NULL,
        avatar_url TEXT,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS hospitals (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        facility_type TEXT NOT NULL,
        address TEXT NOT NULL,
        city TEXT NOT NULL,
        state TEXT NOT NULL,
        phone TEXT NOT NULL,
        emergency_care INTEGER NOT NULL DEFAULT 1,
        dermatology_department INTEGER NOT NULL DEFAULT 1,
        rating REAL NOT NULL DEFAULT 4.8,
        lat REAL NOT NULL DEFAULT 37.7749,
        lng REAL NOT NULL DEFAULT -122.4194,
        operating_hours TEXT NOT NULL,
        accepted_insurances TEXT, -- JSON array
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS appointments (
        id TEXT PRIMARY KEY,
        reference_code TEXT UNIQUE NOT NULL,
        patient_id TEXT NOT NULL,
        patient_name TEXT NOT NULL,
        patient_email TEXT NOT NULL,
        patient_phone TEXT,
        doctor_id TEXT NOT NULL,
        doctor_name TEXT NOT NULL,
        specialty TEXT NOT NULL,
        date TEXT NOT NULL,
        time_slot TEXT NOT NULL,
        mode TEXT NOT NULL,
        reason TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'Pending',
        triage_priority TEXT NOT NULL DEFAULT 'Routine',
        consultation_fee REAL NOT NULL DEFAULT 150,
        screening_id TEXT,
        doctor_notes TEXT,
        cancellation_reason TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (patient_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS screenings (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        image_url TEXT,
        quality_score REAL NOT NULL,
        condition_id TEXT NOT NULL,
        condition_name TEXT NOT NULL,
        category TEXT NOT NULL,
        confidence REAL NOT NULL,
        urgency TEXT NOT NULL,
        uncertainty_flag INTEGER NOT NULL DEFAULT 0,
        uncertainty_message TEXT,
        features_json TEXT,
        abcde_json TEXT,
        report_json TEXT NOT NULL,
        doctor_notes TEXT,
        timestamp TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS feedbacks (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        user_name TEXT NOT NULL,
        user_email TEXT NOT NULL,
        rating INTEGER NOT NULL,
        category TEXT NOT NULL,
        message TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS audit_logs (
        id TEXT PRIMARY KEY,
        timestamp TEXT NOT NULL,
        actor_id TEXT,
        actor_email TEXT NOT NULL,
        actor_role TEXT NOT NULL,
        action TEXT NOT NULL,
        details TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS rate_limits (
        identifier TEXT PRIMARY KEY,
        failed_attempts INTEGER NOT NULL DEFAULT 0,
        last_attempt_at INTEGER NOT NULL,
        locked_until INTEGER NOT NULL DEFAULT 0
      );
    `);
  }

  private seedReferenceData() {
    // Ensure default guest profile exists for guest screenings and bookings
    this.db.prepare(`
      INSERT OR IGNORE INTO users (id, name, email, password_hash, password_salt, role, is_email_verified, created_at)
      VALUES ('guest', 'Guest Patient', 'guest@mediskin.health', 'none', 'none', 'patient', 0, ?)
    `).run(new Date().toISOString());

    // Seed test accounts with scrypt hashes if not existing
    const seedAccounts = [
      {
        id: 'patient-demo-1',
        name: 'Sarah Connor',
        email: 'patient@mediskin.health',
        password: 'PatientSecure123!',
        role: 'patient',
        phone: '+1 (415) 555-0199',
        avatar_url: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
      },
      {
        id: 'doc-1',
        name: 'Dr. Sarah Lin',
        email: 'dr.lin@mediskin.health',
        password: 'DoctorSecure123!',
        role: 'doctor',
        phone: '+1 (415) 555-0188',
        avatar_url: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=200',
      },
      {
        id: 'admin-1',
        name: 'Dr. Jonathan Hall',
        email: 'admin@mediskin.health',
        password: 'AdminSecure123!',
        role: 'admin',
        phone: '+1 (800) 555-9000',
        avatar_url: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200',
      },
    ];

    for (const acc of seedAccounts) {
      const { salt, hash } = this.hashPassword(acc.password);
      this.db.prepare(`
        INSERT INTO users (id, name, email, password_hash, password_salt, role, phone, avatar_url, is_email_verified, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)
        ON CONFLICT(email) DO UPDATE SET
          password_hash = excluded.password_hash,
          password_salt = excluded.password_salt,
          role = excluded.role,
          name = excluded.name,
          is_email_verified = 1
      `).run(acc.id, acc.name, acc.email, hash, salt, acc.role, acc.phone, acc.avatar_url, new Date().toISOString());
    }

    // Check if doctors are populated
    const docCount = (this.db.prepare('SELECT COUNT(*) as count FROM doctors').get() as { count: number }).count;
    if (docCount === 0) {
      const doctorsSeed = [
        {
          id: 'doc-1',
          name: 'Dr. Sarah Lin',
          title: 'MD, FAAD',
          specialty: 'Dermatology & Dermato-Oncology',
          sub_specialties: JSON.stringify(['Melanoma Screening', 'Mohs Micrographic Surgery', 'Dermoscopy']),
          license_number: 'MD-CA-889124',
          experience_years: 14,
          hospital_affiliation: 'Stanford Skin Cancer Center',
          clinic_address: '450 Broadway St, Suite 320',
          city: 'San Francisco',
          state: 'CA',
          consultation_fee: 160,
          rating: 4.9,
          review_count: 128,
          modes: JSON.stringify(['In-Person', 'Video Call']),
          verification_status: 'Verified',
          available_days: JSON.stringify([1, 2, 3, 4, 5]),
          time_slots: JSON.stringify(['09:00 AM', '10:00 AM', '11:30 AM', '02:00 PM', '03:30 PM', '04:30 PM']),
          bio: 'Board-certified dermatologist specializing in early detection of melanoma, pigmentary disorders, and high-resolution dermoscopic evaluation.',
          education: 'Harvard Medical School (MD), Stanford Hospital (Residency & Fellowship)',
          avatar_url: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=300',
          created_at: new Date().toISOString(),
        },
        {
          id: 'doc-2',
          name: 'Dr. Marcus Vance',
          title: 'MD, PhD',
          specialty: 'Clinical Dermatology & Cutaneous Surgery',
          sub_specialties: JSON.stringify(['Basal Cell Carcinoma', 'Squamous Cell Carcinoma', 'Cryosurgery']),
          license_number: 'MD-CA-771249',
          experience_years: 18,
          hospital_affiliation: 'Bay Area Skin Health Pavilion',
          clinic_address: '1200 Market Street, 4th Floor',
          city: 'San Francisco',
          state: 'CA',
          consultation_fee: 180,
          rating: 4.8,
          review_count: 94,
          modes: JSON.stringify(['In-Person', 'Video Call', 'Audio Consultation']),
          verification_status: 'Verified',
          available_days: JSON.stringify([2, 3, 4, 6]),
          time_slots: JSON.stringify(['08:30 AM', '09:30 AM', '11:00 AM', '01:30 PM', '03:00 PM']),
          bio: 'Specialist in non-melanoma skin cancers, advanced diagnostic biopsies, and photodynamic therapy with extensive published clinical trials.',
          education: 'Johns Hopkins School of Medicine (MD/PhD), UCSF Dermatology Residency',
          avatar_url: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=300',
          created_at: new Date().toISOString(),
        },
        {
          id: 'doc-3',
          name: 'Dr. Elena Rostova',
          title: 'MD, FAAD',
          specialty: 'Pediatric & General Dermatology',
          sub_specialties: JSON.stringify(['Atopic Dermatitis (Eczema)', 'Psoriasis', 'Benign Neoplasms']),
          license_number: 'MD-NY-655201',
          experience_years: 11,
          hospital_affiliation: 'Metro Dermatology & Laser Institute',
          clinic_address: '88 Bush Street, Suite 100',
          city: 'San Francisco',
          state: 'CA',
          consultation_fee: 150,
          rating: 4.9,
          review_count: 112,
          modes: JSON.stringify(['In-Person', 'Video Call']),
          verification_status: 'Verified',
          available_days: JSON.stringify([1, 2, 4, 5]),
          time_slots: JSON.stringify(['09:00 AM', '10:30 AM', '01:00 PM', '02:30 PM', '04:00 PM']),
          bio: 'Focused on pediatric skin manifestations, genetic dermatoses, eczema flare prevention, and gentle cryotherapeutic interventions.',
          education: 'Columbia University Vagelos College of Physicians and Surgeons',
          avatar_url: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?auto=format&fit=crop&q=80&w=300',
          created_at: new Date().toISOString(),
        },
      ];

      const stmt = this.db.prepare(`
        INSERT INTO doctors (
          id, name, title, specialty, sub_specialties, license_number, experience_years,
          hospital_affiliation, clinic_address, city, state, consultation_fee, rating,
          review_count, modes, verification_status, available_days, time_slots, bio, education, avatar_url, created_at
        ) VALUES (
          ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        )
      `);

      for (const d of doctorsSeed) {
        stmt.run(
          d.id, d.name, d.title, d.specialty, d.sub_specialties, d.license_number, d.experience_years,
          d.hospital_affiliation, d.clinic_address, d.city, d.state, d.consultation_fee, d.rating,
          d.review_count, d.modes, d.verification_status, d.available_days, d.time_slots, d.bio, d.education, d.avatar_url, d.created_at
        );
      }
    }

    // Check if hospitals are populated
    const hospCount = (this.db.prepare('SELECT COUNT(*) as count FROM hospitals').get() as { count: number }).count;
    if (hospCount === 0) {
      const hospitalsSeed = [
        {
          id: 'hosp-1',
          name: 'Stanford Hospital & Clinics - Skin Oncology Center',
          facility_type: 'Academic Medical Center',
          address: '300 Pasteur Dr, Pavilion H',
          city: 'Stanford',
          state: 'CA',
          phone: '(650) 723-4000',
          emergency_care: 1,
          dermatology_department: 1,
          rating: 4.9,
          lat: 37.4344,
          lng: -122.1753,
          operating_hours: '24/7 Emergency; Dermatology Clinics: Mon-Fri 8am-5pm',
          accepted_insurances: JSON.stringify(['Blue Shield', 'Aetna', 'Medicare', 'UnitedHealthcare', 'Cigna']),
          created_at: new Date().toISOString(),
        },
        {
          id: 'hosp-2',
          name: 'UCSF Medical Center at Mission Bay - Dermatology Pavilion',
          facility_type: 'Tertiary Care Hospital',
          address: '1825 4th St, 5th Floor',
          city: 'San Francisco',
          state: 'CA',
          phone: '(415) 353-7800',
          emergency_care: 1,
          dermatology_department: 1,
          rating: 4.9,
          lat: 37.7681,
          lng: -122.3912,
          operating_hours: '24/7 Acute Care; Outpatient: Mon-Fri 8am-5:30pm',
          accepted_insurances: JSON.stringify(['Blue Cross', 'Kaiser Permanente Referral', 'Medicare', 'Anthem']),
          created_at: new Date().toISOString(),
        },
        {
          id: 'hosp-3',
          name: 'California Pacific Medical Center (CPMC) - Van Ness Campus',
          facility_type: 'Comprehensive Community Hospital',
          address: '1101 Van Ness Ave',
          city: 'San Francisco',
          state: 'CA',
          phone: '(415) 600-6000',
          emergency_care: 1,
          dermatology_department: 1,
          rating: 4.7,
          lat: 37.7865,
          lng: -122.4215,
          operating_hours: '24/7 Emergency Services; Dermatology Wing: Mon-Fri 8:30am-5pm',
          accepted_insurances: JSON.stringify(['Aetna', 'Cigna', 'Blue Shield', 'Humana']),
          created_at: new Date().toISOString(),
        },
      ];

      const stmt = this.db.prepare(`
        INSERT INTO hospitals (
          id, name, facility_type, address, city, state, phone, emergency_care,
          dermatology_department, rating, lat, lng, operating_hours, accepted_insurances, created_at
        ) VALUES (
          ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        )
      `);

      for (const h of hospitalsSeed) {
        stmt.run(
          h.id, h.name, h.facility_type, h.address, h.city, h.state, h.phone,
          h.emergency_care, h.dermatology_department, h.rating, h.lat, h.lng,
          h.operating_hours, h.accepted_insurances, h.created_at
        );
      }
    }
  }

  // --- Password Hashing with Salt (scrypt) ---
  public hashPassword(password: string): { salt: string; hash: string } {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync(password, salt, 64).toString('hex');
    return { salt, hash };
  }

  public verifyPassword(password: string, salt: string, storedHash: string): boolean {
    const hash = crypto.scryptSync(password, salt, 64).toString('hex');
    return crypto.timingSafeEqual(Buffer.from(hash, 'hex'), Buffer.from(storedHash, 'hex'));
  }
}

export const serverDb = new ServerDatabase();
