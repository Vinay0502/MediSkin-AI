import test from 'node:test';
import assert from 'node:assert/strict';
import { ServerDatabase } from './db.ts';

test('ServerDatabase initializes tables and reference doctors', () => {
  const serverDb = new ServerDatabase();
  const doctors = serverDb.db.prepare('SELECT COUNT(*) as count FROM doctors').get() as { count: number };
  assert.ok(doctors.count >= 3, 'Should seed at least 3 accredited doctors');

  const hospitals = serverDb.db.prepare('SELECT COUNT(*) as count FROM hospitals').get() as { count: number };
  assert.ok(hospitals.count >= 3, 'Should seed at least 3 clinical facilities');
});

test('Password hashing with scrypt generates salt and validates correctly', () => {
  const serverDb = new ServerDatabase();
  const rawPass = 'SecretDermMed#2026';
  const { salt, hash } = serverDb.hashPassword(rawPass);

  assert.ok(salt.length > 10, 'Salt should be non-empty hex');
  assert.ok(hash.length > 20, 'Hash should be scrypt hex');

  const valid = serverDb.verifyPassword(rawPass, salt, hash);
  assert.equal(valid, true, 'Original password should verify');

  const invalid = serverDb.verifyPassword('WrongPassword123', salt, hash);
  assert.equal(invalid, false, 'Wrong password should fail verification');
});

test('Rate limiting table prevents brute-force attempts', () => {
  const serverDb = new ServerDatabase();
  const testId = `test-ip-${Date.now()}`;
  serverDb.db.prepare(`
    INSERT INTO rate_limits (identifier, failed_attempts, last_attempt_at, locked_until)
    VALUES (?, 5, ?, ?)
  `).run(testId, Date.now(), Date.now() + 60000);

  const row = serverDb.db.prepare('SELECT * FROM rate_limits WHERE identifier = ?').get(testId) as any;
  assert.equal(row.failed_attempts, 5);
  assert.ok(row.locked_until > Date.now(), 'Account should be locked for 60 seconds');
});
