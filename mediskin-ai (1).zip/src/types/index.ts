export type UserRole = 'patient' | 'doctor' | 'admin';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  phone?: string;
  avatarUrl?: string;
  medicalHistoryConsent?: boolean;
  isEmailVerified: boolean;
  emailVerificationCode?: string;
  createdAt: string;
  passwordHash?: string;
  failedLoginAttempts?: number;
  lockoutUntil?: number; // epoch ms
}

export type DoctorVerificationStatus = 'Verified' | 'Pending Review' | 'Needs More Info' | 'Rejected';

export interface DoctorProfile {
  id: string;
  name: string;
  title: string;
  specialty: string;
  subSpecialties: string[];
  licenseNumber: string;
  experienceYears: number;
  hospitalAffiliation: string;
  clinicAddress: string;
  city: string;
  state: string;
  consultationFee: number;
  rating: number;
  reviewCount: number;
  modes: ('In-Person' | 'Video Call' | 'Audio Consultation')[];
  verificationStatus: DoctorVerificationStatus;
  availableDays: number[];
  timeSlots: string[];
  bio: string;
  education: string;
  avatarUrl: string;
}

export interface HospitalFacility {
  id: string;
  name: string;
  facilityType: 'Specialized Dermatology Center' | 'General Hospital' | 'Skin Cancer Institute' | 'Urgent Care';
  address: string;
  city: string;
  state: string;
  phone: string;
  emergencyCare: boolean;
  dermatologyDepartment: boolean;
  rating: number;
  lat: number;
  lng: number;
  operatingHours: string;
  acceptedInsurances: string[];
}

export interface SkinConditionDetail {
  id: string;
  code: string;
  name: string;
  medicalName: string;
  category: 'Benign' | 'Pre-Malignant' | 'Malignant' | 'Inflammatory';
  summary: string;
  commonSigns: string[];
  riskFactors: string[];
  dermoscopicFeatures: string[];
  urgencyRecommendation: string;
  sources: { title: string; url: string }[];
  lastReviewed: string;
}

export interface ScreeningHistoryItem {
  id: string;
  timestamp: string;
  patientId: string;
  imageUrl?: string;
  conditionId: string;
  conditionName: string;
  category: string;
  confidence: number;
  urgency: 'low' | 'moderate' | 'high' | 'urgent';
  uncertaintyFlag: boolean;
  notes?: string;
}

export interface SystemNotification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'appointment' | 'verification' | 'system' | 'safety' | 'auth';
  timestamp: string;
  isRead: boolean;
  actionUrl?: string;
}

export interface UserFeedback {
  id: string;
  userId: string;
  userName: string;
  rating: number;
  category: 'Screening Accuracy' | 'Booking Experience' | 'UI / Navigation' | 'General';
  comments: string;
  createdAt: string;
}

export interface AuditLogEntry {
  id: string;
  actorEmail: string;
  actorRole: UserRole;
  action: string;
  details: string;
  timestamp: string;
  ipAddress?: string;
}

export interface AnalyticsEvent {
  id: string;
  type: 'page_view' | 'screening_start' | 'screening_complete' | 'booking_submitted' | 'auth_login' | 'auth_register' | 'error';
  userId?: string;
  metadata?: Record<string, any>;
  timestamp: string;
}

export interface ErrorTelemetryRecord {
  id: string;
  message: string;
  stack?: string;
  componentStack?: string;
  route: string;
  timestamp: string;
}

export interface DatabaseBackup {
  version: string;
  exportedAt: string;
  appId: string;
  checksum: string;
  users: UserProfile[];
  doctors: DoctorProfile[];
  hospitals: HospitalFacility[];
  appointments: any[];
  screenings: ScreeningHistoryItem[];
  feedbacks: UserFeedback[];
  auditLogs: AuditLogEntry[];
}
