import { jsPDF } from 'jspdf';
import { CompleteScreeningReport } from './aiVisionEngine.ts';

export interface PatientInfoForReport {
  name: string;
  email: string;
  id?: string;
}

export interface PdfExportOptions {
  includeHeatmap?: boolean;
  notes?: string;
}

/**
 * Generates an auditable, professional Medical Screening PDF Report for MediSkin AI
 */
export function buildMedicalScreeningPdf(
  report: CompleteScreeningReport,
  rawImageUrl: string,
  patient: PatientInfoForReport,
  options: PdfExportOptions = { includeHeatmap: true }
): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth(); // 210mm
  const margin = 16;
  let currentY = 16;

  const { screeningResult, qualityReport, features, abcdeAnalysis } = report;
  const primary = screeningResult.primaryCondition;
  const reportRef = `MSK-${Date.now().toString().slice(-6)}`;
  const dateFormatted = new Date(report.timestamp).toLocaleString();

  // 1. BRAND HEADER BAR (Teal Accent)
  doc.setFillColor(13, 148, 136); // #0d9488
  doc.rect(0, 0, pageWidth, 8, 'F');

  // Header Title & Logo Box
  doc.setFillColor(240, 253, 250); // #f0fdfa
  doc.roundedRect(margin, currentY, pageWidth - margin * 2, 22, 3, 3, 'F');
  doc.setDrawColor(204, 251, 241);
  doc.roundedRect(margin, currentY, pageWidth - margin * 2, 22, 3, 3, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(15, 23, 42); // #0f172a
  doc.text('MediSkin AI', margin + 6, currentY + 9);

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(13, 148, 136);
  doc.text('CLINICAL PRELIMINARY SCREENING REPORT', margin + 6, currentY + 16);

  // Document Reference Details on Right
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  doc.text(`Report Ref: ${reportRef}`, pageWidth - margin - 6, currentY + 8, { align: 'right' });
  doc.text(`Generated: ${dateFormatted}`, pageWidth - margin - 6, currentY + 13, { align: 'right' });
  doc.text('Model: HAM10000 Ensemble v2.6', pageWidth - margin - 6, currentY + 18, { align: 'right' });

  currentY += 28;

  // 2. PATIENT DEMOGRAPHICS & CLINICAL METADATA
  doc.setFillColor(248, 250, 252); // #f8fafc
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(margin, currentY, pageWidth - margin * 2, 18, 2, 2, 'FD');

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(100, 116, 139);
  doc.text('PATIENT NAME', margin + 6, currentY + 6);
  doc.text('EMAIL ADDRESS', margin + 70, currentY + 6);
  doc.text('RECORD STATUS', margin + 135, currentY + 6);

  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text(patient.name || 'Anonymous Patient', margin + 6, currentY + 13);
  doc.text(patient.email || 'patient@mediskin.health', margin + 70, currentY + 13);
  doc.setTextColor(13, 148, 136);
  doc.text('Screening Complete • Awaiting MD Review', margin + 135, currentY + 13);

  currentY += 24;

  // 3. PRIMARY CLASSIFICATION & URGENCY BOX
  const isUrgent = screeningResult.clinicalUrgency === 'urgent' || primary?.category === 'Malignant';
  const boxFill = isUrgent ? [254, 242, 242] : [240, 253, 250]; // Light red or light teal
  const borderColor = isUrgent ? [254, 202, 202] : [204, 251, 241];

  doc.setFillColor(boxFill[0], boxFill[1], boxFill[2]);
  doc.setDrawColor(borderColor[0], borderColor[1], borderColor[2]);
  doc.roundedRect(margin, currentY, pageWidth - margin * 2, 28, 3, 3, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(isUrgent ? 185 : 13, isUrgent ? 28 : 148, isUrgent ? 28 : 136);
  doc.text(
    `PRELIMINARY INDICATION: ${primary?.category?.toUpperCase() || 'LESION'} • ${screeningResult.clinicalUrgency?.toUpperCase()} PRIORITY`,
    margin + 6,
    currentY + 7
  );

  doc.setFontSize(13);
  doc.setTextColor(15, 23, 42);
  doc.text(primary?.conditionName || 'Unclassified Lesion', margin + 6, currentY + 16);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(71, 85, 105);
  doc.text(`Calibrated Model Confidence: ${screeningResult.calibratedConfidence}%  •  Dataset: HAM10000 ISIC Archive`, margin + 6, currentY + 23);

  // Big Confidence Pill on Right
  doc.setFillColor(isUrgent ? 239 : 13, isUrgent ? 68 : 148, isUrgent ? 68 : 136);
  doc.roundedRect(pageWidth - margin - 35, currentY + 6, 29, 16, 2, 2, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.text(`${screeningResult.calibratedConfidence}%`, pageWidth - margin - 20.5, currentY + 14, { align: 'center' });
  doc.setFontSize(6);
  doc.text('CALIBRATED', pageWidth - margin - 20.5, currentY + 19, { align: 'center' });

  currentY += 34;

  // 4. LESION IMAGERY (Original Photo & Grad-CAM Heatmap)
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  doc.text('DERMOSCOPIC IMAGERY & EXPLAINABLE AI (GRAD-CAM)', margin, currentY);

  currentY += 4;

  const imgBoxWidth = 85;
  const imgBoxHeight = 55;

  // Image 1: Original Capture
  doc.setDrawColor(226, 232, 240);
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(margin, currentY, imgBoxWidth, imgBoxHeight, 2, 2, 'FD');

  try {
    if (rawImageUrl && rawImageUrl.startsWith('data:image')) {
      doc.addImage(rawImageUrl, 'JPEG', margin + 1, currentY + 1, imgBoxWidth - 2, imgBoxHeight - 8);
    }
  } catch (e) {
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text('[Dermoscopic Image Captured]', margin + 10, currentY + 25);
  }

  doc.setFontSize(7);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('Figure A: Captured Lesion Photo', margin + 4, currentY + imgBoxHeight - 2);

  // Image 2: Grad-CAM Overlay
  const rightImgX = margin + imgBoxWidth + 8;
  doc.roundedRect(rightImgX, currentY, imgBoxWidth, imgBoxHeight, 2, 2, 'FD');

  try {
    if (report.heatmapDataUrl && report.heatmapDataUrl.startsWith('data:image')) {
      doc.addImage(report.heatmapDataUrl, 'PNG', rightImgX + 1, currentY + 1, imgBoxWidth - 2, imgBoxHeight - 8);
    }
  } catch (e) {
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text('[Grad-CAM Heatmap Active]', rightImgX + 10, currentY + 25);
  }

  doc.text('Figure B: Grad-CAM Saliency Activation Heatmap', rightImgX + 4, currentY + imgBoxHeight - 2);

  currentY += imgBoxHeight + 8;

  // 5. ABCDE DERMOSCOPIC ASSESSMENT & OPTICAL QUALITY TABLE
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  doc.text('CLINICAL ABCDE CRITERIA & COMPUTER VISION METRICS', margin, currentY);

  currentY += 4;

  // Table container
  doc.setFillColor(255, 255, 255);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(margin, currentY, pageWidth - margin * 2, 38, 2, 2, 'FD');

  // Row 1: Header
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, currentY, pageWidth - margin * 2, 7, 'F');
  doc.setFontSize(7);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(71, 85, 105);
  doc.text('METRIC', margin + 4, currentY + 5);
  doc.text('MEASURED VALUE', margin + 50, currentY + 5);
  doc.text('REFERENCE THRESHOLD', margin + 95, currentY + 5);
  doc.text('CLINICAL FINDING', margin + 140, currentY + 5);

  const rows = [
    {
      name: 'Asymmetry (A)',
      value: `Score: ${features.asymmetryScore}`,
      ref: '< 0.35 (Symmetric)',
      status: features.asymmetryScore > 0.35 ? 'Asymmetric Axis Flagged' : 'Regular Symmetry',
    },
    {
      name: 'Border Irregularity (B)',
      value: `Score: ${features.borderIrregularity}`,
      ref: '< 0.45 (Smooth edge)',
      status: features.borderIrregularity > 0.45 ? 'Irregular / Notched Margin' : 'Well-Demarcated',
    },
    {
      name: 'Color Variegation (C)',
      value: `${features.colorVariegationCount} Hues Detected`,
      ref: '< 3 Distinct Hues',
      status: features.colorVariegationCount >= 3 ? 'Multi-Tone Pigmentation' : 'Uniform Coloration',
    },
    {
      name: 'Diameter (D)',
      value: `${features.diameterMm} mm`,
      ref: '< 6.0 mm (Pencil eraser)',
      status: features.diameterMm >= 6.0 ? 'Elevated Diameter (>6mm)' : 'Within Normal Bounds',
    },
  ];

  let tableY = currentY + 12;
  rows.forEach((r, idx) => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7);
    doc.setTextColor(15, 23, 42);
    doc.text(r.name, margin + 4, tableY);
    doc.text(r.value, margin + 50, tableY);
    doc.setTextColor(100, 116, 139);
    doc.text(r.ref, margin + 95, tableY);
    doc.setTextColor(r.status.includes('Flagged') || r.status.includes('Elevated') ? 185 : 13, r.status.includes('Flagged') || r.status.includes('Elevated') ? 28 : 148, r.status.includes('Flagged') || r.status.includes('Elevated') ? 28 : 136);
    doc.setFont('helvetica', 'bold');
    doc.text(r.status, margin + 140, tableY);
    tableY += 6.5;
  });

  currentY += 44;

  // 6. DIFFERENTIAL DIAGNOSES BREAKDOWN
  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  doc.text('DIFFERENTIAL CLASSIFICATIONS (MODEL SOFTMAX PROBABILITIES):', margin, currentY);

  currentY += 4;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(7);
  doc.setTextColor(71, 85, 105);

  const differentialsText = screeningResult.topDifferentials
    .map((d, i) => `${i + 1}. ${d.conditionName} (${d.category}): ${Math.round(d.probability * 100)}%`)
    .join('    |    ');
  doc.text(differentialsText, margin, currentY);

  currentY += 8;

  // 7. RECOMMENDED NEXT STEPS & REFERRAL SECTION
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(margin, currentY, pageWidth - margin * 2, 24, 2, 2, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(15, 23, 42);
  doc.text('RECOMMENDED CLINICAL ACTION FOR PHYSICIAN / DERMATOLOGIST:', margin + 4, currentY + 6);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(51, 65, 85);
  doc.text(screeningResult.recommendedAction, margin + 4, currentY + 12);

  doc.setFontSize(7);
  doc.setTextColor(100, 116, 139);
  doc.text('Physician Notes / Biopsy Assessment Orders: ____________________________________________________________________', margin + 4, currentY + 19);

  currentY += 28;

  // 8. MANDATORY MEDICAL DISCLAIMER (FOOTER)
  doc.setDrawColor(226, 232, 240);
  doc.line(margin, currentY, pageWidth - margin, currentY);
  currentY += 4;

  doc.setFontSize(6.5);
  doc.setFont('helvetica', 'italic');
  doc.setTextColor(100, 116, 139);
  const disclaimer =
    'NOTICE TO HEALTHCARE PROVIDERS & PATIENTS: MediSkin AI is an educational, computer-assisted preliminary triage tool benchmarked on the HAM10000 research archive. It is NOT cleared by FDA/CE as a standalone diagnostic device and does not produce a confirmed clinical diagnosis. All conclusions must be verified through clinical in-person examination, dermoscopy, and histopathology. MediSkin AI does not prescribe medications or replace professional medical consultation.';
  doc.text(disclaimer, margin, currentY, { maxWidth: pageWidth - margin * 2 });

  return doc;
}

/**
 * Downloads the medical report as a PDF file
 */
export function exportMedicalScreeningReportPdf(
  report: CompleteScreeningReport,
  rawImageUrl: string,
  patient: PatientInfoForReport,
  options?: PdfExportOptions
): string {
  const doc = buildMedicalScreeningPdf(report, rawImageUrl, patient, options);
  const refId = `MSK-REPORT-${Date.now().toString().slice(-6)}`;
  const filename = `${refId}.pdf`;
  doc.save(filename);
  return filename;
}

/**
 * Native Web Share or fallback for sharing report with physician
 */
export async function shareMedicalScreeningReport(
  report: CompleteScreeningReport,
  rawImageUrl: string,
  patient: PatientInfoForReport
): Promise<{ shared: boolean; method: 'web-share' | 'download' }> {
  const doc = buildMedicalScreeningPdf(report, rawImageUrl, patient);
  const pdfBlob = doc.output('blob');
  const filename = `MediSkin-Report-${Date.now().toString().slice(-6)}.pdf`;
  const file = new File([pdfBlob], filename, { type: 'application/pdf' });

  if (typeof navigator !== 'undefined' && navigator.canShare && navigator.canShare({ files: [file] })) {
    try {
      await navigator.share({
        title: 'MediSkin AI Medical Screening Report',
        text: `Clinical preliminary screening report for ${patient.name}. Condition: ${report.screeningResult.primaryCondition?.conditionName || 'Skin Lesion'} (${report.screeningResult.calibratedConfidence}% calibrated confidence).`,
        files: [file],
      });
      return { shared: true, method: 'web-share' };
    } catch {
      // User cancelled share or rejected
    }
  }

  // Fallback: download directly
  doc.save(filename);
  return { shared: true, method: 'download' };
}
