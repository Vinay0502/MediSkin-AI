import { UserProfile, DoctorProfile, HospitalFacility, ScreeningHistoryItem, AuditLogEntry, UserRole } from '../types/index.ts';
import { AppointmentRecord } from '../utils/appointmentRules.ts';

const TOKEN_KEY = 'mediskin_session_token';
const CACHED_USER_KEY = 'mediskin_cached_user';

export class ApiService {
  private static instance: ApiService;

  private constructor() {}

  public static getInstance(): ApiService {
    if (!ApiService.instance) {
      ApiService.instance = new ApiService();
    }
    return ApiService.instance;
  }

  public getToken(): string | null {
    try {
      return localStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  }

  public setToken(token: string | null): void {
    try {
      if (token) {
        localStorage.setItem(TOKEN_KEY, token);
      } else {
        localStorage.removeItem(TOKEN_KEY);
      }
    } catch (e) {
      console.warn('Storage unavailable:', e);
    }
  }

  public getCachedUser(): UserProfile | null {
    try {
      const stored = localStorage.getItem(CACHED_USER_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  }

  public setCachedUser(user: UserProfile | null): void {
    try {
      if (user) {
        localStorage.setItem(CACHED_USER_KEY, JSON.stringify(user));
      } else {
        localStorage.removeItem(CACHED_USER_KEY);
      }
    } catch (e) {
      console.warn('Storage unavailable:', e);
    }
  }

  private async request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string> || {}),
    };

    const token = this.getToken();
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(endpoint, {
      ...options,
      headers,
    });

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      throw new Error(data.error || `HTTP error ${response.status}`);
    }

    return data as T;
  }

  // --- Auth APIs ---
  public async register(payload: { name: string; email: string; password: string; phone?: string; role?: string }): Promise<{
    success: boolean;
    token: string;
    user: UserProfile;
    verificationCodeDemo?: string;
  }> {
    const res = await this.request<any>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    if (res.token) {
      this.setToken(res.token);
      this.setCachedUser(res.user);
    }
    return res;
  }

  public async login(payload: { email: string; password: string }): Promise<{
    success: boolean;
    token: string;
    user: UserProfile;
  }> {
    const res = await this.request<any>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
    if (res.token) {
      this.setToken(res.token);
      this.setCachedUser(res.user);
    }
    return res;
  }

  public async logout(): Promise<void> {
    try {
      await this.request('/api/auth/logout', { method: 'POST' });
    } catch {
      // Ignore network errors on logout
    } finally {
      this.setToken(null);
      this.setCachedUser(null);
    }
  }

  public async getMe(): Promise<UserProfile> {
    const res = await this.request<{ success: boolean; user: UserProfile }>('/api/auth/me');
    if (res.user) {
      this.setCachedUser(res.user);
    }
    return res.user;
  }

  public async verifyEmail(code: string): Promise<{ success: boolean; message: string }> {
    const res = await this.request<any>('/api/auth/verify-email', {
      method: 'POST',
      body: JSON.stringify({ code }),
    });
    const cached = this.getCachedUser();
    if (cached) {
      cached.isEmailVerified = true;
      this.setCachedUser(cached);
    }
    return res;
  }

  public async requestPasswordReset(email: string): Promise<{ success: boolean; message: string; resetCodeDemo?: string }> {
    return this.request('/api/auth/request-reset', {
      method: 'POST',
      body: JSON.stringify({ email }),
    });
  }

  public async resetPassword(payload: { email: string; code: string; newPassword: string }): Promise<{ success: boolean; message: string }> {
    return this.request('/api/auth/reset-password', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  public async deleteAccount(password: string): Promise<{ success: boolean; message: string }> {
    const res = await this.request<any>('/api/auth/account', {
      method: 'DELETE',
      body: JSON.stringify({ password }),
    });
    this.setToken(null);
    this.setCachedUser(null);
    return res;
  }

  // --- Doctors APIs ---
  public async getDoctors(): Promise<DoctorProfile[]> {
    const res = await this.request<{ success: boolean; doctors: DoctorProfile[] }>('/api/doctors');
    return res.doctors;
  }

  public async getDoctorById(id: string): Promise<DoctorProfile> {
    const res = await this.request<{ success: boolean; doctor: DoctorProfile }>(`/api/doctors/${id}`);
    return res.doctor;
  }

  public async updateDoctorSchedule(id: string, availableDays: number[], timeSlots: string[]): Promise<void> {
    await this.request(`/api/doctors/${id}/schedule`, {
      method: 'PUT',
      body: JSON.stringify({ availableDays, timeSlots }),
    });
  }

  public async updateDoctorVerification(id: string, status: string): Promise<void> {
    await this.request(`/api/admin/doctors/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  }

  // --- Hospitals APIs ---
  public async getHospitals(): Promise<HospitalFacility[]> {
    const res = await this.request<{ success: boolean; hospitals: HospitalFacility[] }>('/api/hospitals');
    return res.hospitals;
  }

  public async createHospital(facility: Partial<HospitalFacility>): Promise<void> {
    await this.request('/api/hospitals', {
      method: 'POST',
      body: JSON.stringify(facility),
    });
  }

  // --- Appointments APIs ---
  public async getAppointments(): Promise<AppointmentRecord[]> {
    const res = await this.request<{ success: boolean; appointments: AppointmentRecord[] }>('/api/appointments');
    return res.appointments;
  }

  public async createAppointment(payload: {
    doctorId: string;
    date: string;
    timeSlot: string;
    mode: string;
    reason: string;
    screeningId?: string;
    patientName?: string;
    patientEmail?: string;
    patientPhone?: string;
  }): Promise<{ success: boolean; appointment: AppointmentRecord }> {
    return this.request('/api/appointments', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  public async updateAppointmentStatus(id: string, status: string, options?: { cancellationReason?: string; doctorNotes?: string }): Promise<void> {
    await this.request(`/api/appointments/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status, ...options }),
    });
  }

  // --- Screenings APIs ---
  public async getScreenings(): Promise<ScreeningHistoryItem[]> {
    const res = await this.request<{ success: boolean; screenings: ScreeningHistoryItem[] }>('/api/screenings');
    return res.screenings;
  }

  public async saveScreening(report: any, imageUrl?: string): Promise<{ success: boolean; id: string }> {
    return this.request('/api/screenings', {
      method: 'POST',
      body: JSON.stringify({ report, imageUrl }),
    });
  }

  public async deleteScreening(id: string): Promise<void> {
    await this.request(`/api/screenings/${id}`, {
      method: 'DELETE',
    });
  }

  // --- Feedbacks APIs ---
  public async submitFeedback(payload: { rating: number; category: string; message: string; userName?: string; userEmail?: string }): Promise<void> {
    await this.request('/api/feedback', {
      method: 'POST',
      body: JSON.stringify(payload),
    });
  }

  // --- Admin APIs ---
  public async getAdminStats(): Promise<{
    users: number;
    doctors: number;
    hospitals: number;
    appointments: number;
    screenings: number;
    pendingVerifications: number;
  }> {
    const res = await this.request<{ success: boolean; stats: any }>('/api/admin/stats');
    return res.stats;
  }

  public async getAdminAuditLogs(): Promise<AuditLogEntry[]> {
    const res = await this.request<{ success: boolean; logs: AuditLogEntry[] }>('/api/admin/audit-logs');
    return res.logs;
  }
}

export const api = ApiService.getInstance();
