import {
  DoctorProfile,
  HospitalFacility,
  SkinConditionDetail,
  SystemNotification,
  UserFeedback,
  AuditLogEntry,
  ScreeningHistoryItem,
  UserProfile,
  UserRole,
  DoctorVerificationStatus,
} from '../types/index.ts';
import {
  AppointmentRecord,
  AppointmentStatus,
  canTransitionAppointmentStatus,
  generateBookingReference,
  validateBookingRequest,
} from '../utils/appointmentRules.ts';
import {
  INITIAL_DOCTORS,
  INITIAL_HOSPITALS,
  SKIN_CONDITIONS_LIBRARY,
  INITIAL_APPOINTMENTS,
  INITIAL_NOTIFICATIONS,
  INITIAL_FEEDBACKS,
  INITIAL_AUDIT_LOGS,
} from '../data/mockData.ts';
import { api } from './api.ts';

const STORAGE_KEYS = {
  CURRENT_USER: 'mediskin_current_user',
  DOCTORS: 'mediskin_doctors',
  HOSPITALS: 'mediskin_hospitals',
  APPOINTMENTS: 'mediskin_appointments',
  SCREENINGS: 'mediskin_screenings',
  NOTIFICATIONS: 'mediskin_notifications',
  FEEDBACKS: 'mediskin_feedbacks',
  AUDIT_LOGS: 'mediskin_audit_logs',
};

const DEFAULT_GUEST: UserProfile = {
  id: 'guest',
  name: 'Guest User',
  email: 'guest@mediskin.health',
  role: 'patient',
  medicalHistoryConsent: true,
  isEmailVerified: false,
  createdAt: new Date().toISOString(),
};

// Safe helper for localStorage
function getItem<T>(key: string, defaultValue: T): T {
  try {
    const stored = localStorage.getItem(key);
    if (!stored) return defaultValue;
    return JSON.parse(stored) as T;
  } catch {
    return defaultValue;
  }
}

function setItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    console.warn('Storage quota exceeded or storage unavailable:', e);
  }
}

export class DatabaseService {
  private static instance: DatabaseService;

  private constructor() {
    this.bootstrapSeedData();
  }

  public static getInstance(): DatabaseService {
    if (!DatabaseService.instance) {
      DatabaseService.instance = new DatabaseService();
    }
    return DatabaseService.instance;
  }

  private bootstrapSeedData(): void {
    if (!localStorage.getItem(STORAGE_KEYS.DOCTORS)) {
      setItem(STORAGE_KEYS.DOCTORS, INITIAL_DOCTORS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.HOSPITALS)) {
      setItem(STORAGE_KEYS.HOSPITALS, INITIAL_HOSPITALS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.APPOINTMENTS)) {
      setItem(STORAGE_KEYS.APPOINTMENTS, INITIAL_APPOINTMENTS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS)) {
      setItem(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.FEEDBACKS)) {
      setItem(STORAGE_KEYS.FEEDBACKS, INITIAL_FEEDBACKS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS)) {
      setItem(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
    }

    // Clean out legacy dummy account from storage if present
    const existing = getItem<UserProfile | null>(STORAGE_KEYS.CURRENT_USER, null);
    if (existing && existing.email === 'alex.mercer@example.com') {
      setItem(STORAGE_KEYS.CURRENT_USER, DEFAULT_GUEST);
    }
  }

  // --- User Session ---
  public getCurrentUser(): UserProfile {
    const user = getItem<UserProfile>(STORAGE_KEYS.CURRENT_USER, DEFAULT_GUEST);
    if (user.email === 'alex.mercer@example.com') {
      return DEFAULT_GUEST;
    }
    return user;
  }

  public setCurrentUser(user: UserProfile): void {
    setItem(STORAGE_KEYS.CURRENT_USER, user);
    this.addAuditLog(user.email, user.role, 'USER_SESSION_SWITCH', `Switched active session to ${user.name} (${user.role})`);
  }

  public clearCurrentUser(): void {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    setItem(STORAGE_KEYS.CURRENT_USER, DEFAULT_GUEST);
  }

  public switchRole(role: UserRole): UserProfile {
    let user: UserProfile;
    if (role === 'patient') {
      user = {
        id: 'patient-demo-1',
        name: 'Sarah Connor',
        email: 'patient@mediskin.health',
        role: 'patient',
        medicalHistoryConsent: true,
        isEmailVerified: true,
        createdAt: '2026-09-01T12:00:00Z',
      };
    } else if (role === 'doctor') {
      user = {
        id: 'doc-1',
        name: 'Dr. Sarah Lin',
        email: 'dr.lin@mediskin.health',
        role: 'doctor',
        phone: '+1 (415) 555-0188',
        avatarUrl: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=200',
        isEmailVerified: true,
        createdAt: '2026-08-15T09:00:00Z',
      };
    } else {
      user = {
        id: 'admin-1',
        name: 'Dr. Jonathan Hall (Chief Admin)',
        email: 'admin@mediskin.health',
        role: 'admin',
        phone: '+1 (800) 555-9000',
        avatarUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=200',
        isEmailVerified: true,
        createdAt: '2026-01-01T00:00:00Z',
      };
    }
    this.setCurrentUser(user);
    return user;
  }

  // --- Doctors & Verification ---
  public getDoctors(): DoctorProfile[] {
    return getItem<DoctorProfile[]>(STORAGE_KEYS.DOCTORS, INITIAL_DOCTORS);
  }

  public getDoctorById(id: string): DoctorProfile | undefined {
    return this.getDoctors().find((d) => d.id === id);
  }

  public updateDoctorVerification(
    doctorId: string,
    newStatus: DoctorVerificationStatus,
    adminEmail: string
  ): boolean {
    const list = this.getDoctors();
    const idx = list.findIndex((d) => d.id === doctorId);
    if (idx === -1) return false;

    const oldStatus = list[idx].verificationStatus;
    list[idx].verificationStatus = newStatus;
    setItem(STORAGE_KEYS.DOCTORS, list);

    // Sync to backend API if available
    api.updateDoctorVerification(doctorId, newStatus).catch(() => {});

    this.addAuditLog(
      adminEmail,
      'admin',
      'DOCTOR_VERIFICATION_UPDATE',
      `Doctor ${list[idx].name} status changed from "${oldStatus}" to "${newStatus}"`
    );

    // Notify doctor
    this.addNotification({
      userId: doctorId,
      title: 'Credential Verification Update',
      message: `Your medical credentials verification status has been updated to "${newStatus}".`,
      type: 'verification',
      actionUrl: 'dashboard',
    });

    return true;
  }

  public updateDoctorAvailability(doctorId: string, availableDays: number[], timeSlots: string[]): boolean {
    const list = this.getDoctors();
    const idx = list.findIndex((d) => d.id === doctorId);
    if (idx === -1) return false;

    list[idx].availableDays = availableDays;
    list[idx].timeSlots = timeSlots;
    setItem(STORAGE_KEYS.DOCTORS, list);

    api.updateDoctorSchedule(doctorId, availableDays, timeSlots).catch(() => {});
    return true;
  }

  // --- Healthcare Facilities ---
  public getHospitals(): HospitalFacility[] {
    return getItem<HospitalFacility[]>(STORAGE_KEYS.HOSPITALS, INITIAL_HOSPITALS);
  }

  public addHospital(facility: HospitalFacility, adminEmail: string): void {
    const list = this.getHospitals();
    list.push(facility);
    setItem(STORAGE_KEYS.HOSPITALS, list);

    api.createHospital(facility).catch(() => {});
    this.addAuditLog(adminEmail, 'admin', 'HOSPITAL_ADDED', `Added facility ${facility.name}`);
  }

  // --- Appointments ---
  public getAppointments(filter?: { userId?: string; role?: UserRole }): AppointmentRecord[] {
    const all = getItem<AppointmentRecord[]>(STORAGE_KEYS.APPOINTMENTS, INITIAL_APPOINTMENTS);
    if (!filter) return all;

    if (filter.role === 'patient' && filter.userId) {
      return all.filter((a) => a.patientId === filter.userId);
    }
    if (filter.role === 'doctor' && filter.userId) {
      return all.filter((a) => a.doctorId === filter.userId);
    }
    // Admin sees all
    return all;
  }

  public getAppointmentById(id: string): AppointmentRecord | undefined {
    return this.getAppointments().find((a) => a.id === id);
  }

  public createAppointment(params: {
    doctorId: string;
    patientId: string;
    patientName: string;
    patientEmail: string;
    patientPhone: string;
    date: string;
    timeSlot: string;
    mode: 'In-Person' | 'Video Call' | 'Audio Consultation';
    reason: string;
  }): { success: boolean; appointment?: AppointmentRecord; error?: string } {
    const doctor = this.getDoctorById(params.doctorId);
    if (!doctor) {
      return { success: false, error: 'Doctor not found in directory.' };
    }

    const all = this.getAppointments();
    const validation = validateBookingRequest(
      {
        doctorId: params.doctorId,
        date: params.date,
        timeSlot: params.timeSlot,
        patientEmail: params.patientEmail,
      },
      all,
      {
        doctorId: doctor.id,
        availableDays: doctor.availableDays,
        slots: doctor.timeSlots,
      }
    );

    if (!validation.isValid) {
      return { success: false, error: validation.error };
    }

    const newAppointment: AppointmentRecord = {
      id: `app-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      referenceCode: generateBookingReference(),
      patientId: params.patientId,
      patientName: params.patientName,
      patientEmail: params.patientEmail,
      patientPhone: params.patientPhone,
      doctorId: doctor.id,
      doctorName: doctor.name,
      specialty: doctor.specialty,
      clinicName: doctor.hospitalAffiliation,
      date: params.date,
      timeSlot: params.timeSlot,
      mode: params.mode,
      reason: params.reason,
      status: 'Confirmed',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    all.unshift(newAppointment);
    setItem(STORAGE_KEYS.APPOINTMENTS, all);

    // Sync to backend API
    api.createAppointment({
      doctorId: params.doctorId,
      date: params.date,
      timeSlot: params.timeSlot,
      mode: params.mode,
      reason: params.reason,
      patientName: params.patientName,
      patientEmail: params.patientEmail,
      patientPhone: params.patientPhone,
    }).catch(() => {});

    // Notify patient
    this.addNotification({
      userId: params.patientId,
      title: 'Appointment Confirmed',
      message: `Your appointment with ${doctor.name} on ${params.date} at ${params.timeSlot} is confirmed (Ref: ${newAppointment.referenceCode}).`,
      type: 'appointment',
      actionUrl: 'appointments',
    });

    // Notify doctor
    this.addNotification({
      userId: doctor.id,
      title: 'New Appointment Booking',
      message: `${params.patientName} scheduled a ${params.mode} consultation on ${params.date} at ${params.timeSlot}.`,
      type: 'appointment',
      actionUrl: 'dashboard',
    });

    this.addAuditLog(
      params.patientEmail,
      'patient',
      'APPOINTMENT_CREATED',
      `Booked appointment ${newAppointment.referenceCode} with ${doctor.name} for ${params.date}`
    );

    return { success: true, appointment: newAppointment };
  }

  public updateAppointmentStatus(
    appointmentId: string,
    newStatus: AppointmentStatus,
    actorEmail: string,
    actorRole: UserRole,
    notes?: string
  ): { success: boolean; error?: string } {
    const all = this.getAppointments();
    const idx = all.findIndex((a) => a.id === appointmentId);
    if (idx === -1) return { success: false, error: 'Appointment not found' };

    const current = all[idx];
    if (!canTransitionAppointmentStatus(current.status, newStatus, actorRole)) {
      return {
        success: false,
        error: `Action not permitted: Cannot transition appointment from ${current.status} to ${newStatus} with role "${actorRole}".`,
      };
    }

    current.status = newStatus;
    current.updatedAt = new Date().toISOString();
    if (notes) current.notes = notes;

    setItem(STORAGE_KEYS.APPOINTMENTS, all);

    api.updateAppointmentStatus(appointmentId, newStatus, { doctorNotes: notes }).catch(() => {});

    this.addNotification({
      userId: current.patientId,
      title: `Appointment ${newStatus}`,
      message: `Your consultation with ${current.doctorName} on ${current.date} at ${current.timeSlot} has been marked as ${newStatus}.`,
      type: 'appointment',
      actionUrl: 'appointments',
    });

    this.addAuditLog(
      actorEmail,
      actorRole,
      'APPOINTMENT_STATUS_CHANGE',
      `Appointment ${current.referenceCode} transitioned to ${newStatus}`
    );

    return { success: true };
  }

  public rescheduleAppointment(
    appointmentId: string,
    newDate: string,
    newTimeSlot: string,
    actorEmail: string,
    actorRole: UserRole
  ): { success: boolean; error?: string } {
    const all = this.getAppointments();
    const idx = all.findIndex((a) => a.id === appointmentId);
    if (idx === -1) return { success: false, error: 'Appointment not found' };

    const current = all[idx];
    const doctor = this.getDoctorById(current.doctorId);
    if (!doctor) return { success: false, error: 'Doctor record unavailable' };

    const otherAppointments = all.filter((a) => a.id !== appointmentId);
    const validation = validateBookingRequest(
      {
        doctorId: current.doctorId,
        date: newDate,
        timeSlot: newTimeSlot,
        patientEmail: current.patientEmail,
      },
      otherAppointments,
      {
        doctorId: doctor.id,
        availableDays: doctor.availableDays,
        slots: doctor.timeSlots,
      }
    );

    if (!validation.isValid) {
      return { success: false, error: validation.error };
    }

    const oldDate = current.date;
    const oldSlot = current.timeSlot;

    current.date = newDate;
    current.timeSlot = newTimeSlot;
    current.status = 'Confirmed';
    current.updatedAt = new Date().toISOString();

    setItem(STORAGE_KEYS.APPOINTMENTS, all);

    api.updateAppointmentStatus(appointmentId, 'Confirmed', { doctorNotes: `Rescheduled to ${newDate} at ${newTimeSlot}` }).catch(() => {});

    this.addNotification({
      userId: current.patientId,
      title: 'Appointment Rescheduled',
      message: `Your appointment with ${current.doctorName} was rescheduled from ${oldDate} ${oldSlot} to ${newDate} at ${newTimeSlot}.`,
      type: 'appointment',
      actionUrl: 'appointments',
    });

    this.addAuditLog(
      actorEmail,
      actorRole,
      'APPOINTMENT_RESCHEDULED',
      `Appointment ${current.referenceCode} rescheduled to ${newDate} ${newTimeSlot}`
    );

    return { success: true };
  }

  // --- Skin Screening History ---
  public getScreeningHistory(patientId?: string): ScreeningHistoryItem[] {
    const all = getItem<ScreeningHistoryItem[]>(STORAGE_KEYS.SCREENINGS, []);
    if (!patientId) return all;
    return all.filter((s) => s.patientId === patientId);
  }

  public saveScreeningRecord(record: Omit<ScreeningHistoryItem, 'id' | 'timestamp'>): ScreeningHistoryItem {
    const all = getItem<ScreeningHistoryItem[]>(STORAGE_KEYS.SCREENINGS, []);
    const newRecord: ScreeningHistoryItem = {
      ...record,
      id: `screen-${Date.now()}`,
      timestamp: new Date().toISOString(),
    };
    all.unshift(newRecord);
    setItem(STORAGE_KEYS.SCREENINGS, all);

    // Sync to backend API
    api.saveScreening(record, record.imageUrl).catch(() => {});

    this.addAuditLog(
      'user-consent-active',
      'patient',
      'SCREENING_RECORD_SAVED',
      `Saved preliminary screening: ${newRecord.conditionName} (${newRecord.confidence}%)`
    );

    return newRecord;
  }

  public deleteScreeningRecord(id: string): void {
    const all = getItem<ScreeningHistoryItem[]>(STORAGE_KEYS.SCREENINGS, []);
    const filtered = all.filter((s) => s.id !== id);
    setItem(STORAGE_KEYS.SCREENINGS, filtered);
    api.deleteScreening(id).catch(() => {});
  }

  // --- Skin Condition Library ---
  public getConditions(): SkinConditionDetail[] {
    return SKIN_CONDITIONS_LIBRARY;
  }

  public getConditionById(id: string): SkinConditionDetail | undefined {
    return SKIN_CONDITIONS_LIBRARY.find((c) => c.id === id);
  }

  // --- Notifications ---
  public getNotifications(userId?: string): SystemNotification[] {
    const all = getItem<SystemNotification[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    if (!userId) return all;
    return all.filter((n) => n.userId === userId || n.userId === 'all');
  }

  public addNotification(notification: Omit<SystemNotification, 'id' | 'timestamp' | 'isRead'>): void {
    const all = getItem<SystemNotification[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    all.unshift({
      ...notification,
      id: `notif-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString(),
      isRead: false,
    });
    setItem(STORAGE_KEYS.NOTIFICATIONS, all);
  }

  public markNotificationRead(id: string): void {
    const all = getItem<SystemNotification[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    const item = all.find((n) => n.id === id);
    if (item) {
      item.isRead = true;
      setItem(STORAGE_KEYS.NOTIFICATIONS, all);
    }
  }

  public markAllNotificationsRead(userId: string): void {
    const all = getItem<SystemNotification[]>(STORAGE_KEYS.NOTIFICATIONS, INITIAL_NOTIFICATIONS);
    all.forEach((n) => {
      if (n.userId === userId || n.userId === 'all') n.isRead = true;
    });
    setItem(STORAGE_KEYS.NOTIFICATIONS, all);
  }

  // --- Feedback ---
  public getFeedbacks(): UserFeedback[] {
    return getItem<UserFeedback[]>(STORAGE_KEYS.FEEDBACKS, INITIAL_FEEDBACKS);
  }

  public submitFeedback(feedback: Omit<UserFeedback, 'id' | 'createdAt'>): void {
    const all = this.getFeedbacks();
    all.unshift({
      ...feedback,
      id: `fb-${Date.now()}`,
      createdAt: new Date().toISOString(),
    });
    setItem(STORAGE_KEYS.FEEDBACKS, all);

    api.submitFeedback({
      rating: feedback.rating,
      category: feedback.category,
      message: feedback.comments,
      userName: feedback.userName,
    }).catch(() => {});
  }

  // --- Audit Trail ---
  public getAuditLogs(): AuditLogEntry[] {
    return getItem<AuditLogEntry[]>(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
  }

  public addAuditLog(actorEmail: string, actorRole: UserRole, action: string, details: string): void {
    const logs = this.getAuditLogs();
    logs.unshift({
      id: `audit-${Date.now()}`,
      actorEmail,
      actorRole,
      action,
      details,
      timestamp: new Date().toISOString(),
    });
    setItem(STORAGE_KEYS.AUDIT_LOGS, logs.slice(0, 200));
  }

  // --- Database Backup & Restore ---
  public exportDatabaseBackup(): any {
    const backup = {
      version: '2.6.4',
      exportedAt: new Date().toISOString(),
      appId: 'mediskin-clinical-suite',
      checksum: `sha256-${Date.now()}-${Math.random().toString(36).substring(2, 8)}`,
      doctors: this.getDoctors(),
      hospitals: this.getHospitals(),
      appointments: this.getAppointments(),
      screenings: this.getScreeningHistory(),
      feedbacks: this.getFeedbacks(),
      auditLogs: this.getAuditLogs(),
    };

    const user = this.getCurrentUser();
    this.addAuditLog(user.email, user.role, 'DATABASE_BACKUP_EXPORT', 'Full database snapshot downloaded.');
    return backup;
  }

  public restoreDatabaseBackup(backupJson: string): { success: boolean; error?: string } {
    try {
      const data = JSON.parse(backupJson);
      if (!data.version || !Array.isArray(data.doctors) || !Array.isArray(data.appointments)) {
        return { success: false, error: 'Invalid backup file format or incompatible database schema.' };
      }

      setItem(STORAGE_KEYS.DOCTORS, data.doctors);
      if (Array.isArray(data.hospitals)) setItem(STORAGE_KEYS.HOSPITALS, data.hospitals);
      if (Array.isArray(data.appointments)) setItem(STORAGE_KEYS.APPOINTMENTS, data.appointments);
      if (Array.isArray(data.screenings)) setItem(STORAGE_KEYS.SCREENINGS, data.screenings);
      if (Array.isArray(data.feedbacks)) setItem(STORAGE_KEYS.FEEDBACKS, data.feedbacks);

      const user = this.getCurrentUser();
      this.addAuditLog(user.email, user.role, 'DATABASE_BACKUP_RESTORE', `Restored database snapshot from ${data.exportedAt || 'backup'}`);

      return { success: true };
    } catch (err: any) {
      return { success: false, error: `Corrupt backup data: ${err.message}` };
    }
  }

  /**
   * Purges all private user data (GDPR / HIPAA patient right to erasure)
   */
  public purgeUserData(userId: string): void {
    const screenings = this.getScreeningHistory().filter((s) => s.patientId !== userId);
    setItem(STORAGE_KEYS.SCREENINGS, screenings);

    const appointments = this.getAppointments().map((app) => {
      if (app.patientId === userId) {
        return { ...app, status: 'Cancelled' as const, patientName: '[Redacted]', patientEmail: '[Redacted]', reason: '[Purged]' };
      }
      return app;
    });
    setItem(STORAGE_KEYS.APPOINTMENTS, appointments);

    const notifications = this.getNotifications().filter((n) => n.userId !== userId);
    setItem(STORAGE_KEYS.NOTIFICATIONS, notifications);
  }
}

export const db = DatabaseService.getInstance();
