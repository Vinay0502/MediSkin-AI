import { ErrorTelemetryRecord } from '../types/index.ts';

const ERROR_STORAGE_KEY = 'mediskin_error_telemetry';

export class ErrorTrackingService {
  private static instance: ErrorTrackingService;

  private constructor() {
    this.installGlobalHandlers();
  }

  public static getInstance(): ErrorTrackingService {
    if (!ErrorTrackingService.instance) {
      ErrorTrackingService.instance = new ErrorTrackingService();
    }
    return ErrorTrackingService.instance;
  }

  private installGlobalHandlers(): void {
    if (typeof window === 'undefined') return;

    window.addEventListener('error', (event) => {
      this.logError(event.message || 'Window uncaught error', event.error?.stack);
    });

    window.addEventListener('unhandledrejection', (event) => {
      this.logError(
        typeof event.reason === 'string' ? event.reason : event.reason?.message || 'Unhandled Promise Rejection',
        event.reason?.stack
      );
    });
  }

  public logError(message: string, stack?: string, componentStack?: string): void {
    try {
      const stored = localStorage.getItem(ERROR_STORAGE_KEY);
      const list: ErrorTelemetryRecord[] = stored ? JSON.parse(stored) : [];

      list.unshift({
        id: `err-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        message,
        stack,
        componentStack,
        route: window.location.pathname + window.location.search,
        timestamp: new Date().toISOString(),
      });

      localStorage.setItem(ERROR_STORAGE_KEY, JSON.stringify(list.slice(0, 50)));
    } catch {
      // failsafe
    }
  }

  public getErrors(): ErrorTelemetryRecord[] {
    try {
      const stored = localStorage.getItem(ERROR_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  public clearErrors(): void {
    try {
      localStorage.removeItem(ERROR_STORAGE_KEY);
    } catch {
      // failsafe
    }
  }
}

export const errorTracker = ErrorTrackingService.getInstance();
