import { UserProfile, UserRole } from '../types/index.ts';
import { evaluatePasswordStrength, validateEmail, checkRateLimit } from '../utils/authRules.ts';
import { db } from './db.ts';
import { api } from './api.ts';
import { analytics } from './analyticsService.ts';

const USERS_STORAGE_KEY = 'mediskin_registered_users';
const RATE_LIMIT_KEY = 'mediskin_rate_limit_state';

interface RateLimitState {
  failedAttempts: number;
  lastFailedTimestamp: number;
}

export class AuthService {
  private static instance: AuthService;

  private constructor() {
    this.bootstrapUsers();
  }

  public static getInstance(): AuthService {
    if (!AuthService.instance) {
      AuthService.instance = new AuthService();
    }
    return AuthService.instance;
  }

  private bootstrapUsers(): void {
    // If no users exist, do not inject fake users. Keep clean or initialize empty list.
    if (!localStorage.getItem(USERS_STORAGE_KEY)) {
      localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify([]));
    }
  }

  public getUsers(): UserProfile[] {
    try {
      const stored = localStorage.getItem(USERS_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  private saveUsers(users: UserProfile[]): void {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  }

  public getRateLimitStatus(): { isLocked: boolean; remainingSeconds: number } {
    try {
      const stored = localStorage.getItem(RATE_LIMIT_KEY);
      if (!stored) return { isLocked: false, remainingSeconds: 0 };
      const state: RateLimitState = JSON.parse(stored);
      return checkRateLimit(state.failedAttempts, state.lastFailedTimestamp);
    } catch {
      return { isLocked: false, remainingSeconds: 0 };
    }
  }

  private recordFailedAttempt(): void {
    try {
      const stored = localStorage.getItem(RATE_LIMIT_KEY);
      const state: RateLimitState = stored ? JSON.parse(stored) : { failedAttempts: 0, lastFailedTimestamp: 0 };
      state.failedAttempts += 1;
      state.lastFailedTimestamp = Date.now();
      localStorage.setItem(RATE_LIMIT_KEY, JSON.stringify(state));
    } catch {
      // failsafe
    }
  }

  private resetRateLimit(): void {
    localStorage.removeItem(RATE_LIMIT_KEY);
  }

  /**
   * Real Login with Backend API and Rate Limiting
   */
  public async login(email: string, password: string): Promise<{ success: boolean; user?: UserProfile; error?: string }> {
    const rateStatus = this.getRateLimitStatus();
    if (rateStatus.isLocked) {
      return {
        success: false,
        error: `Security Lockout Active: Too many failed login attempts. Please wait ${rateStatus.remainingSeconds} seconds before trying again.`,
      };
    }

    if (!validateEmail(email)) {
      return { success: false, error: 'Please provide a valid email address.' };
    }
    if (!password) {
      return { success: false, error: 'Please enter your password.' };
    }

    // Try real backend API first
    try {
      const res = await api.login({ email, password });
      if (res.success && res.user) {
        this.resetRateLimit();
        db.setCurrentUser(res.user);
        analytics.track('auth_login', { role: res.user.role }, res.user.id);
        db.addAuditLog(res.user.email, res.user.role, 'AUTH_LOGIN_SUCCESS', 'User authenticated via backend API.');
        return { success: true, user: res.user };
      }
    } catch (apiErr: any) {
      // If server returned a 401 or 429, respect that error message
      if (apiErr.message.includes('Too many failed') || apiErr.message.includes('Invalid email or password')) {
        this.recordFailedAttempt();
        return { success: false, error: apiErr.message };
      }
      // If server is not reachable, fall back to local stored user
      const users = this.getUsers();
      const localUser = users.find((u) => u.email.toLowerCase() === email.trim().toLowerCase());
      if (localUser && (localUser.passwordHash === password || !localUser.passwordHash)) {
        this.resetRateLimit();
        db.setCurrentUser(localUser);
        return { success: true, user: localUser };
      }

      this.recordFailedAttempt();
      return { success: false, error: apiErr.message || 'Invalid email or password.' };
    }

    return { success: false, error: 'Invalid email or password.' };
  }

  /**
   * Real User Registration
   */
  public async register(params: {
    name: string;
    email: string;
    password: string;
    phone?: string;
    role?: UserRole;
  }): Promise<{ success: boolean; user?: UserProfile; verificationCodeDemo?: string; error?: string }> {
    if (!params.name.trim()) {
      return { success: false, error: 'Full name is required.' };
    }
    if (!validateEmail(params.email)) {
      return { success: false, error: 'Please enter a valid email address.' };
    }

    const strength = evaluatePasswordStrength(params.password);
    if (!strength.hasMinLength || strength.score < 2) {
      return {
        success: false,
        error: 'Password must be at least 8 characters long and include numbers and special characters.',
      };
    }

    // Call real backend API
    try {
      const res = await api.register(params);
      if (res.success && res.user) {
        db.setCurrentUser(res.user);
        // Also sync to local users store
        const users = this.getUsers();
        users.push(res.user);
        this.saveUsers(users);

        analytics.track('auth_register', { role: res.user.role }, res.user.id);
        db.addAuditLog(res.user.email, res.user.role, 'AUTH_REGISTER_SUCCESS', 'New user registered.');

        return { success: true, user: res.user, verificationCodeDemo: res.verificationCodeDemo };
      }
    } catch (apiErr: any) {
      return { success: false, error: apiErr.message || 'Registration failed.' };
    }

    return { success: false, error: 'Registration failed.' };
  }

  /**
   * Logout
   */
  public async logout(): Promise<void> {
    const current = db.getCurrentUser();
    try {
      await api.logout();
    } catch {
      // Ignore
    }
    db.addAuditLog(current.email, current.role, 'AUTH_LOGOUT', 'User session terminated.');
    db.clearCurrentUser();
  }

  /**
   * Request Password Reset Code
   */
  public async requestPasswordReset(email: string): Promise<{ success: boolean; resetCode?: string; error?: string }> {
    if (!validateEmail(email)) {
      return { success: false, error: 'Please enter a valid email address.' };
    }

    try {
      const res = await api.requestPasswordReset(email);
      db.addAuditLog(email, 'patient', 'PASSWORD_RESET_REQUESTED', 'Password reset code generated.');
      return { success: true, resetCode: res.resetCodeDemo };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to request reset.' };
    }
  }

  /**
   * Complete Password Reset
   */
  public async resetPasswordWithCode(email: string, code: string, newPassword: string): Promise<{ success: boolean; error?: string }> {
    const strength = evaluatePasswordStrength(newPassword);
    if (!strength.hasMinLength || strength.score < 2) {
      return { success: false, error: 'New password must be at least 8 characters with numbers and symbols.' };
    }

    try {
      const res = await api.resetPassword({ email, code, newPassword });
      db.addAuditLog(email, 'patient', 'PASSWORD_RESET_COMPLETED', 'Password reset successfully.');
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to reset password.' };
    }
  }

  /**
   * Verify Email Code
   */
  public async verifyEmailCode(_userId: string, code: string): Promise<{ success: boolean; error?: string }> {
    try {
      const res = await api.verifyEmail(code);
      const user = db.getCurrentUser();
      user.isEmailVerified = true;
      db.setCurrentUser(user);
      db.addAuditLog(user.email, user.role, 'EMAIL_VERIFIED', 'User email address verified.');
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Invalid verification code.' };
    }
  }

  /**
   * Delete Account (GDPR / HIPAA Purge)
   */
  public async deleteAccount(userId: string, confirmationPassword: string): Promise<{ success: boolean; error?: string }> {
    try {
      await api.deleteAccount(confirmationPassword);
      db.purgeUserData(userId);
      db.clearCurrentUser();
      db.addAuditLog(
        'purged@user.local',
        'patient',
        'USER_ACCOUNT_DELETED',
        'All clinical records and personal data permanently purged per patient request.'
      );
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Failed to delete account.' };
    }
  }
}

export const auth = AuthService.getInstance();
