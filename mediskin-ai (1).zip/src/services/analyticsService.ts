import { AnalyticsEvent } from '../types/index.ts';

const ANALYTICS_STORAGE_KEY = 'mediskin_analytics_events';

export class AnalyticsService {
  private static instance: AnalyticsService;

  private constructor() {}

  public static getInstance(): AnalyticsService {
    if (!AnalyticsService.instance) {
      AnalyticsService.instance = new AnalyticsService();
    }
    return AnalyticsService.instance;
  }

  public track(type: AnalyticsEvent['type'], metadata?: Record<string, any>, userId?: string): void {
    try {
      const stored = localStorage.getItem(ANALYTICS_STORAGE_KEY);
      const events: AnalyticsEvent[] = stored ? JSON.parse(stored) : [];

      events.unshift({
        id: `ev-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        type,
        userId,
        metadata,
        timestamp: new Date().toISOString(),
      });

      // Keep up to 200 events
      localStorage.setItem(ANALYTICS_STORAGE_KEY, JSON.stringify(events.slice(0, 200)));
    } catch {
      // Storage unavailable or quota exceeded; failsafe silently
    }
  }

  public getEvents(): AnalyticsEvent[] {
    try {
      const stored = localStorage.getItem(ANALYTICS_STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  }

  public getSummary() {
    const events = this.getEvents();
    const pageViews = events.filter((e) => e.type === 'page_view').length;
    const screenings = events.filter((e) => e.type === 'screening_complete').length;
    const bookings = events.filter((e) => e.type === 'booking_submitted').length;
    const logins = events.filter((e) => e.type === 'auth_login').length;

    return {
      totalEvents: events.length,
      pageViews,
      screenings,
      bookings,
      logins,
      conversionRate: screenings > 0 ? Math.round((bookings / screenings) * 100) : 0,
    };
  }
}

export const analytics = AnalyticsService.getInstance();
