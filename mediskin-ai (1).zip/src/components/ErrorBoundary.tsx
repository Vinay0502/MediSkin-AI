import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home } from 'lucide-react';
import { errorTracker } from '../services/errorTrackingService.ts';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  errorMessage: string;
  errorStack?: string;
  showDetails: boolean;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      errorMessage: '',
      showDetails: false,
    };
  }

  static getDerivedStateFromError(error: Error): State {
    return {
      hasError: true,
      errorMessage: error.message || 'An unexpected application exception occurred.',
      errorStack: error.stack,
      showDetails: false,
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    errorTracker.logError(error.message, error.stack, errorInfo.componentStack || undefined);
  }

  handleReload = (): void => {
    window.location.reload();
  };

  handleReset = (): void => {
    this.setState({ hasError: false, errorMessage: '' });
    window.location.href = '/';
  };

  render(): ReactNode {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white rounded-3xl border border-slate-200 p-8 shadow-xl text-center space-y-6">
            <div className="w-16 h-16 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-rose-700 bg-rose-50 px-2.5 py-0.5 rounded-full">
                Application Exception
              </span>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
                Something went wrong
              </h1>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                An isolated error was caught and logged into the clinical error telemetry registry without exposing sensitive medical data.
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-left text-xs font-mono text-slate-700 break-words">
              {this.state.errorMessage}
            </div>

            <div className="flex flex-col sm:flex-row gap-3">
              <button
                onClick={this.handleReload}
                className="flex-1 py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center justify-center gap-2"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Reload Application</span>
              </button>
              <button
                onClick={this.handleReset}
                className="py-3 px-5 border border-slate-200 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-2"
              >
                <Home className="w-3.5 h-3.5" />
                <span>Return to Home</span>
              </button>
            </div>

            <button
              onClick={() => this.setState({ showDetails: !this.state.showDetails })}
              className="text-[11px] text-slate-400 hover:text-slate-600 underline"
            >
              {this.state.showDetails ? 'Hide Stack Trace' : 'View Technical Stack Trace'}
            </button>

            {this.state.showDetails && (
              <pre className="p-3 bg-slate-950 text-slate-300 rounded-xl text-[10px] text-left overflow-x-auto max-h-48 font-mono">
                {this.state.errorStack}
              </pre>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
