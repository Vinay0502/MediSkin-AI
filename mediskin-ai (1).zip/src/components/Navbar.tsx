import React, { useState } from 'react';
import {
  Scan,
  Calendar,
  Users,
  Building2,
  BookOpen,
  LayoutDashboard,
  Bell,
  Menu,
  X,
  Shield,
  User,
  CheckCircle,
  HelpCircle,
  ChevronDown,
  LogOut,
  LogIn,
  UserPlus,
} from 'lucide-react';
import { UserProfile, UserRole } from '../types/index.ts';
import { db } from '../services/db.ts';
import { auth } from '../services/authService.ts';
import { PWAInstallButton } from './PWAInstallButton.tsx';

interface Props {
  currentView: string;
  onNavigate: (view: string, params?: Record<string, any>) => void;
  currentUser: UserProfile;
  onRoleSwitch: (role: UserRole) => void;
  onOpenDisclaimer: () => void;
  onOpenAuth: (mode?: 'login' | 'register') => void;
  onLogout?: () => void;
}

export const Navbar: React.FC<Props> = ({
  currentView,
  onNavigate,
  currentUser,
  onRoleSwitch,
  onOpenDisclaimer,
  onOpenAuth,
  onLogout,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [roleMenuOpen, setRoleMenuOpen] = useState(false);

  const notifications = db.getNotifications(currentUser.id);
  const unreadCount = notifications.filter((n) => !n.isRead).length;

  const handleNav = (view: string) => {
    onNavigate(view);
    setMobileMenuOpen(false);
    setNotificationsOpen(false);
    setRoleMenuOpen(false);
  };

  const navItems = [
    { id: 'home', label: 'Home', icon: null },
    { id: 'analysis', label: 'Skin Screening', icon: Scan, badge: 'AI' },
    { id: 'doctors', label: 'Dermatologists', icon: Users },
    { id: 'hospitals', label: 'Clinics', icon: Building2 },
    { id: 'library', label: 'Condition Library', icon: BookOpen },
    { id: 'appointments', label: 'My Appointments', icon: Calendar },
    {
      id: 'dashboard',
      label: currentUser.role === 'admin' ? 'Admin Portal' : currentUser.role === 'doctor' ? 'Doctor Portal' : 'My Health',
      icon: LayoutDashboard,
    },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div className="flex items-center gap-3 cursor-pointer select-none" onClick={() => handleNav('home')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal-600 to-sky-600 flex items-center justify-center text-white shadow-md shadow-teal-500/20 ring-2 ring-white">
              <Scan className="w-5 h-5" />
            </div>
            <div>
              <span className="text-lg font-black tracking-tight text-slate-900 flex items-center gap-1">
                MediSkin<span className="text-teal-600">AI</span>
              </span>
              <span className="hidden sm:block text-[10px] uppercase font-bold tracking-wider text-slate-400 -mt-1">
                Clinical Dermatology Screening
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1" aria-label="Main Navigation">
            {navItems.map((item) => {
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={`px-3 py-2 rounded-lg text-xs font-semibold transition-all relative flex items-center gap-1.5 ${
                    isActive
                      ? 'bg-teal-50 text-teal-700 shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  {item.icon && <item.icon className="w-3.5 h-3.5" />}
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="px-1.5 py-0.2 bg-teal-600 text-white rounded-full text-[9px] font-bold">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Actions & Role Switcher */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* PWA Install Button */}
            <PWAInstallButton />

            {/* Notification Bell */}
            <div className="relative">
              <button
                onClick={() => setNotificationsOpen(!notificationsOpen)}
                className="p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-xl transition relative"
                aria-label="View notifications"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full ring-2 ring-white" />
                )}
              </button>

              {/* Notifications Dropdown */}
              {notificationsOpen && (
                <div className="absolute right-0 mt-2 w-80 bg-white rounded-2xl shadow-xl border border-slate-200 py-3 px-4 z-50">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800">Notifications</h4>
                    {unreadCount > 0 && (
                      <button
                        onClick={() => db.markAllNotificationsRead(currentUser.id)}
                        className="text-[11px] text-teal-600 hover:underline font-medium"
                      >
                        Mark all read
                      </button>
                    )}
                  </div>
                  <div className="max-h-64 overflow-y-auto space-y-2">
                    {notifications.length === 0 ? (
                      <p className="text-xs text-slate-400 py-4 text-center">No notifications</p>
                    ) : (
                      notifications.slice(0, 5).map((n) => (
                        <div
                          key={n.id}
                          onClick={() => {
                            db.markNotificationRead(n.id);
                            if (n.actionUrl) handleNav(n.actionUrl);
                          }}
                          className={`p-2.5 rounded-xl text-xs cursor-pointer transition ${
                            n.isRead ? 'bg-slate-50 text-slate-600' : 'bg-teal-50/60 text-slate-800 border-l-2 border-teal-600'
                          }`}
                        >
                          <p className="font-semibold text-slate-900">{n.title}</p>
                          <p className="text-[11px] text-slate-600 mt-0.5 line-clamp-2">{n.message}</p>
                          <span className="text-[10px] text-slate-400 mt-1 block">
                            {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* User Session & Role Controls */}
            {currentUser.id === 'guest' ? (
              <div className="flex items-center gap-1.5 sm:gap-2">
                <button
                  onClick={() => onOpenAuth('login')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 hover:text-teal-700 hover:bg-slate-100 transition border border-slate-200/90 shadow-2xs"
                >
                  <LogIn className="w-3.5 h-3.5 text-teal-600" />
                  <span>Sign In</span>
                </button>
                <button
                  onClick={() => onOpenAuth('register')}
                  className="hidden sm:flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold text-white bg-teal-600 hover:bg-teal-700 transition shadow-xs"
                >
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Register</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 sm:gap-2">
                {/* Profile Pill & Dropdown */}
                <div className="relative">
                  <button
                    onClick={() => setRoleMenuOpen(!roleMenuOpen)}
                    className="flex items-center gap-2 pl-1.5 pr-2.5 py-1 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-medium transition border border-slate-200"
                    aria-label="User Account Menu"
                  >
                    {currentUser.avatarUrl ? (
                      <img
                        src={currentUser.avatarUrl}
                        alt={currentUser.name}
                        className="w-6 h-6 rounded-full object-cover border border-white shadow-2xs"
                      />
                    ) : (
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center text-white text-[10px] font-bold ${
                        currentUser.role === 'admin' ? 'bg-purple-600' : currentUser.role === 'doctor' ? 'bg-blue-600' : 'bg-teal-600'
                      }`}>
                        {currentUser.name ? currentUser.name[0].toUpperCase() : 'U'}
                      </div>
                    )}
                    <span className="hidden sm:inline font-semibold max-w-[100px] truncate text-slate-900">{currentUser.name}</span>
                    <span className={`hidden md:inline text-[9px] uppercase font-bold px-1.5 py-0.5 rounded ${
                      currentUser.role === 'admin' ? 'bg-purple-100 text-purple-700' : currentUser.role === 'doctor' ? 'bg-blue-100 text-blue-700' : 'bg-teal-100 text-teal-700'
                    }`}>
                      {currentUser.role}
                    </span>
                    <ChevronDown className="w-3 h-3 text-slate-500" />
                  </button>

                  {roleMenuOpen && (
                    <div className="absolute right-0 mt-2 w-72 bg-white rounded-2xl shadow-xl border border-slate-200 py-2.5 z-50 animate-in fade-in zoom-in-95 duration-150">
                      <div className="px-4 py-2 border-b border-slate-100 mb-1 flex items-start gap-3">
                        {currentUser.avatarUrl ? (
                          <img
                            src={currentUser.avatarUrl}
                            alt={currentUser.name}
                            className="w-10 h-10 rounded-full object-cover border border-slate-200 shadow-2xs"
                          />
                        ) : (
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white text-sm font-bold shrink-0 ${
                            currentUser.role === 'admin' ? 'bg-purple-600' : currentUser.role === 'doctor' ? 'bg-blue-600' : 'bg-teal-600'
                          }`}>
                            {currentUser.name ? currentUser.name[0].toUpperCase() : 'U'}
                          </div>
                        )}
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-slate-900 text-xs truncate">{currentUser.name}</p>
                          <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                          <div className="mt-1 flex items-center gap-2">
                            <span className="text-[10px] font-bold text-teal-700 uppercase bg-teal-50 px-1.5 py-0.5 rounded">
                              {currentUser.role}
                            </span>
                            {currentUser.isEmailVerified ? (
                              <span className="text-[10px] text-emerald-600 font-semibold flex items-center gap-0.5">
                                <CheckCircle className="w-3 h-3" /> Verified
                              </span>
                            ) : (
                              <button
                                onClick={() => { setRoleMenuOpen(false); handleNav('settings'); }}
                                className="text-[10px] text-amber-600 font-bold hover:underline"
                              >
                                Verify Email
                              </button>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="px-3 py-1">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Navigation</span>
                      </div>

                      <button
                        onClick={() => handleNav('appointments')}
                        className="w-full px-3.5 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center justify-between"
                      >
                        <span>My Clinical Appointments</span>
                      </button>

                      <button
                        onClick={() => handleNav('settings')}
                        className="w-full px-3.5 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center justify-between"
                      >
                        <span>Account Settings & Security</span>
                      </button>

                      <button
                        onClick={() => handleNav('onboarding')}
                        className="w-full px-3.5 py-2 text-left text-xs text-slate-700 hover:bg-slate-50 flex items-center justify-between"
                      >
                        <span>Onboarding Tutorial</span>
                      </button>

                      {currentUser.role === 'admin' && (
                        <button
                          onClick={() => handleNav('analytics')}
                          className="w-full px-3.5 py-2 text-left text-xs text-purple-700 hover:bg-purple-50 font-semibold flex items-center justify-between"
                        >
                          <span>Platform Analytics & Errors</span>
                        </button>
                      )}

                      <div className="px-3 py-1 pt-2 border-t border-slate-100">
                        <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Switch Role View</span>
                      </div>
                      <button
                        onClick={() => { onRoleSwitch('patient'); setRoleMenuOpen(false); }}
                        className={`w-full px-3.5 py-1.5 text-left text-xs flex items-center justify-between hover:bg-slate-50 ${
                          currentUser.role === 'patient' ? 'font-bold text-teal-700 bg-teal-50/50' : 'text-slate-700'
                        }`}
                      >
                        <span>Patient Perspective</span>
                        {currentUser.role === 'patient' && <CheckCircle className="w-3.5 h-3.5 text-teal-600" />}
                      </button>
                      <button
                        onClick={() => { onRoleSwitch('doctor'); setRoleMenuOpen(false); }}
                        className={`w-full px-3.5 py-1.5 text-left text-xs flex items-center justify-between hover:bg-slate-50 ${
                          currentUser.role === 'doctor' ? 'font-bold text-blue-700 bg-blue-50/50' : 'text-slate-700'
                        }`}
                      >
                        <span>Doctor Perspective</span>
                        {currentUser.role === 'doctor' && <CheckCircle className="w-3.5 h-3.5 text-blue-600" />}
                      </button>
                      <button
                        onClick={() => { onRoleSwitch('admin'); setRoleMenuOpen(false); }}
                        className={`w-full px-3.5 py-1.5 text-left text-xs flex items-center justify-between hover:bg-slate-50 ${
                          currentUser.role === 'admin' ? 'font-bold text-purple-700 bg-purple-50/50' : 'text-slate-700'
                        }`}
                      >
                        <span>Administrator</span>
                        {currentUser.role === 'admin' && <CheckCircle className="w-3.5 h-3.5 text-purple-600" />}
                      </button>

                      <div className="pt-2 border-t border-slate-100 px-3 space-y-1">
                        <button
                          onClick={() => {
                            setRoleMenuOpen(false);
                            onOpenAuth('login');
                          }}
                          className="w-full py-1.5 text-center text-xs font-semibold text-slate-700 hover:bg-slate-50 rounded-lg transition"
                        >
                          Switch Account
                        </button>
                        <button
                          onClick={async () => {
                            setRoleMenuOpen(false);
                            if (onLogout) {
                              onLogout();
                            } else {
                              await auth.logout();
                              window.location.reload();
                            }
                          }}
                          className="w-full py-2 text-center text-xs font-bold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-xl transition flex items-center justify-center gap-1.5"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          <span>Sign Out</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>

                {/* Direct Desktop Sign Out Button */}
                <button
                  onClick={async () => {
                    if (onLogout) {
                      onLogout();
                    } else {
                      await auth.logout();
                      window.location.reload();
                    }
                  }}
                  title="Sign Out of MediSkin"
                  className="hidden md:flex items-center gap-1 px-2.5 py-1.5 text-xs font-bold text-rose-600 hover:text-rose-700 bg-rose-50/80 hover:bg-rose-100/90 rounded-xl transition border border-rose-200/60 shadow-2xs"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            )}

            {/* Disclaimer Help Link */}
            <button
              onClick={onOpenDisclaimer}
              className="hidden md:inline-flex p-2 text-slate-400 hover:text-teal-600 hover:bg-slate-50 rounded-xl transition"
              title="Medical Safety Disclaimer"
            >
              <HelpCircle className="w-4 h-4" />
            </button>

            {/* Mobile Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 hover:bg-slate-100 rounded-xl"
              aria-label="Toggle mobile menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-200 bg-white px-4 pt-3 pb-6 space-y-3 shadow-lg animate-in slide-in-from-top duration-200">
          {/* Mobile Auth Banner */}
          {currentUser.id === 'guest' ? (
            <div className="p-3 bg-teal-50/70 rounded-2xl border border-teal-100 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-900">Patient Account</p>
                <p className="text-[11px] text-slate-500">Sign in to save reports & history</p>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => { setMobileMenuOpen(false); onOpenAuth('login'); }}
                  className="px-3 py-1.5 bg-white text-teal-700 font-bold rounded-xl text-xs border border-teal-200 shadow-2xs"
                >
                  Sign In
                </button>
                <button
                  onClick={() => { setMobileMenuOpen(false); onOpenAuth('register'); }}
                  className="px-3 py-1.5 bg-teal-600 text-white font-bold rounded-xl text-xs shadow-2xs"
                >
                  Register
                </button>
              </div>
            </div>
          ) : (
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                {currentUser.avatarUrl ? (
                  <img src={currentUser.avatarUrl} alt={currentUser.name} className="w-8 h-8 rounded-full object-cover" />
                ) : (
                  <div className="w-8 h-8 rounded-full bg-teal-600 text-white font-bold text-xs flex items-center justify-center">
                    {currentUser.name ? currentUser.name[0].toUpperCase() : 'U'}
                  </div>
                )}
                <div>
                  <p className="text-xs font-bold text-slate-900 leading-tight">{currentUser.name}</p>
                  <p className="text-[10px] text-slate-500">{currentUser.email}</p>
                </div>
              </div>
              <button
                onClick={async () => {
                  setMobileMenuOpen(false);
                  if (onLogout) {
                    onLogout();
                  } else {
                    await auth.logout();
                    window.location.reload();
                  }
                }}
                className="flex items-center gap-1 px-3 py-1.5 text-xs font-bold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-xl transition"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2 mb-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`flex items-center gap-2 p-2.5 rounded-xl text-xs font-semibold ${
                  currentView === item.id ? 'bg-teal-600 text-white' : 'bg-slate-50 text-slate-700 hover:bg-slate-100'
                }`}
              >
                {item.icon && <item.icon className="w-4 h-4" />}
                <span>{item.label}</span>
              </button>
            ))}
          </div>

          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
            <button
              onClick={() => { onOpenDisclaimer(); setMobileMenuOpen(false); }}
              className="text-xs text-slate-500 hover:text-teal-600 flex items-center gap-1.5"
            >
              <HelpCircle className="w-4 h-4" />
              <span>Medical Safety Protocol</span>
            </button>
            <span className="text-[10px] text-slate-400">v2.6 Stable</span>
          </div>
        </div>
      )}
    </header>
  );
};
