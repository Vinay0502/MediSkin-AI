import React from 'react';
import { ShieldCheck, HeartPulse, ExternalLink, Activity } from 'lucide-react';

interface Props {
  onNavigate: (view: string) => void;
  onOpenDisclaimer: () => void;
}

export const Footer: React.FC<Props> = ({ onNavigate, onOpenDisclaimer }) => {
  return (
    <footer className="bg-slate-900 text-slate-400 text-xs border-t border-slate-800">
      {/* Emergency Notice Banner */}
      <div className="bg-rose-950/70 border-b border-rose-900/60 py-3 px-4">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-rose-200">
          <div className="flex items-center gap-2">
            <HeartPulse className="w-4 h-4 text-rose-400 shrink-0" />
            <span className="font-semibold text-xs">Medical Emergency:</span>
            <span className="text-[11px] text-rose-300">
              If a lesion is rapidly ulcerating, heavily bleeding, or accompanied by severe acute symptoms, call 911 or visit the nearest emergency facility.
            </span>
          </div>
          <button
            onClick={() => onNavigate('hospitals')}
            className="text-[11px] underline font-medium text-rose-300 hover:text-white shrink-0"
          >
            Find Urgent Care
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Col 1: Brand */}
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-white font-bold text-base">
              <div className="w-7 h-7 rounded-lg bg-teal-500 flex items-center justify-center text-white">
                <Activity className="w-4 h-4" />
              </div>
              <span>MediSkin AI</span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Clinical deep-learning lesion classification, computer vision quality assurance, verified dermatologist discovery, and patient consultation scheduling.
            </p>
            <div className="flex items-center gap-2 text-[11px] text-emerald-400">
              <ShieldCheck className="w-4 h-4" />
              <span>HAM10000 / ISIC Research Standard</span>
            </div>
          </div>

          {/* Col 2: Clinical Services */}
          <div>
            <h4 className="text-white font-semibold mb-3 uppercase tracking-wider text-[11px]">Platform</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('analysis')} className="hover:text-teal-400 transition">
                  AI Skin Screening & Heatmap
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('doctors')} className="hover:text-teal-400 transition">
                  Find Board-Certified Dermatologists
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('hospitals')} className="hover:text-teal-400 transition">
                  Hospital & Urgent Care Search
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('library')} className="hover:text-teal-400 transition">
                  Skin Condition Medical Atlas
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('appointments')} className="hover:text-teal-400 transition">
                  Appointment Management
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Medical Sources */}
          <div>
            <h4 className="text-white font-semibold mb-3 uppercase tracking-wider text-[11px]">Medical References</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a
                  href="https://www.aad.org"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-teal-400 flex items-center gap-1"
                >
                  <span>American Academy of Dermatology (AAD)</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a
                  href="https://www.skincancer.org"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-teal-400 flex items-center gap-1"
                >
                  <span>Skin Cancer Foundation</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a
                  href="https://dermnetnz.org"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-teal-400 flex items-center gap-1"
                >
                  <span>DermNet Dermatology Resource</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
              <li>
                <a
                  href="https://isic-archive.com"
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-teal-400 flex items-center gap-1"
                >
                  <span>International Skin Imaging Collaboration</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </li>
            </ul>
          </div>

          {/* Col 4: Legal & Safety */}
          <div>
            <h4 className="text-white font-semibold mb-3 uppercase tracking-wider text-[11px]">Safety & Governance</h4>
            <p className="text-[11px] leading-relaxed text-slate-400 mb-3">
              MediSkin AI is an educational screening aid. It is <strong>NOT</strong> an FDA/CE cleared diagnostic device. Never disregard professional medical advice.
            </p>
            <div className="space-y-1.5">
              <button
                onClick={onOpenDisclaimer}
                className="block text-teal-400 hover:text-teal-300 underline font-medium"
              >
                Read Medical Disclaimer & Protocol
              </button>
              <button
                onClick={() => onNavigate('privacy')}
                className="block text-slate-300 hover:text-teal-300"
              >
                Privacy Policy (HIPAA / GDPR)
              </button>
              <button
                onClick={() => onNavigate('terms')}
                className="block text-slate-300 hover:text-teal-300"
              >
                Terms of Service
              </button>
              <button
                onClick={() => onNavigate('feedback')}
                className="block text-slate-300 hover:text-white"
              >
                Submit Quality Feedback & Reviews
              </button>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500">
          <p>© 2026 MediSkin AI Technologies. Built for ethical healthcare accessibility.</p>
          <div className="flex items-center gap-4">
            <span>PWA & Play Store Ready</span>
            <span>Local Secure Storage</span>
            <span>Version 2.6.4</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
