import React, { useEffect, useState } from 'react';
import { Download, Smartphone, CheckCircle, Info } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const PWAInstallButton: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [showModal, setShowModal] = useState(false);

  useEffect(() => {
    // Check if running in standalone mode (PWA installed)
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(isStandalone);

    const ua = window.navigator.userAgent.toLowerCase();
    const isIOSDevice = /iphone|ipad|ipod/.test(ua);
    setIsIOS(isIOSDevice);

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') {
        setIsInstalled(true);
        setDeferredPrompt(null);
      }
    } else {
      setShowModal(true);
    }
  };

  if (isInstalled) {
    return (
      <span className="hidden sm:inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-emerald-700 bg-emerald-50 rounded-full border border-emerald-200">
        <CheckCircle className="w-3.5 h-3.5" />
        App Installed
      </span>
    );
  }

  return (
    <>
      <button
        onClick={handleInstallClick}
        aria-label="Install MediSkin AI mobile application"
        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-sm transition active:scale-95"
      >
        <Smartphone className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">Install App</span>
        <span className="sm:hidden">Install</span>
      </button>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-white rounded-2xl p-6 shadow-2xl border border-slate-100">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center font-bold">
                <Smartphone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Install MediSkin AI</h3>
                <p className="text-xs text-slate-500">Google Play Store & Mobile PWA</p>
              </div>
            </div>

            <div className="space-y-3 text-sm text-slate-600 mb-6">
              {isIOS ? (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <p className="font-semibold text-slate-800 mb-1">To install on iPhone or iPad:</p>
                  <ol className="list-decimal list-inside space-y-1 text-xs">
                    <li>Tap the <strong>Share</strong> button in Safari toolbar.</li>
                    <li>Scroll down and select <strong>Add to Home Screen</strong>.</li>
                    <li>Tap <strong>Add</strong> to launch in standalone app mode.</li>
                  </ol>
                </div>
              ) : (
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <p className="font-semibold text-slate-800 mb-1">Android & Google Play Store:</p>
                  <p className="text-xs text-slate-600 mb-2">
                    MediSkin AI complies with Google Play Store <strong>Trusted Web Activity (TWA)</strong> and PWA guidelines. You can install it directly to your home screen or package it using Bubblewrap / Expo for Play Store distribution.
                  </p>
                  <ul className="text-xs space-y-1 list-disc list-inside">
                    <li>Works offline with cached guidelines</li>
                    <li>Fast instant launch with camera access</li>
                    <li>Zero storage overhead</li>
                  </ul>
                </div>
              )}

              <div className="flex items-center gap-2 p-2.5 bg-teal-50 text-teal-800 rounded-lg text-xs">
                <Info className="w-4 h-4 shrink-0 text-teal-600" />
                <span>Manifest, secure service worker, and icons are active.</span>
              </div>
            </div>

            <button
              onClick={() => setShowModal(false)}
              className="w-full py-2.5 bg-slate-900 text-white font-medium rounded-xl hover:bg-slate-800 text-sm"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
};
