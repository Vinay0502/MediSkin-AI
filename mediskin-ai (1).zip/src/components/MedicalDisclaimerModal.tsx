import React from 'react';
import { AlertTriangle, ShieldCheck, HeartPulse, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const MedicalDisclaimerModal: React.FC<Props> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-100 max-h-[90vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-teal-50/50">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Medical Safety & Regulatory Statement</h2>
              <p className="text-xs text-slate-500">MediSkin AI Clinical Protocol v2.6</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100"
            aria-label="Close disclaimer modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-4 text-sm text-slate-600 leading-relaxed">
          <div className="p-4 bg-amber-50 rounded-xl border border-amber-200 text-amber-900 flex items-start gap-3">
            <HeartPulse className="w-5 h-5 shrink-0 text-amber-600 mt-0.5" />
            <div>
              <p className="font-bold text-xs uppercase tracking-wider text-amber-800">
                Not a Replacement for Professional Medical Diagnosis
              </p>
              <p className="text-xs mt-1 text-amber-800/90">
                MediSkin AI is an educational, preliminary computer-assisted triage and lesion screening tool. It does <strong>not</strong> produce a definitive clinical diagnosis and must never be used as a substitute for professional evaluation by a qualified medical practitioner.
              </p>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-slate-900 mb-1.5 text-sm">1. Limitations of AI Screening</h3>
            <p className="text-xs text-slate-600">
              Skin lesion images taken on consumer mobile devices vary in lighting, focus, resolution, and angle. Even high-accuracy deep learning models trained on dermoscopic datasets (e.g. HAM10000) have statistical false-positive and false-negative rates. A low-risk AI result does not guarantee the absence of malignancy.
            </p>
          </div>

          <div>
            <h3 className="font-semibold text-slate-900 mb-1.5 text-sm">2. When to Seek Immediate Attention (Red Flags)</h3>
            <ul className="text-xs text-slate-600 list-disc list-inside space-y-1">
              <li>A mole or lesion that is rapidly growing, spreading, or changing color.</li>
              <li>Spontaneous bleeding, crusting, oozing, or ulceration that does not heal within 3 weeks.</li>
              <li>Severe localized pain, tenderness, or persistent itching.</li>
              <li>A new dark streak under a fingernail or toenail.</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-slate-900 mb-1.5 text-sm">3. Data Privacy & Confidentiality</h3>
            <p className="text-xs text-slate-600">
              Uploaded skin images are evaluated in-session for optical quality and feature extraction. MediSkin AI does not sell, share, or disclose patient images to third-party advertisers. Local storage of screening history is controlled entirely by you and can be purged at any time from your patient dashboard.
            </p>
          </div>

          <div className="pt-2 border-t border-slate-100 flex items-center gap-2 text-xs text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Complies with digital health transparency and ethical healthcare guidance.</span>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-sm font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-xl shadow-sm transition"
          >
            I Understand & Agree
          </button>
        </div>
      </div>
    </div>
  );
};
