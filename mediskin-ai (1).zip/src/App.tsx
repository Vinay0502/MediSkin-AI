import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { Footer } from './components/Footer.tsx';
import { MedicalDisclaimerModal } from './components/MedicalDisclaimerModal.tsx';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { AuthModal } from './views/AuthModal.tsx';
import { HomeView } from './views/HomeView.tsx';
import { AnalysisView } from './views/AnalysisView.tsx';
import { ResultsView } from './views/ResultsView.tsx';
import { DoctorDirectoryView } from './views/DoctorDirectoryView.tsx';
import { DoctorProfileView } from './views/DoctorProfileView.tsx';
import { HospitalSearchView } from './views/HospitalSearchView.tsx';
import { ConditionLibraryView } from './views/ConditionLibraryView.tsx';
import { AppointmentBookingView } from './views/AppointmentBookingView.tsx';
import { MyAppointmentsView } from './views/MyAppointmentsView.tsx';
import { PatientDashboardView } from './views/PatientDashboardView.tsx';
import { DoctorDashboardView } from './views/DoctorDashboardView.tsx';
import { AdminDashboardView } from './views/AdminDashboardView.tsx';
import { AboutView } from './views/AboutView.tsx';
import { FeedbackView } from './views/FeedbackView.tsx';
import { OnboardingView } from './views/OnboardingView.tsx';
import { PrivacyPolicyView } from './views/PrivacyPolicyView.tsx';
import { TermsOfServiceView } from './views/TermsOfServiceView.tsx';
import { SettingsView } from './views/SettingsView.tsx';
import { AnalyticsView } from './views/AnalyticsView.tsx';
import { NotFoundView } from './views/NotFoundView.tsx';
import { db } from './services/db.ts';
import { analytics } from './services/analyticsService.ts';
import { CompleteScreeningReport } from './services/aiVisionEngine.ts';
import { UserProfile, UserRole } from './types/index.ts';
import { auth } from './services/authService.ts';
import { api } from './services/api.ts';
import { Home, Scan, Users, Calendar, LayoutDashboard, WifiOff, AlertCircle } from 'lucide-react';

export default function App() {
  const [currentView, setCurrentView] = useState<string>('home');
  const [viewParams, setViewParams] = useState<Record<string, any>>({});
  const [currentUser, setCurrentUser] = useState<UserProfile>(db.getCurrentUser());
  const [disclaimerOpen, setDisclaimerOpen] = useState<boolean>(false);
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'login' | 'register' | 'forgot' | 'verify'>('login');
  const [latestReport, setLatestReport] = useState<CompleteScreeningReport | null>(null);
  const [latestImageUrl, setLatestImageUrl] = useState<string | null>(null);
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );

  // Restore authenticated session from backend token on mount
  useEffect(() => {
    const token = api.getToken();
    if (token) {
      api.getMe()
        .then((user) => {
          if (user && user.id) {
            setCurrentUser(user);
            db.setCurrentUser(user);
          }
        })
        .catch(() => {
          api.setToken(null);
          api.setCachedUser(null);
          setCurrentUser(db.getCurrentUser());
        });
    }
  }, []);

  // Network status listener and service worker
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch((err) => {
        console.warn('Service worker registration failed:', err);
      });
    }

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Track page navigation in analytics
  const handleNavigate = (view: string, params: Record<string, any> = {}) => {
    setCurrentView(view);
    setViewParams(params);
    analytics.track('page_view', { view, params }, currentUser.id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRoleSwitch = (newRole: UserRole) => {
    const updatedUser = db.switchRole(newRole);
    setCurrentUser(updatedUser);
  };

  const handleLogout = async () => {
    await auth.logout();
    const guestUser = db.getCurrentUser();
    setCurrentUser(guestUser);
    handleNavigate('home');
  };

  const handleAnalysisComplete = (report: CompleteScreeningReport, rawImageUrl: string) => {
    setLatestReport(report);
    setLatestImageUrl(rawImageUrl);
    analytics.track('screening_complete', {
      condition: report.screeningResult.primaryCondition?.conditionName,
      confidence: report.screeningResult.calibratedConfidence,
      urgency: report.screeningResult.clinicalUrgency,
    }, currentUser.id);
    setCurrentView('results');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenAuth = (mode: 'login' | 'register' | 'forgot' | 'verify' = 'login') => {
    setAuthModalMode(mode);
    setAuthModalOpen(true);
  };

  const handleAuthSuccess = (user: UserProfile) => {
    setCurrentUser(user);
    db.setCurrentUser(user);
    setAuthModalOpen(false);
  };

  // Render current view
  const renderView = () => {
    switch (currentView) {
      case 'home':
        return (
          <HomeView
            onNavigate={handleNavigate}
            featuredDoctors={db.getDoctors()}
            onOpenDisclaimer={() => setDisclaimerOpen(true)}
          />
        );

      case 'analysis':
        return (
          <AnalysisView
            onAnalysisComplete={handleAnalysisComplete}
            currentUser={currentUser}
            onOpenDisclaimer={() => setDisclaimerOpen(true)}
          />
        );

      case 'results':
        if (!latestReport || !latestImageUrl) {
          return (
            <AnalysisView
              onAnalysisComplete={handleAnalysisComplete}
              currentUser={currentUser}
              onOpenDisclaimer={() => setDisclaimerOpen(true)}
            />
          );
        }
        return (
          <ResultsView
            report={latestReport}
            rawImageUrl={latestImageUrl}
            currentUser={currentUser}
            onNavigate={handleNavigate}
            onOpenDisclaimer={() => setDisclaimerOpen(true)}
          />
        );

      case 'doctors':
        return (
          <DoctorDirectoryView
            doctors={db.getDoctors()}
            onNavigate={handleNavigate}
            prefilledReason={viewParams.prefilledReason}
          />
        );

      case 'doctor-profile': {
        const doc = db.getDoctorById(viewParams.doctorId) || db.getDoctors()[0];
        return (
          <DoctorProfileView
            doctor={doc}
            onNavigate={handleNavigate}
            onBack={() => handleNavigate('doctors')}
          />
        );
      }

      case 'hospitals':
        return (
          <HospitalSearchView
            facilities={db.getHospitals()}
            onNavigate={handleNavigate}
          />
        );

      case 'library':
        return (
          <ConditionLibraryView
            conditions={db.getConditions()}
            initialConditionId={viewParams.conditionId}
            onNavigate={handleNavigate}
          />
        );

      case 'booking':
        return (
          <AppointmentBookingView
            doctorId={viewParams.doctorId || db.getDoctors()[0].id}
            currentUser={currentUser}
            prefilledReason={viewParams.prefilledReason}
            onNavigate={handleNavigate}
            onBack={() => handleNavigate('doctors')}
          />
        );

      case 'appointments':
        return (
          <MyAppointmentsView
            currentUser={currentUser}
            onNavigate={handleNavigate}
          />
        );

      case 'dashboard':
        if (currentUser.role === 'admin') {
          return <AdminDashboardView currentUser={currentUser} />;
        }
        if (currentUser.role === 'doctor') {
          return <DoctorDashboardView currentUser={currentUser} />;
        }
        return (
          <PatientDashboardView
            currentUser={currentUser}
            onNavigate={handleNavigate}
          />
        );

      case 'settings':
        return (
          <SettingsView
            currentUser={currentUser}
            onOpenVerifyModal={() => handleOpenAuth('verify')}
            onNavigate={handleNavigate}
          />
        );

      case 'onboarding':
        return (
          <OnboardingView
            onComplete={() => handleNavigate('home')}
            onNavigate={handleNavigate}
          />
        );

      case 'privacy':
        return <PrivacyPolicyView onBack={() => handleNavigate('home')} />;

      case 'terms':
        return <TermsOfServiceView onBack={() => handleNavigate('home')} />;

      case 'analytics':
        return <AnalyticsView />;

      case 'about':
        return <AboutView />;

      case 'feedback':
        return <FeedbackView currentUser={currentUser} />;

      default:
        return <NotFoundView onNavigate={handleNavigate} />;
    }
  };

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-slate-50 flex flex-col font-sans text-slate-800 antialiased selection:bg-teal-500 selection:text-white pb-16 lg:pb-0">
        {/* Offline Alert Strip */}
        {!isOnline && (
          <div className="fixed top-0 inset-x-0 z-50 bg-amber-500 text-white text-xs font-bold py-1.5 px-4 text-center flex items-center justify-center gap-2 shadow-md">
            <WifiOff className="w-3.5 h-3.5" />
            <span>Offline Mode Active — Using cached clinical records.</span>
          </div>
        )}

        {/* Email Verification Warning Banner if not verified */}
        {currentUser.id !== 'guest' && !currentUser.isEmailVerified && (
          <div className="bg-amber-100 text-amber-900 border-b border-amber-200 px-4 py-2 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>Your email address is unverified. Verify now to receive appointment updates.</span>
            </div>
            <button
              onClick={() => handleOpenAuth('verify')}
              className="px-2.5 py-0.5 bg-amber-600 hover:bg-amber-700 text-white rounded font-bold text-[11px]"
            >
              Verify Code
            </button>
          </div>
        )}

        {/* Main Navbar */}
        <Navbar
          currentView={currentView}
          onNavigate={handleNavigate}
          currentUser={currentUser}
          onRoleSwitch={handleRoleSwitch}
          onOpenDisclaimer={() => setDisclaimerOpen(true)}
          onOpenAuth={handleOpenAuth}
          onLogout={handleLogout}
        />

        {/* Main Content Area */}
        <main className="flex-1 w-full" id="main-content">
          {renderView()}
        </main>

        {/* Footer */}
        <Footer
          onNavigate={handleNavigate}
          onOpenDisclaimer={() => setDisclaimerOpen(true)}
        />

        {/* Medical Safety Disclaimer Modal */}
        <MedicalDisclaimerModal
          isOpen={disclaimerOpen}
          onClose={() => setDisclaimerOpen(false)}
        />

        {/* Authentication & Verification Modal */}
        <AuthModal
          isOpen={authModalOpen}
          initialMode={authModalMode}
          onClose={() => setAuthModalOpen(false)}
          onSuccess={handleAuthSuccess}
        />

        {/* Mobile Bottom Navigation Bar */}
        <nav
          aria-label="Mobile Bottom Navigation"
          className="lg:hidden fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur-md border-t border-slate-200 z-40 px-3 py-1.5 flex items-center justify-around shadow-lg"
        >
          <button
            onClick={() => handleNavigate('home')}
            className={`flex flex-col items-center py-1 px-2 text-[10px] font-semibold transition ${
              currentView === 'home' ? 'text-teal-600' : 'text-slate-500'
            }`}
          >
            <Home className="w-4 h-4 mb-0.5" />
            <span>Home</span>
          </button>

          <button
            onClick={() => handleNavigate('analysis')}
            className={`flex flex-col items-center py-1 px-2 text-[10px] font-semibold transition ${
              currentView === 'analysis' || currentView === 'results' ? 'text-teal-600' : 'text-slate-500'
            }`}
          >
            <div className="w-6 h-6 rounded-full bg-teal-600 text-white flex items-center justify-center -mt-2 mb-0.5 shadow-sm">
              <Scan className="w-3.5 h-3.5" />
            </div>
            <span>Scan</span>
          </button>

          <button
            onClick={() => handleNavigate('doctors')}
            className={`flex flex-col items-center py-1 px-2 text-[10px] font-semibold transition ${
              currentView === 'doctors' || currentView === 'doctor-profile' || currentView === 'booking'
                ? 'text-teal-600'
                : 'text-slate-500'
            }`}
          >
            <Users className="w-4 h-4 mb-0.5" />
            <span>Doctors</span>
          </button>

          <button
            onClick={() => handleNavigate('appointments')}
            className={`flex flex-col items-center py-1 px-2 text-[10px] font-semibold transition ${
              currentView === 'appointments' ? 'text-teal-600' : 'text-slate-500'
            }`}
          >
            <Calendar className="w-4 h-4 mb-0.5" />
            <span>Visits</span>
          </button>

          <button
            onClick={() => handleNavigate('dashboard')}
            className={`flex flex-col items-center py-1 px-2 text-[10px] font-semibold transition ${
              currentView === 'dashboard' ? 'text-teal-600' : 'text-slate-500'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 mb-0.5" />
            <span>Portal</span>
          </button>
        </nav>
      </div>
    </ErrorBoundary>
  );
}
