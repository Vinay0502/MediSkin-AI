import React, { useState } from 'react';
import {
  Scan,
  ShieldCheck,
  Calendar,
  CheckCircle,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  HeartPulse,
  Eye,
} from 'lucide-react';

interface Props {
  onComplete: () => void;
  onNavigate: (view: string) => void;
}

export const OnboardingView: React.FC<Props> = ({ onComplete, onNavigate }) => {
  const [step, setStep] = useState<number>(1);

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden p-6 sm:p-10 space-y-8">
        {/* Progress header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-teal-600 text-white text-xs font-bold flex items-center justify-center">
              {step}
            </span>
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Step {step} of 3</span>
          </div>

          <button
            onClick={onComplete}
            className="text-xs text-slate-400 hover:text-slate-600 font-medium"
          >
            Skip Tutorial
          </button>
        </div>

        {/* Step 1: Capture Technique */}
        {step === 1 && (
          <div className="space-y-6 text-center sm:text-left">
            <div className="w-16 h-16 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center mx-auto sm:mx-0">
              <Scan className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl font-black text-slate-900">
                1. Capturing Quality Skin Photos
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                MediSkin AI's deep learning model relies on sharp optical focus and consistent illumination to detect lesion characteristics accurately.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-slate-700">
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                <span className="font-bold block text-teal-800">Even Indirect Lighting</span>
                <p className="text-[11px] text-slate-500">Avoid harsh flash reflections and heavy deep shadows.</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                <span className="font-bold block text-teal-800">Sharp Focus (Laplacian)</span>
                <p className="text-[11px] text-slate-500">Hold device steady 4–6 inches away from the lesion.</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                <span className="font-bold block text-teal-800">Clear Framing</span>
                <p className="text-[11px] text-slate-500">Keep the entire mole centered in the image frame.</p>
              </div>
            </div>
          </div>
        )}

        {/* Step 2: Clinical Understanding */}
        {step === 2 && (
          <div className="space-y-6 text-center sm:text-left">
            <div className="w-16 h-16 rounded-2xl bg-sky-100 text-sky-700 flex items-center justify-center mx-auto sm:mx-0">
              <ShieldCheck className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl font-black text-slate-900">
                2. Preliminary AI Screening Scope
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                MediSkin AI is an educational triage tool benchmarked on the HAM10000 archive. It does not replace a clinical biopsy or doctor's judgment.
              </p>
            </div>

            <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-amber-950 text-xs space-y-1.5">
              <p className="font-bold">Explainable AI & Safety Principles:</p>
              <ul className="list-disc list-inside space-y-1 text-[11px] text-amber-900">
                <li>Grad-CAM heatmaps highlight which visual borders influenced the classification.</li>
                <li>Ambiguous or borderline photos trigger explicit clinical uncertainty warnings.</li>
                <li>Any rapidly growing or bleeding spots must be evaluated by a dermatologist.</li>
              </ul>
            </div>
          </div>
        )}

        {/* Step 3: Fast Scheduling */}
        {step === 3 && (
          <div className="space-y-6 text-center sm:text-left">
            <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto sm:mx-0">
              <Calendar className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h2 className="text-2xl font-black text-slate-900">
                3. Seamless Specialist Care
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                Connect with board-certified dermatologists for in-person clinic visits or video telehealth consultations in under two minutes.
              </p>
            </div>

            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-2 text-slate-600">
              <div className="flex items-center gap-2 text-slate-900 font-bold">
                <CheckCircle className="w-4 h-4 text-teal-600" />
                <span>You're ready to get started!</span>
              </div>
              <p className="text-[11px]">
                Your privacy is protected. Screening photos are processed locally on your device under strict patient consent.
              </p>
            </div>
          </div>
        )}

        {/* Footer controls */}
        <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
          {step > 1 ? (
            <button
              onClick={() => setStep(step - 1)}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl flex items-center gap-1.5"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>Back</span>
            </button>
          ) : (
            <div />
          )}

          {step < 3 ? (
            <button
              onClick={() => setStep(step + 1)}
              className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs transition"
            >
              <span>Next</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={() => {
                onComplete();
                onNavigate('analysis');
              }}
              className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-md shadow-teal-600/25 transition active:scale-95"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>Start First Screening</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
