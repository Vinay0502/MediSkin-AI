import React, { useState } from 'react';
import {
  Search,
  BookOpen,
  AlertTriangle,
  ShieldCheck,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Clock,
  Sparkles,
} from 'lucide-react';
import { SkinConditionDetail } from '../types/index.ts';

interface Props {
  conditions: SkinConditionDetail[];
  initialConditionId?: string;
  onNavigate: (view: string, params?: Record<string, any>) => void;
}

export const ConditionLibraryView: React.FC<Props> = ({
  conditions,
  initialConditionId,
  onNavigate,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [expandedId, setExpandedId] = useState<string | null>(initialConditionId || conditions[0]?.id || null);

  const categories = ['all', 'Malignant', 'Pre-Malignant', 'Benign', 'Inflammatory'];

  const filteredConditions = conditions.filter((c) => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.medicalName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.summary.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || c.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header */}
      <div className="max-w-3xl">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-600 block mb-1">
          Dermatological Reference Atlas
        </span>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          Skin Condition Medical Library
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
          Peer-reviewed medical descriptions, clinical presentation signs, risk factors, and dermoscopic hallmarks grounded in the American Academy of Dermatology (AAD) and ISIC archives.
        </p>
      </div>

      {/* Filter / Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search by condition name, medical terminology, or symptom..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-teal-500 focus:bg-white outline-none"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                  selectedCategory === cat
                    ? 'bg-teal-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {cat === 'all' ? 'All Classes' : cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Conditions Accordion List */}
      <div className="space-y-4">
        {filteredConditions.map((condition) => {
          const isExpanded = expandedId === condition.id;
          return (
            <div
              key={condition.id}
              className={`bg-white rounded-2xl border transition overflow-hidden ${
                isExpanded ? 'border-teal-500 shadow-md ring-2 ring-teal-500/10' : 'border-slate-200 shadow-xs'
              }`}
            >
              {/* Accordion Summary Row */}
              <button
                onClick={() => setExpandedId(isExpanded ? null : condition.id)}
                className="w-full p-5 text-left flex items-start sm:items-center justify-between gap-4 hover:bg-slate-50/50 transition"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs font-bold text-teal-700 bg-teal-50 px-2 py-0.5 rounded">
                      {condition.code}
                    </span>
                    <h3 className="font-extrabold text-base text-slate-900">{condition.name}</h3>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                      condition.category === 'Malignant'
                        ? 'bg-rose-100 text-rose-800'
                        : condition.category === 'Pre-Malignant'
                        ? 'bg-amber-100 text-amber-800'
                        : condition.category === 'Inflammatory'
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {condition.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 italic">{condition.medicalName}</p>
                </div>

                <div className="p-1 text-slate-400 shrink-0">
                  {isExpanded ? <ChevronUp className="w-5 h-5 text-teal-600" /> : <ChevronDown className="w-5 h-5" />}
                </div>
              </button>

              {/* Accordion Expanded Detail Body */}
              {isExpanded && (
                <div className="px-5 pb-6 pt-2 border-t border-slate-100 space-y-5 text-xs text-slate-600 leading-relaxed">
                  <p className="text-slate-700 text-xs sm:text-sm font-normal">
                    {condition.summary}
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Common Signs */}
                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
                      <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
                        Common Clinical Signs
                      </h4>
                      <ul className="space-y-1 list-disc list-inside text-[11px] text-slate-600">
                        {condition.commonSigns.map((sign, idx) => (
                          <li key={idx}>{sign}</li>
                        ))}
                      </ul>
                    </div>

                    {/* Dermoscopic Features */}
                    <div className="p-4 bg-slate-50 rounded-xl border border-slate-100 space-y-2">
                      <h4 className="font-bold text-slate-900 uppercase tracking-wider text-[11px]">
                        Dermoscopic Hallmarks
                      </h4>
                      <ul className="space-y-1 list-disc list-inside text-[11px] text-slate-600">
                        {condition.dermoscopicFeatures.map((feat, idx) => (
                          <li key={idx}>{feat}</li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Urgency Recommendation */}
                  <div className="p-3.5 bg-teal-50/70 border border-teal-200 rounded-xl text-teal-950 flex items-start gap-2.5">
                    <ShieldCheck className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold uppercase tracking-wider text-[10px] text-teal-800 block">
                        Clinical Guidance
                      </span>
                      <p className="text-[11px] mt-0.5">{condition.urgencyRecommendation}</p>
                    </div>
                  </div>

                  {/* Sources & Last Reviewed */}
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-3 border-t border-slate-100 text-[11px] text-slate-400">
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="font-semibold text-slate-500">Peer Sources:</span>
                      {condition.sources.map((src, idx) => (
                        <a
                          key={idx}
                          href={src.url}
                          target="_blank"
                          rel="noreferrer"
                          className="text-teal-600 hover:underline flex items-center gap-0.5"
                        >
                          <span>{src.title}</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      ))}
                    </div>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /> Reviewed: {condition.lastReviewed}
                    </span>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
