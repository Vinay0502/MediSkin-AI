import React from 'react';
import { ArrowLeft, AlertTriangle } from 'lucide-react';

interface Props {
  onBack: () => void;
}

export const TermsOfServiceView: React.FC<Props> = ({ onBack }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Return to Application</span>
      </button>

      <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 shadow-sm space-y-6 text-xs text-slate-600 leading-relaxed">
        <div className="space-y-1 pb-4 border-b border-slate-100">
          <span className="text-[10px] font-bold uppercase tracking-wider text-teal-600">
            Legal Terms & Regulatory Notice
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
            Terms of Service & Medical Disclaimer
          </h1>
          <p className="text-xs text-slate-400">Effective Date: October 20, 2026</p>
        </div>

        <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-amber-950 font-medium">
          CRITICAL: MediSkin AI is an educational preliminary screening platform. It does NOT provide a definitive medical diagnosis and is not cleared by regulatory agencies as a standalone medical diagnostic device.
        </div>

        <section className="space-y-2">
          <h2 className="text-sm font-bold text-slate-900">1. Acceptance of Terms</h2>
          <p>
            By accessing or utilizing the MediSkin AI platform, mobile web application, or appointment scheduling features, you acknowledge and agree to be bound by these Terms of Service.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-bold text-slate-900">2. Emergency Situations</h2>
          <p>
            DO NOT USE MEDISKIN AI FOR MEDICAL EMERGENCIES. If you are experiencing sudden, severe bleeding, spreading infection, or acute distress, call 911 or proceed immediately to the nearest hospital emergency room.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-bold text-slate-900">3. Non-Establishment of Doctor-Patient Relationship</h2>
          <p>
            The generation of automated classification metrics, Grad-CAM attention heatmaps, or ABCDE risk ratings does not constitute a doctor-patient relationship. A formal relationship is created only when a consultation is confirmed with an independent licensed healthcare provider.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-bold text-slate-900">4. Limitation of Liability</h2>
          <p>
            To the maximum extent permitted by applicable law, MediSkin AI and its operators shall not be liable for any indirect, incidental, or consequential damages resulting from user reliance on preliminary screening heuristics.
          </p>
        </section>
      </div>
    </div>
  );
};
