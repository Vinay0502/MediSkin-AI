import React, { useState } from 'react';
import {
  CompleteScreeningReport,
} from '../services/aiVisionEngine.ts';
import {
  AlertTriangle,
  CheckCircle,
  ShieldAlert,
  Calendar,
  Building2,
  Eye,
  Sliders,
  Layers,
  FileDown,
  RotateCcw,
  Sparkles,
  Info,
  ExternalLink,
  BookOpen,
  Printer,
  Share2,
  Check,
  Loader2,
} from 'lucide-react';
import { exportScreeningReportToPdf } from '../utils/pdfExport.ts';
import { db } from '../services/db.ts';
import { UserProfile } from '../types/index.ts';

interface Props {
  report: CompleteScreeningReport;
  rawImageUrl: string;
  currentUser?: UserProfile;
  onNavigate: (view: string, params?: Record<string, any>) => void;
  onOpenDisclaimer: () => void;
}

export const ResultsView: React.FC<Props> = ({
  report,
  rawImageUrl,
  currentUser,
  onNavigate,
  onOpenDisclaimer,
}) => {
  const [heatmapOpacity, setHeatmapOpacity] = useState<number>(65);
  const [showHeatmap, setShowHeatmap] = useState<boolean>(true);
  const [isExportingPdf, setIsExportingPdf] = useState<boolean>(false);
  const [exportedFilename, setExportedFilename] = useState<string | null>(null);

  const { screeningResult, qualityReport, features, abcdeAnalysis } = report;
  const primary = screeningResult.primaryCondition;
  const activeUser = currentUser || db.getCurrentUser();

  const handleExportPdf = async () => {
    try {
      setIsExportingPdf(true);
      const res = await exportScreeningReportToPdf({
        report,
        rawImageUrl,
        patient: activeUser,
        referenceId: `MS-${Date.now().toString().slice(-6)}`,
      });
      if (res.success) {
        setExportedFilename(res.filename);
        setTimeout(() => setExportedFilename(null), 6000);
      }
    } catch (err) {
      console.error('PDF export error:', err);
      // Fallback to browser print if canvas or jsPDF encounters any issue
      window.print();
    } finally {
      setIsExportingPdf(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleBookWithResults = () => {
    const reason = primary
      ? `AI Screening Triage: ${primary.conditionName} (${screeningResult.calibratedConfidence}% conf). Urgency: ${screeningResult.clinicalUrgency}. ABCDE Score: ${abcdeAnalysis.totalScore}/10.`
      : 'Skin lesion evaluation and dermatological screening.';
    onNavigate('doctors', { prefilledReason: reason });
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Top Banner & Quick Actions */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 bg-teal-100 text-teal-800 text-[11px] font-bold uppercase tracking-wider rounded-md">
              Screening Report
            </span>
            <span className="text-xs text-slate-400">Ref ID: {Date.now().toString().slice(-6)}</span>
          </div>
          <h1 className="text-2xl font-black text-slate-900 mt-1">
            Preliminary Lesion Classification
          </h1>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => onNavigate('analysis')}
            className="px-3.5 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Screen Another</span>
          </button>
          
          <button
            onClick={handlePrint}
            className="px-3 py-2 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition"
            title="Print report directly"
          >
            <Printer className="w-3.5 h-3.5 text-slate-500" />
            <span className="hidden sm:inline">Print</span>
          </button>

          <button
            onClick={handleExportPdf}
            disabled={isExportingPdf}
            className="px-4 py-2 bg-teal-700 hover:bg-teal-800 disabled:bg-teal-400 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition active:scale-95 cursor-pointer"
          >
            {isExportingPdf ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span>Generating PDF...</span>
              </>
            ) : (
              <>
                <FileDown className="w-3.5 h-3.5 text-teal-200" />
                <span>Export Medical PDF</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* PDF Downloaded Success Toast */}
      {exportedFilename && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 text-emerald-900 rounded-2xl flex items-center justify-between text-xs animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
            <div>
              <span className="font-bold">Medical Screening Report Exported! </span>
              <span className="text-emerald-700 font-mono text-[11px]">({exportedFilename})</span>
              <p className="text-[11px] text-emerald-800">
                You can now email or bring this PDF document to your dermatologist consultation.
              </p>
            </div>
          </div>
          <button
            onClick={() => setExportedFilename(null)}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-900 px-2 py-1"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Uncertainty or Borderline Quality Warning Banner */}
      {screeningResult.uncertaintyFlag && (
        <div className="p-4 bg-amber-50 rounded-2xl border border-amber-200 text-amber-900 flex items-start gap-3 text-xs leading-relaxed">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold text-amber-950">Classification Uncertainty Flag Active</p>
            <p>{screeningResult.uncertaintyMessage}</p>
            <p className="text-[11px] text-amber-800 font-medium pt-1">
              Safety rule: MediSkin AI does not force definitive classifications on ambiguous optical presentations. An in-person dermoscopic exam is advised.
            </p>
          </div>
        </div>
      )}

      {/* Primary Result & Urgency Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Visual Saliency / Heatmap Inspector */}
        <div className="lg:col-span-5 bg-white rounded-3xl border border-slate-200 shadow-sm p-5 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-teal-600" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
                Explainable AI (Grad-CAM)
              </h3>
            </div>
            <label className="flex items-center gap-1.5 cursor-pointer text-xs font-medium text-slate-600">
              <input
                type="checkbox"
                checked={showHeatmap}
                onChange={(e) => setShowHeatmap(e.target.checked)}
                className="rounded text-teal-600"
              />
              <span>Heatmap Overlay</span>
            </label>
          </div>

          {/* Dual Layer Canvas / Image Preview */}
          <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-slate-950 border border-slate-200 shadow-inner flex items-center justify-center">
            {/* Base Image */}
            <img
              src={rawImageUrl}
              alt="Uploaded skin lesion"
              className="absolute inset-0 w-full h-full object-cover"
            />

            {/* Grad-CAM Saliency Overlay */}
            {showHeatmap && report.heatmapDataUrl && (
              <img
                src={report.heatmapDataUrl}
                alt="Grad-CAM activation heatmap"
                className="absolute inset-0 w-full h-full object-cover mix-blend-screen pointer-events-none transition-opacity duration-150"
                style={{ opacity: heatmapOpacity / 100 }}
              />
            )}

            {/* Heatmap Legend Overlay Badge */}
            <div className="absolute top-2 left-2 px-2.5 py-1 bg-black/70 backdrop-blur-xs rounded-md text-[10px] text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              <span>Model Attention Hotspots</span>
            </div>
          </div>

          {/* Opacity Control Slider */}
          {showHeatmap && (
            <div className="space-y-1.5 bg-slate-50 p-3 rounded-xl border border-slate-100">
              <div className="flex items-center justify-between text-xs text-slate-600 font-medium">
                <span className="flex items-center gap-1">
                  <Sliders className="w-3.5 h-3.5 text-teal-600" /> Heatmap Intensity
                </span>
                <span className="font-mono text-teal-700">{heatmapOpacity}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={heatmapOpacity}
                onChange={(e) => setHeatmapOpacity(Number(e.target.value))}
                className="w-full accent-teal-600 cursor-pointer h-1.5 bg-slate-200 rounded-lg"
              />
              <p className="text-[10px] text-slate-400">
                Red and amber regions represent high feature gradients (asymmetry & border variations) driving the classification head.
              </p>
            </div>
          )}

          {/* Optical Quality Metadata */}
          <div className="text-xs space-y-1.5 pt-2 border-t border-slate-100 text-slate-500">
            <div className="flex justify-between">
              <span>Sharpness Score:</span>
              <span className="font-semibold text-slate-800">{qualityReport.score}/100 (Laplacian: {report.qualityReport.issues.length === 0 ? 'Optimal' : 'Adequate'})</span>
            </div>
            <div className="flex justify-between">
              <span>Estimated Diameter:</span>
              <span className="font-semibold text-slate-800">{features.diameterMm} mm</span>
            </div>
            <div className="flex justify-between">
              <span>Asymmetry Index:</span>
              <span className="font-semibold text-slate-800">{features.asymmetryScore} (0.0 - 1.0)</span>
            </div>
          </div>
        </div>

        {/* Right Column: Clinical Classification & Action Recommendations */}
        <div className="lg:col-span-7 space-y-6">
          {/* Main Classification Card */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                  primary?.category === 'Malignant'
                    ? 'bg-rose-100 text-rose-800 border border-rose-200'
                    : primary?.category === 'Pre-Malignant'
                    ? 'bg-amber-100 text-amber-800 border border-amber-200'
                    : 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                }`}>
                  {primary?.category || 'Unclassified'} Lesion
                </span>
                <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                  {primary?.conditionName || 'Indeterminate Presentation'}
                </h2>
              </div>

              {/* Confidence Score Ring */}
              <div className="text-right shrink-0">
                <span className="text-2xl font-black text-teal-600">
                  {screeningResult.calibratedConfidence}%
                </span>
                <span className="block text-[10px] text-slate-400 font-medium">Calibrated Conf.</span>
              </div>
            </div>

            {/* Urgency Guidance Strip */}
            <div className={`p-3.5 rounded-2xl flex items-center justify-between text-xs font-semibold ${
              screeningResult.clinicalUrgency === 'urgent'
                ? 'bg-rose-50 text-rose-900 border border-rose-200'
                : screeningResult.clinicalUrgency === 'high'
                ? 'bg-amber-50 text-amber-900 border border-amber-200'
                : 'bg-emerald-50 text-emerald-900 border border-emerald-200'
            }`}>
              <div className="flex items-center gap-2">
                <ShieldAlert className={`w-4 h-4 ${
                  screeningResult.clinicalUrgency === 'urgent' ? 'text-rose-600' : 'text-amber-600'
                }`} />
                <span>Recommended Action: {screeningResult.recommendedAction}</span>
              </div>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-white/80">
                {screeningResult.clinicalUrgency} Priority
              </span>
            </div>

            {/* Top Differential Predictions (Model Probabilities) */}
            <div className="space-y-2 pt-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                Top Differential Classifications
              </h4>
              <div className="space-y-2">
                {screeningResult.topDifferentials.map((item) => (
                  <div key={item.conditionId} className="space-y-1 text-xs">
                    <div className="flex justify-between font-medium">
                      <span className="text-slate-800">{item.conditionName} ({item.category})</span>
                      <span className="text-slate-500 font-mono">{Math.round(item.probability * 100)}%</span>
                    </div>
                    <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          item.category === 'Malignant'
                            ? 'bg-rose-500'
                            : item.category === 'Pre-Malignant'
                            ? 'bg-amber-500'
                            : 'bg-teal-500'
                        }`}
                        style={{ width: `${Math.round(item.probability * 100)}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* ABCDE Dermoscopic Criteria Checklist */}
            <div className="pt-3 border-t border-slate-100 space-y-2">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                  ABCDE Dermoscopy Assessment
                </h4>
                <span className={`text-xs font-bold ${
                  abcdeAnalysis.riskRating === 'High' ? 'text-rose-600' : abcdeAnalysis.riskRating === 'Moderate' ? 'text-amber-600' : 'text-emerald-600'
                }`}>
                  Risk Rating: {abcdeAnalysis.riskRating} ({abcdeAnalysis.totalScore}/10 pts)
                </span>
              </div>

              <div className="space-y-1.5 text-xs text-slate-600">
                {abcdeAnalysis.flaggedItems.length === 0 ? (
                  <p className="text-slate-400 italic">No concerning ABCDE irregularities detected.</p>
                ) : (
                  abcdeAnalysis.flaggedItems.map((item, idx) => (
                    <div key={idx} className="flex items-start gap-2 bg-slate-50 p-2 rounded-lg">
                      <span className="w-1.5 h-1.5 rounded-full bg-teal-600 mt-1.5 shrink-0" />
                      <span className="text-[11px]">{item}</span>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Healthcare Action Buttons */}
            <div className="pt-4 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                onClick={handleBookWithResults}
                className="py-3 px-4 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-md shadow-teal-600/20 transition flex items-center justify-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                <span>Book Dermatologist Consultation</span>
              </button>

              <button
                onClick={() => onNavigate('hospitals')}
                className="py-3 px-4 bg-white hover:bg-slate-50 border border-slate-300 text-slate-800 font-semibold text-xs rounded-xl shadow-xs transition flex items-center justify-center gap-2"
              >
                <Building2 className="w-4 h-4 text-teal-600" />
                <span>Find Nearby Clinic</span>
              </button>
            </div>
          </div>

          {/* Medical Library Quick Link */}
          {primary && (
            <div className="p-4 bg-teal-50/60 rounded-2xl border border-teal-200/80 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2.5">
                <BookOpen className="w-4 h-4 text-teal-700 shrink-0" />
                <div>
                  <p className="font-bold text-teal-950">Learn more about {primary.conditionName}</p>
                  <p className="text-[11px] text-teal-800">
                    Review symptoms, dermoscopic hallmarks, and prevention in the Medical Library.
                  </p>
                </div>
              </div>
              <button
                onClick={() => onNavigate('library', { conditionId: primary.conditionId })}
                className="px-3 py-1.5 bg-teal-700 text-white font-semibold rounded-lg hover:bg-teal-800 shrink-0 transition"
              >
                View Atlas
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
