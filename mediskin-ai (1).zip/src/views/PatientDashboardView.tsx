import React, { useState } from 'react';
import {
  Scan,
  Calendar,
  Clock,
  Trash2,
  ExternalLink,
  ShieldAlert,
  ArrowRight,
  BookOpen,
  User,
  Activity,
  FileDown,
  Loader2,
  Check,
} from 'lucide-react';
import { UserProfile, ScreeningHistoryItem } from '../types/index.ts';
import { db } from '../services/db.ts';
import { exportSavedScreeningToPdf } from '../utils/pdfExport.ts';

interface Props {
  currentUser: UserProfile;
  onNavigate: (view: string, params?: Record<string, any>) => void;
}

export const PatientDashboardView: React.FC<Props> = ({ currentUser, onNavigate }) => {
  const [screenings, setScreenings] = useState<ScreeningHistoryItem[]>(
    db.getScreeningHistory(currentUser.id)
  );
  const [exportingId, setExportingId] = useState<string | null>(null);
  const [exportSuccessMsg, setExportSuccessMsg] = useState<string | null>(null);

  const appointments = db.getAppointments({ userId: currentUser.id, role: 'patient' });
  const upcomingAppointments = appointments.filter((a) => a.status === 'Confirmed' || a.status === 'Pending');

  const handleExportSingle = async (rec: ScreeningHistoryItem) => {
    try {
      setExportingId(rec.id);
      const res = await exportSavedScreeningToPdf(rec, currentUser);
      if (res.success) {
        setExportSuccessMsg(`Exported report: ${res.filename}`);
        setTimeout(() => setExportSuccessMsg(null), 5000);
      }
    } catch (err) {
      console.error('Failed to export PDF:', err);
    } finally {
      setExportingId(null);
    }
  };

  const [deletingScreeningId, setDeletingScreeningId] = useState<string | null>(null);

  const handleConfirmDeleteScreening = () => {
    if (!deletingScreeningId) return;
    db.deleteScreeningRecord(deletingScreeningId);
    setScreenings(db.getScreeningHistory(currentUser.id));
    setDeletingScreeningId(null);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-teal-700 via-teal-800 to-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1.5">
          <span className="text-xs font-bold uppercase tracking-wider text-teal-300">
            Patient Health Dashboard
          </span>
          <h1 className="text-2xl sm:text-3xl font-black">
            Welcome back, {currentUser.name}
          </h1>
          <p className="text-xs sm:text-sm text-teal-100 max-w-xl">
            Review your preliminary AI skin screenings, upcoming dermatologist consultations, and preventive clinical guidance in one private hub.
          </p>
        </div>

        <div className="flex gap-2 shrink-0">
          <button
            onClick={() => onNavigate('analysis')}
            className="px-5 py-3 bg-white text-teal-900 hover:bg-teal-50 font-bold text-xs rounded-xl shadow-md transition flex items-center gap-2 active:scale-95"
          >
            <Scan className="w-4 h-4 text-teal-600" />
            <span>New Skin Screening</span>
          </button>
        </div>
      </div>

      {/* Grid: Upcoming Appointments & Quick Stats */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upcoming Appointments Column */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Calendar className="w-4 h-4 text-teal-600" />
              <span>Upcoming Consultations ({upcomingAppointments.length})</span>
            </h3>
            <button
              onClick={() => onNavigate('appointments')}
              className="text-xs font-semibold text-teal-700 hover:underline"
            >
              View All
            </button>
          </div>

          {upcomingAppointments.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500 bg-slate-50 rounded-2xl">
              No upcoming appointments. Scheduled appointments will appear here.
            </div>
          ) : (
            <div className="space-y-3">
              {upcomingAppointments.slice(0, 3).map((app) => (
                <div
                  key={app.id}
                  className="p-4 rounded-2xl border border-slate-100 bg-slate-50/70 hover:bg-slate-50 transition flex items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{app.doctorName}</span>
                      <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                        app.status === 'Confirmed' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {app.status}
                      </span>
                    </div>
                    <p className="text-slate-500">{app.specialty} • {app.mode}</p>
                    <p className="text-teal-700 font-semibold">{app.date} at {app.timeSlot}</p>
                  </div>

                  <button
                    onClick={() => onNavigate('appointments')}
                    className="px-3 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 rounded-lg text-xs font-semibold text-slate-700 shadow-xs"
                  >
                    Manage
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Quick Health Actions Card */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
          <h3 className="font-bold text-slate-900 text-sm">Patient Care Shortcuts</h3>
          <div className="space-y-2.5 text-xs">
            <button
              onClick={() => onNavigate('doctors')}
              className="w-full p-3 bg-slate-50 hover:bg-teal-50 border border-slate-100 hover:border-teal-200 rounded-xl text-left font-semibold text-slate-700 hover:text-teal-900 transition flex items-center justify-between"
            >
              <span>Find a Dermatologist</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
            </button>
            <button
              onClick={() => onNavigate('hospitals')}
              className="w-full p-3 bg-slate-50 hover:bg-teal-50 border border-slate-100 hover:border-teal-200 rounded-xl text-left font-semibold text-slate-700 hover:text-teal-900 transition flex items-center justify-between"
            >
              <span>Locate Nearby Clinics</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
            </button>
            <button
              onClick={() => onNavigate('library')}
              className="w-full p-3 bg-slate-50 hover:bg-teal-50 border border-slate-100 hover:border-teal-200 rounded-xl text-left font-semibold text-slate-700 hover:text-teal-900 transition flex items-center justify-between"
            >
              <span>Explore Condition Atlas</span>
              <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
            </button>
          </div>

          <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-400 leading-relaxed">
            All screening records are stored locally on your device under strict patient consent.
          </div>
        </div>
      </div>

      {/* Saved Screening History */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-slate-900 text-base">Saved Skin Screening Reports</h3>
            <p className="text-xs text-slate-400">Past AI-assisted evaluation snapshots</p>
          </div>
          <span className="text-xs text-slate-400">{screenings.length} records saved</span>
        </div>

        {/* Export Success Notification */}
        {exportSuccessMsg && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{exportSuccessMsg}</span>
            </div>
            <button onClick={() => setExportSuccessMsg(null)} className="font-bold hover:underline">
              Dismiss
            </button>
          </div>
        )}

        {screenings.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500 bg-slate-50 rounded-2xl space-y-2">
            <p>No skin screenings performed yet.</p>
            <button
              onClick={() => onNavigate('analysis')}
              className="px-4 py-2 bg-teal-600 text-white rounded-xl font-semibold"
            >
              Perform First Screening
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {screenings.map((rec) => (
              <div
                key={rec.id}
                className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 hover:bg-slate-50 transition flex items-start justify-between gap-4 text-xs"
              >
                <div className="flex items-start gap-3">
                  {rec.imageUrl && (
                    <img
                      src={rec.imageUrl}
                      alt={rec.conditionName}
                      className="w-14 h-14 rounded-xl object-cover border border-slate-200 shrink-0"
                    />
                  )}
                  <div className="space-y-0.5">
                    <span className="font-bold text-slate-900 block text-sm">{rec.conditionName}</span>
                    <span className="text-slate-500 block">{rec.category} • {rec.confidence}% confidence</span>
                    <span className={`inline-block px-1.5 py-0.2 rounded text-[10px] font-semibold mt-1 ${
                      rec.urgency === 'urgent'
                        ? 'bg-rose-100 text-rose-800'
                        : rec.urgency === 'high'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}>
                      {rec.urgency} Urgency
                    </span>
                    <span className="text-[10px] text-slate-400 block pt-0.5">
                      {new Date(rec.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleExportSingle(rec)}
                    disabled={exportingId === rec.id}
                    className="p-2 text-teal-700 hover:text-teal-900 hover:bg-teal-50 rounded-lg transition"
                    title="Export medical PDF report"
                  >
                    {exportingId === rec.id ? (
                      <Loader2 className="w-4 h-4 animate-spin text-teal-600" />
                    ) : (
                      <FileDown className="w-4 h-4" />
                    )}
                  </button>

                  <button
                    onClick={() => setDeletingScreeningId(rec.id)}
                    className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                    title="Delete record"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Delete Screening Confirmation Modal */}
      {deletingScreeningId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-bold text-slate-900 text-base">Delete Screening Record?</h3>
              <p className="text-xs text-slate-500">
                Are you sure you want to remove this saved screening report? This action cannot be undone.
              </p>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setDeletingScreeningId(null)}
                className="flex-1 py-2.5 border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
              >
                Keep Record
              </button>
              <button
                onClick={handleConfirmDeleteScreening}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
