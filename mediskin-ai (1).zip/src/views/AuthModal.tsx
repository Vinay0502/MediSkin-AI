import React, { useState, useEffect } from 'react';
import {
  Lock,
  Mail,
  User,
  Phone,
  ShieldCheck,
  AlertTriangle,
  X,
  Eye,
  EyeOff,
  CheckCircle,
  Clock,
  ArrowRight,
  KeyRound,
} from 'lucide-react';
import { auth } from '../services/authService.ts';
import { evaluatePasswordStrength, validateEmail } from '../utils/authRules.ts';
import { UserProfile } from '../types/index.ts';

interface Props {
  isOpen: boolean;
  initialMode?: 'login' | 'register' | 'forgot' | 'verify';
  onClose: () => void;
  onSuccess: (user: UserProfile) => void;
}

export const AuthModal: React.FC<Props> = ({
  isOpen,
  initialMode = 'login',
  onClose,
  onSuccess,
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot' | 'verify'>(initialMode);

  // Form fields
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [resetCode, setResetCode] = useState('');
  const [verifyCode, setVerifyCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [rateLimitCountdown, setRateLimitCountdown] = useState(0);

  const switchToMode = (newMode: 'login' | 'register' | 'forgot' | 'verify') => {
    setMode(newMode);
    setErrorMsg(null);
    setSuccessNotice(null);
    setPassword('');
    setConfirmPassword('');
    if (newMode === 'register') {
      setEmail('');
      setName('');
    }
  };

  useEffect(() => {
    setMode(initialMode);
    setErrorMsg(null);
    setSuccessNotice(null);
    setPassword('');
    setConfirmPassword('');
    if (initialMode === 'register') {
      setEmail('');
      setName('');
    }
  }, [initialMode, isOpen]);

  // Rate limiter timer
  useEffect(() => {
    const status = auth.getRateLimitStatus();
    if (status.isLocked) {
      setRateLimitCountdown(status.remainingSeconds);
      const timer = setInterval(() => {
        setRateLimitCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [isOpen, errorMsg]);

  if (!isOpen) return null;

  const passwordStrength = evaluatePasswordStrength(password);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setIsLoading(true);

    try {
      const res = await auth.login(email, password);
      setIsLoading(false);
      if (res.success && res.user) {
        onSuccess(res.user);
        onClose();
      } else {
        setErrorMsg(res.error || 'Login failed.');
      }
    } catch (err: any) {
      setIsLoading(false);
      setErrorMsg(err.message || 'Login failed.');
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (password !== confirmPassword) {
      setErrorMsg('Passwords do not match.');
      return;
    }

    setIsLoading(true);
    try {
      const res = await auth.register({ name, email, password, phone, role: 'patient' });
      setIsLoading(false);
      if (res.success && res.user) {
        setSuccessNotice(`Account created successfully! ${res.verificationCodeDemo ? `(Verification code: ${res.verificationCodeDemo})` : 'Verification code sent.'}`);
        onSuccess(res.user);
        setMode('verify');
      } else {
        setErrorMsg(res.error || 'Registration failed.');
      }
    } catch (err: any) {
      setIsLoading(false);
      setErrorMsg(err.message || 'Registration failed.');
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    setIsLoading(true);
    try {
      const res = await auth.requestPasswordReset(email);
      setIsLoading(false);
      if (res.success) {
        setSuccessNotice(`Reset code sent to ${email} ${res.resetCode ? `(Code: ${res.resetCode})` : ''}.`);
      } else {
        setErrorMsg(res.error || 'Failed to request reset.');
      }
    } catch (err: any) {
      setIsLoading(false);
      setErrorMsg(err.message || 'Failed to request reset.');
    }
  };

  const handleCompleteReset = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    setIsLoading(true);
    try {
      const res = await auth.resetPasswordWithCode(email, resetCode, password);
      setIsLoading(false);
      if (res.success) {
        setSuccessNotice('Password reset successfully! You can now log in.');
        setMode('login');
      } else {
        setErrorMsg(res.error || 'Password reset failed.');
      }
    } catch (err: any) {
      setIsLoading(false);
      setErrorMsg(err.message || 'Password reset failed.');
    }
  };

  const handleVerifyEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    setIsLoading(true);
    try {
      const current = auth.getUsers().find((u) => u.email.toLowerCase() === email.toLowerCase());
      const res = await auth.verifyEmailCode(current?.id || '', verifyCode);
      setIsLoading(false);
      if (res.success) {
        setSuccessNotice('Email address verified successfully!');
        setTimeout(() => onClose(), 1200);
      } else {
        setErrorMsg(res.error || 'Verification code failed.');
      }
    } catch (err: any) {
      setIsLoading(false);
      setErrorMsg(err.message || 'Verification code failed.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden relative">
        {/* Header */}
        <div className="p-6 pb-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-teal-600 text-white flex items-center justify-center shadow-xs">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">
                {mode === 'login' && 'Sign in to MediSkin AI'}
                {mode === 'register' && 'Create Patient Account'}
                {mode === 'forgot' && 'Reset Your Password'}
                {mode === 'verify' && 'Verify Email Address'}
              </h2>
              <p className="text-[11px] text-slate-500">Secure HIPAA-compliant session</p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Rate Limit Lockout Banner */}
          {rateLimitCountdown > 0 && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-2xl flex items-center gap-2 text-rose-900 text-xs">
              <Clock className="w-4 h-4 text-rose-600 shrink-0" />
              <span>Security lockout active. Please wait <strong>{rateLimitCountdown}s</strong> before retry.</span>
            </div>
          )}

          {/* Feedback messages */}
          {errorMsg && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2 text-rose-800 text-xs">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successNotice && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-2 text-emerald-800 text-xs">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{successNotice}</span>
            </div>
          )}

          {/* 1. LOGIN MODE */}
          {mode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-3.5 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="email"
                    required
                    placeholder="patient@mediskin.health"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-teal-500"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="font-semibold text-slate-700">Password</label>
                  <button
                    type="button"
                    onClick={() => switchToMode('forgot')}
                    className="text-[11px] text-teal-700 hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-9 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-2 focus:ring-teal-500"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600"
                  >
                    {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading || rateLimitCountdown > 0}
                className="w-full py-3 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 text-white font-bold rounded-xl shadow-xs transition"
              >
                {isLoading ? 'Signing In...' : 'Sign In'}
              </button>

              {/* 1-Click Test Credentials */}
              <div className="pt-2 border-t border-slate-100">
                <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 text-center mb-1.5">
                  1-Click Test Accounts (Persistent SQLite)
                </p>
                <div className="grid grid-cols-3 gap-1.5 text-[11px]">
                  <button
                    type="button"
                    onClick={() => {
                      setEmail('patient@mediskin.health');
                      setPassword('PatientSecure123!');
                      setErrorMsg(null);
                    }}
                    className="p-1.5 bg-teal-50 hover:bg-teal-100 text-teal-800 rounded-lg font-semibold text-center transition border border-teal-200/60"
                  >
                    Patient
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEmail('dr.lin@mediskin.health');
                      setPassword('DoctorSecure123!');
                      setErrorMsg(null);
                    }}
                    className="p-1.5 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-lg font-semibold text-center transition border border-blue-200/60"
                  >
                    Doctor
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setEmail('admin@mediskin.health');
                      setPassword('AdminSecure123!');
                      setErrorMsg(null);
                    }}
                    className="p-1.5 bg-purple-50 hover:bg-purple-100 text-purple-800 rounded-lg font-semibold text-center transition border border-purple-200/60"
                  >
                    Admin
                  </button>
                </div>
              </div>

              <div className="text-center pt-1">
                <span className="text-slate-500">Don't have an account? </span>
                <button
                  type="button"
                  onClick={() => switchToMode('register')}
                  className="font-bold text-teal-700 hover:underline"
                >
                  Create one now
                </button>
              </div>
            </form>
          )}

          {/* 2. REGISTER MODE */}
          {mode === 'register' && (
            <form onSubmit={handleRegister} className="space-y-3 text-xs">
              <div>
                <label className="font-semibold text-slate-700 block mb-1">Full Name</label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    placeholder="Jane Doe"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Email Address</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="email"
                    required
                    placeholder="jane@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Password</label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="password"
                    required
                    placeholder="Min 8 chars with number & symbol"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  />
                </div>

                {/* Password Strength Indicator */}
                {password.length > 0 && (
                  <div className="mt-1.5 space-y-1">
                    <div className="flex justify-between text-[10px]">
                      <span className="text-slate-400">Strength:</span>
                      <span className={`font-bold ${
                        passwordStrength.level === 'Strong' ? 'text-emerald-600' : passwordStrength.level === 'Good' ? 'text-teal-600' : 'text-amber-600'
                      }`}>{passwordStrength.level}</span>
                    </div>
                    <div className="w-full bg-slate-200 h-1 rounded-full overflow-hidden">
                      <div
                        className={`h-full transition-all duration-300 ${
                          passwordStrength.score >= 4
                            ? 'bg-emerald-500 w-full'
                            : passwordStrength.score === 3
                            ? 'bg-teal-500 w-3/4'
                            : passwordStrength.score === 2
                            ? 'bg-amber-500 w-1/2'
                            : 'bg-rose-500 w-1/4'
                        }`}
                      />
                    </div>
                  </div>
                )}
              </div>

              <div>
                <label className="font-semibold text-slate-700 block mb-1">Confirm Password</label>
                <input
                  type="password"
                  required
                  placeholder="Repeat password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-xl shadow-xs transition"
              >
                {isLoading ? 'Creating Account...' : 'Register Patient Account'}
              </button>

              <div className="text-center pt-1">
                <span className="text-slate-500">Already registered? </span>
                <button
                  type="button"
                  onClick={() => switchToMode('login')}
                  className="font-bold text-teal-700 hover:underline"
                >
                  Sign in
                </button>
              </div>
            </form>
          )}

          {/* 3. FORGOT PASSWORD MODE */}
          {mode === 'forgot' && (
            <div className="space-y-3.5 text-xs">
              <form onSubmit={handleForgotPassword} className="space-y-3">
                <p className="text-slate-500 text-[11px]">
                  Enter your registered account email. A 6-digit confirmation code will be sent to verify your identity.
                </p>
                <div>
                  <label className="font-semibold text-slate-700 block mb-1">Account Email</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                  />
                </div>
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 bg-slate-900 text-white font-semibold rounded-xl"
                >
                  Send Verification Code
                </button>
              </form>

              {successNotice && (
                <form onSubmit={handleCompleteReset} className="space-y-3 pt-3 border-t border-slate-100">
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">6-Digit Code</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. 938210"
                      value={resetCode}
                      onChange={(e) => setResetCode(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="font-semibold text-slate-700 block mb-1">New Password</label>
                    <input
                      type="password"
                      required
                      placeholder="Enter strong new password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                    />
                  </div>
                  <button
                    type="submit"
                    className="w-full py-2.5 bg-teal-600 text-white font-bold rounded-xl"
                  >
                    Confirm & Update Password
                  </button>
                </form>
              )}

              <button
                type="button"
                onClick={() => switchToMode('login')}
                className="w-full text-center text-slate-400 hover:text-slate-700 text-[11px]"
              >
                Back to Login
              </button>
            </div>
          )}

          {/* 4. VERIFY EMAIL MODE */}
          {mode === 'verify' && (
            <form onSubmit={handleVerifyEmail} className="space-y-3.5 text-xs">
              <p className="text-slate-600 leading-relaxed text-[11px]">
                Please enter the 6-digit verification code sent to your registered email address (or check notifications).
              </p>
              <div>
                <label className="font-semibold text-slate-700 block mb-1">6-Digit Verification Code</label>
                <input
                  type="text"
                  required
                  placeholder="Enter code"
                  value={verifyCode}
                  onChange={(e) => setVerifyCode(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-center font-mono text-base tracking-widest outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-xl shadow-xs transition"
              >
                Verify & Continue
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
