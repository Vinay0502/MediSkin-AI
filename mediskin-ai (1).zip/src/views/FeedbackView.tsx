import React, { useState } from 'react';
import { Star, MessageSquare, CheckCircle, ShieldCheck } from 'lucide-react';
import { UserProfile, UserFeedback } from '../types/index.ts';
import { db } from '../services/db.ts';

interface Props {
  currentUser: UserProfile;
}

export const FeedbackView: React.FC<Props> = ({ currentUser }) => {
  const [feedbacks, setFeedbacks] = useState<UserFeedback[]>(db.getFeedbacks());
  const [rating, setRating] = useState<number>(5);
  const [category, setCategory] = useState<UserFeedback['category']>('Screening Accuracy');
  const [comments, setComments] = useState<string>('');
  const [submitted, setSubmitted] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comments.trim()) return;

    db.submitFeedback({
      userId: currentUser.id,
      userName: currentUser.name,
      rating,
      category,
      comments,
    });

    setFeedbacks(db.getFeedbacks());
    setComments('');
    setSubmitted(true);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      <div className="max-w-2xl">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-600 block mb-1">
          Quality Improvement & Reviews
        </span>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          Patient Feedback & Analytics
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2">
          Your feedback directly guides clinical algorithmic calibration, image quality tuning, and specialist booking UX.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        {/* Form Column */}
        <div className="md:col-span-5 bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
          <h3 className="font-bold text-slate-900 text-sm">Submit Clinical Experience Review</h3>

          {submitted && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900 text-xs flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Thank you! Your feedback has been recorded in the quality registry.</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="font-semibold text-slate-700 block mb-1">Overall Rating</label>
              <div className="flex items-center gap-2">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    type="button"
                    key={star}
                    onClick={() => setRating(star)}
                    className="p-1 hover:scale-110 transition"
                  >
                    <Star
                      className={`w-6 h-6 ${
                        star <= rating
                          ? 'fill-amber-400 stroke-amber-500'
                          : 'stroke-slate-300'
                      }`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Feedback Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
              >
                <option value="Screening Accuracy">Screening Accuracy & Grad-CAM</option>
                <option value="Booking Experience">Specialist Booking Experience</option>
                <option value="UI / Navigation">UI & Mobile Navigation</option>
                <option value="General">General Medical Safety</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 block mb-1">Detailed Remarks</label>
              <textarea
                rows={4}
                required
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                placeholder="Share your experience with image capture, clarity checks, or consultation..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none leading-relaxed"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-teal-600 hover:bg-teal-700 text-white font-bold rounded-xl shadow-xs transition"
            >
              Submit Quality Review
            </button>
          </form>
        </div>

        {/* Reviews List */}
        <div className="md:col-span-7 space-y-3">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
            Recent Patient Feedback ({feedbacks.length})
          </span>

          <div className="space-y-3">
            {feedbacks.map((fb) => (
              <div key={fb.id} className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{fb.userName}</span>
                    <span className="px-2 py-0.5 bg-slate-100 rounded text-[10px] text-slate-600">
                      {fb.category}
                    </span>
                  </div>
                  <div className="flex items-center gap-0.5 text-amber-500">
                    {Array.from({ length: fb.rating }).map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-amber-400 stroke-amber-500" />
                    ))}
                  </div>
                </div>

                <p className="text-slate-600 italic">"{fb.comments}"</p>
                <span className="text-[10px] text-slate-400 block">
                  {new Date(fb.createdAt).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
