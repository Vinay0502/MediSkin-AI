import React, { useState, useRef } from 'react';
import {
  User,
  Mail,
  ShieldCheck,
  AlertTriangle,
  Download,
  Upload,
  Trash2,
  CheckCircle,
  KeyRound,
  FileText,
} from 'lucide-react';
import { UserProfile } from '../types/index.ts';
import { db } from '../services/db.ts';
import { auth } from '../services/authService.ts';

interface Props {
  currentUser: UserProfile;
  onOpenVerifyModal: () => void;
  onNavigate: (view: string) => void;
}

export const SettingsView: React.FC<Props> = ({
  currentUser,
  onOpenVerifyModal,
  onNavigate,
}) => {
  const [feedback, setFeedback] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Delete account modal
  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [deletePassword, setDeletePassword] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExportBackup = () => {
    try {
      const backup = db.exportDatabaseBackup();
      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `mediskin-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setFeedback('Database backup exported and downloaded successfully.');
    } catch (err: any) {
      setErrorMsg(`Backup export failed: ${err.message}`);
    }
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const res = db.restoreDatabaseBackup(content);
      if (res.success) {
        setFeedback('Database successfully restored from backup snapshot.');
        setTimeout(() => window.location.reload(), 1000);
      } else {
        setErrorMsg(res.error || 'Failed to restore backup.');
      }
    };
    reader.readAsText(file);
  };

  const handleDeleteAccount = async () => {
    if (!deletePassword) {
      setErrorMsg('Please enter your account password to confirm deletion.');
      return;
    }

    setIsDeleting(true);
    try {
      const res = await auth.deleteAccount(currentUser.id, deletePassword);
      setIsDeleting(false);
      if (res.success) {
        setShowDeleteModal(false);
        setFeedback('Your account and all associated health records have been permanently purged.');
        setTimeout(() => {
          window.location.href = '/';
        }, 1200);
      } else {
        setErrorMsg(res.error || 'Account deletion failed.');
      }
    } catch (err: any) {
      setIsDeleting(false);
      setErrorMsg(err.message || 'Account deletion failed.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header */}
      <div>
        <span className="text-xs font-bold uppercase tracking-wider text-teal-600 block mb-1">
          Account Governance
        </span>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          Account & Security Settings
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 mt-1">
          Manage your verified credentials, export local medical backups, and exercise data privacy rights.
        </p>
      </div>

      {feedback && (
        <div className="p-3.5 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-900 text-xs flex items-center justify-between">
          <span className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
            {feedback}
          </span>
          <button onClick={() => setFeedback(null)} className="font-bold text-emerald-700 hover:underline">
            Dismiss
          </button>
        </div>
      )}

      {errorMsg && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-2xl text-rose-900 text-xs flex items-center justify-between">
          <span className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            {errorMsg}
          </span>
          <button onClick={() => setErrorMsg(null)} className="font-bold text-rose-700 hover:underline">
            Dismiss
          </button>
        </div>
      )}

      {/* 1. Profile & Verification Status */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
        <h3 className="font-bold text-slate-900 text-sm pb-2 border-b border-slate-100 flex items-center gap-2">
          <User className="w-4 h-4 text-teal-600" />
          <span>Patient Identity Profile</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div>
            <span className="text-slate-400 block mb-0.5 font-medium">Full Name</span>
            <span className="font-bold text-slate-900 text-sm">{currentUser.name}</span>
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5 font-medium">Assigned Role</span>
            <span className="inline-block px-2.5 py-0.5 bg-teal-50 text-teal-800 rounded font-semibold capitalize">
              {currentUser.role}
            </span>
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5 font-medium">Email Address</span>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="font-semibold text-slate-800">{currentUser.email}</span>
              {currentUser.isEmailVerified ? (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                  <CheckCircle className="w-3 h-3" /> Verified
                </span>
              ) : (
                <button
                  onClick={onOpenVerifyModal}
                  className="text-[10px] font-bold text-amber-700 bg-amber-50 hover:bg-amber-100 px-2 py-0.5 rounded-full border border-amber-200 transition"
                >
                  Verify Now
                </button>
              )}
            </div>
          </div>

          <div>
            <span className="text-slate-400 block mb-0.5 font-medium">Account Created</span>
            <span className="text-slate-600">
              {new Date(currentUser.createdAt || '2026-09-01').toLocaleDateString()}
            </span>
          </div>
        </div>
      </div>

      {/* 2. Database Backup & Restore */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div>
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Download className="w-4 h-4 text-teal-600" />
              <span>Database Backup & Snapshot Recovery</span>
            </h3>
            <p className="text-xs text-slate-400">
              Export an auditable offline snapshot of your appointments, clinics, and screenings.
            </p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 pt-2">
          <button
            onClick={handleExportBackup}
            className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center justify-center gap-2"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Database Backup (JSON)</span>
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-4 py-2.5 border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold transition flex items-center justify-center gap-2"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Restore From Backup File</span>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleImportBackup}
            accept=".json,application/json"
            className="hidden"
          />
        </div>
      </div>

      {/* 3. Danger Zone: Delete Account */}
      <div className="bg-rose-50/50 rounded-3xl border border-rose-200 p-6 sm:p-8 space-y-4">
        <div>
          <h3 className="font-bold text-rose-950 text-sm flex items-center gap-2">
            <Trash2 className="w-4 h-4 text-rose-600" />
            <span>Danger Zone — Permanent Account & Record Erasure</span>
          </h3>
          <p className="text-xs text-rose-800/80 mt-1">
            Exercise your HIPAA/GDPR Right to Erasure. Permanently delete your user credentials, consultation history, and locally stored screening records.
          </p>
        </div>

        <button
          onClick={() => setShowDeleteModal(true)}
          className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl shadow-xs transition"
        >
          Delete My Account Permanently
        </button>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="font-bold text-slate-900 text-base">Confirm Account Deletion</h3>
              <p className="text-xs text-slate-500">
                This action is irreversible. All your appointments and clinical screening reports will be permanently purged.
              </p>
            </div>

            <div className="space-y-2 text-xs">
              <label className="font-semibold text-slate-700 block">
                Enter your password to confirm
              </label>
              <input
                type="password"
                placeholder="Enter account password"
                value={deletePassword}
                onChange={(e) => setDeletePassword(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl outline-none"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setShowDeleteModal(false)}
                className="flex-1 py-2.5 border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleDeleteAccount}
                disabled={isDeleting || !deletePassword}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 disabled:bg-slate-300 text-white text-xs font-bold rounded-xl transition"
              >
                {isDeleting ? 'Purging Data...' : 'Confirm Purge'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
