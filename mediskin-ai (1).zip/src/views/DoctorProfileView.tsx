import React from 'react';
import {
  ArrowLeft,
  CheckCircle2,
  Star,
  MapPin,
  Calendar,
  Building,
  GraduationCap,
  Award,
  ShieldCheck,
  Video,
  Clock,
} from 'lucide-react';
import { DoctorProfile } from '../types/index.ts';

interface Props {
  doctor: DoctorProfile;
  onNavigate: (view: string, params?: Record<string, any>) => void;
  onBack: () => void;
}

export const DoctorProfileView: React.FC<Props> = ({ doctor, onNavigate, onBack }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Specialist Directory</span>
      </button>

      {/* Main Profile Header */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row items-start gap-6">
          <img
            src={doctor.avatarUrl}
            alt={doctor.name}
            className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl object-cover ring-4 ring-slate-100 shrink-0"
          />

          <div className="flex-1 space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="text-2xl font-black text-slate-900">{doctor.name}</h1>
              {doctor.verificationStatus === 'Verified' && (
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-teal-50 text-teal-800 text-xs font-bold rounded-md border border-teal-200">
                  <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" /> State Board Verified
                </span>
              )}
            </div>

            <p className="text-sm font-semibold text-teal-700">{doctor.title} • {doctor.specialty}</p>

            <div className="flex flex-wrap items-center gap-4 text-xs text-slate-500 pt-1">
              <span className="flex items-center gap-1">
                <Building className="w-3.5 h-3.5 text-slate-400" />
                {doctor.hospitalAffiliation}
              </span>
              <span className="flex items-center gap-1">
                <MapPin className="w-3.5 h-3.5 text-slate-400" />
                {doctor.clinicAddress}, {doctor.city}, {doctor.state}
              </span>
              <span className="flex items-center gap-1 font-bold text-amber-600">
                <Star className="w-3.5 h-3.5 fill-amber-400 stroke-amber-500" />
                {doctor.rating} ({doctor.reviewCount} verified reviews)
              </span>
            </div>

            <div className="pt-4 flex flex-wrap items-center justify-between gap-4 border-t border-slate-100">
              <div>
                <span className="text-[10px] text-slate-400 block font-semibold uppercase">Consultation Fee</span>
                <span className="text-xl font-extrabold text-slate-900">${doctor.consultationFee}</span>
              </div>

              <button
                onClick={() => onNavigate('booking', { doctorId: doctor.id })}
                className="px-6 py-3 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl shadow-md shadow-teal-600/20 transition flex items-center gap-2"
              >
                <Calendar className="w-4 h-4" />
                <span>Reserve Appointment Slot</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Details Tabs / Content */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Column: Clinical Focus & Credentials */}
        <div className="md:col-span-2 space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">Biography & Background</h3>
            <p className="text-xs text-slate-600 leading-relaxed">{doctor.bio}</p>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700">Clinical Focus Areas</h3>
            <div className="flex flex-wrap gap-2">
              {doctor.subSpecialties.map((sub) => (
                <span key={sub} className="px-2.5 py-1 bg-teal-50 text-teal-800 text-xs font-medium rounded-lg border border-teal-100">
                  {sub}
                </span>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-teal-600" />
              Education & Board Qualifications
            </h3>
            <p className="text-xs text-slate-600">{doctor.education}</p>
            <div className="pt-2 text-[11px] text-slate-500 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-teal-600" />
              <span>Medical License Reg: <strong>{doctor.licenseNumber}</strong></span>
            </div>
          </div>
        </div>

        {/* Right Column: Schedule & Consultation Modes */}
        <div className="space-y-6">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-2">
              <Clock className="w-4 h-4 text-teal-600" /> Available Consultation Modes
            </h3>

            <div className="space-y-2 text-xs">
              {doctor.modes.map((mode) => (
                <div key={mode} className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 font-semibold text-slate-700 flex items-center justify-between">
                  <span>{mode}</span>
                  <span className="text-[10px] text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">Active</span>
                </div>
              ))}
            </div>

            <div className="pt-2">
              <span className="text-[10px] text-slate-400 block font-bold uppercase mb-1">Standard Clinic Hours</span>
              <p className="text-xs text-slate-600">
                Mon - Fri: 9:00 AM - 5:00 PM (Direct video telehealth available on weekends)
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
