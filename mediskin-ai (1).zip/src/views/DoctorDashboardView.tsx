import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  CheckCircle,
  XCircle,
  Check,
  ShieldCheck,
  Users,
  Settings,
  Plus,
  AlertCircle,
  FileText,
} from 'lucide-react';
import { UserProfile } from '../types/index.ts';
import { db } from '../services/db.ts';
import { AppointmentRecord } from '../utils/appointmentRules.ts';

interface Props {
  currentUser: UserProfile;
}

export const DoctorDashboardView: React.FC<Props> = ({ currentUser }) => {
  const doctor = db.getDoctorById(currentUser.id) || db.getDoctors()[0];
  const [appointments, setAppointments] = useState<AppointmentRecord[]>(
    db.getAppointments({ userId: doctor.id, role: 'doctor' })
  );
  const [availableDays, setAvailableDays] = useState<number[]>(doctor.availableDays);
  const [timeSlots, setTimeSlots] = useState<string[]>(doctor.timeSlots);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);

  const refreshAppointments = () => {
    setAppointments(db.getAppointments({ userId: doctor.id, role: 'doctor' }));
  };

  const handleUpdateStatus = (appId: string, status: 'Confirmed' | 'Rejected' | 'Completed') => {
    const res = db.updateAppointmentStatus(
      appId,
      status,
      currentUser.email,
      'doctor',
      `Updated by ${doctor.name}`
    );
    if (res.success) {
      setFeedbackMsg(`Appointment status updated to ${status}.`);
      refreshAppointments();
    } else {
      setFeedbackMsg(res.error || 'Failed to update appointment status.');
    }
  };

  const toggleDay = (dayIndex: number) => {
    const updated = availableDays.includes(dayIndex)
      ? availableDays.filter((d) => d !== dayIndex)
      : [...availableDays, dayIndex].sort();
    setAvailableDays(updated);
    db.updateDoctorAvailability(doctor.id, updated, timeSlots);
    setFeedbackMsg('Working schedule days updated.');
  };

  const daysLabels = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const pendingRequests = appointments.filter((a) => a.status === 'Pending');
  const activeConfirmed = appointments.filter((a) => a.status === 'Confirmed');

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Doctor Header Strip */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <img
            src={doctor.avatarUrl}
            alt={doctor.name}
            className="w-16 h-16 rounded-2xl object-cover ring-2 ring-slate-100 shrink-0"
          />
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-slate-900">{doctor.name}</h1>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 ${
                doctor.verificationStatus === 'Verified'
                  ? 'bg-teal-50 text-teal-800 border border-teal-200'
                  : 'bg-amber-50 text-amber-800 border border-amber-200'
              }`}>
                <ShieldCheck className="w-3 h-3 text-teal-600" />
                {doctor.verificationStatus}
              </span>
            </div>
            <p className="text-xs font-medium text-teal-700 mt-0.5">
              {doctor.title} • {doctor.specialty} (License: {doctor.licenseNumber})
            </p>
            <p className="text-[11px] text-slate-400">{doctor.hospitalAffiliation}</p>
          </div>
        </div>

        <div className="flex items-center gap-6 text-xs text-slate-600">
          <div className="text-center">
            <span className="text-xl font-black text-slate-900 block">{pendingRequests.length}</span>
            <span className="text-[10px] text-slate-400 uppercase font-semibold">Pending</span>
          </div>
          <div className="text-center">
            <span className="text-xl font-black text-teal-600 block">{activeConfirmed.length}</span>
            <span className="text-[10px] text-slate-400 uppercase font-semibold">Confirmed</span>
          </div>
        </div>
      </div>

      {feedbackMsg && (
        <div className="p-3.5 bg-teal-50 border border-teal-200 rounded-xl text-teal-900 text-xs flex items-center justify-between">
          <span>{feedbackMsg}</span>
          <button onClick={() => setFeedbackMsg(null)} className="text-teal-700 font-bold hover:underline">
            Dismiss
          </button>
        </div>
      )}

      {/* Grid: Pending Appointment Queue & Schedule Settings */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Appointment Queues */}
        <div className="lg:col-span-7 space-y-6">
          {/* Pending Requests Queue */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <Clock className="w-4 h-4 text-amber-500" />
                <span>Pending Booking Requests ({pendingRequests.length})</span>
              </h3>
            </div>

            {pendingRequests.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">No pending patient booking requests.</p>
            ) : (
              <div className="space-y-3">
                {pendingRequests.map((app) => (
                  <div key={app.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <span className="font-mono text-[10px] bg-slate-200 px-1.5 py-0.2 rounded font-bold">
                          {app.referenceCode}
                        </span>
                        <h4 className="font-bold text-slate-900 text-sm mt-1">{app.patientName}</h4>
                        <p className="text-slate-500 text-[11px]">{app.patientEmail} • {app.patientPhone}</p>
                      </div>

                      <div className="text-right">
                        <span className="font-bold text-teal-700 block">{app.date}</span>
                        <span className="text-[11px] text-slate-500">{app.timeSlot} ({app.mode})</span>
                      </div>
                    </div>

                    <div className="p-2.5 bg-white rounded-xl border border-slate-100 text-[11px] text-slate-600">
                      <strong>Reason:</strong> {app.reason}
                    </div>

                    <div className="flex items-center justify-end gap-2 pt-1">
                      <button
                        onClick={() => handleUpdateStatus(app.id, 'Rejected')}
                        className="px-3 py-1.5 border border-rose-200 hover:bg-rose-50 text-rose-700 rounded-xl text-xs font-semibold transition"
                      >
                        Decline
                      </button>
                      <button
                        onClick={() => handleUpdateStatus(app.id, 'Confirmed')}
                        className="px-4 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition"
                      >
                        Accept & Confirm
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Confirmed Schedule Queue */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2 pb-2 border-b border-slate-100">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              <span>Confirmed Consultations Queue ({activeConfirmed.length})</span>
            </h3>

            {activeConfirmed.length === 0 ? (
              <p className="text-xs text-slate-400 py-4 text-center">No active confirmed consultations.</p>
            ) : (
              <div className="space-y-3">
                {activeConfirmed.map((app) => (
                  <div key={app.id} className="p-4 bg-emerald-50/40 rounded-2xl border border-emerald-100 text-xs flex items-center justify-between gap-4">
                    <div className="space-y-0.5">
                      <p className="font-bold text-slate-900">{app.patientName} ({app.mode})</p>
                      <p className="text-emerald-800 font-semibold">{app.date} at {app.timeSlot}</p>
                      <p className="text-slate-500 text-[11px] italic">"{app.reason}"</p>
                    </div>

                    <button
                      onClick={() => handleUpdateStatus(app.id, 'Completed')}
                      className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-xl shrink-0 shadow-xs"
                    >
                      Mark Completed
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Working Schedule & Slot Availability */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <Settings className="w-4 h-4 text-teal-600" />
              <span>Manage Consultation Days</span>
            </h3>

            <p className="text-xs text-slate-500">
              Toggle days of the week you accept clinic appointments and video telehealth calls:
            </p>

            <div className="space-y-2">
              {daysLabels.map((dayName, idx) => {
                const isActive = availableDays.includes(idx);
                return (
                  <button
                    key={dayName}
                    onClick={() => toggleDay(idx)}
                    className={`w-full p-2.5 rounded-xl border text-left text-xs font-semibold transition flex items-center justify-between ${
                      isActive
                        ? 'border-teal-500 bg-teal-50/60 text-teal-900'
                        : 'border-slate-200 bg-slate-50 text-slate-500 hover:bg-slate-100'
                    }`}
                  >
                    <span>{dayName}</span>
                    {isActive ? (
                      <span className="text-[10px] bg-teal-600 text-white px-2 py-0.5 rounded font-bold">Open</span>
                    ) : (
                      <span className="text-[10px] text-slate-400">Off</span>
                    )}
                  </button>
                );
              })}
            </div>

            <div className="pt-3 border-t border-slate-100">
              <span className="text-xs font-bold text-slate-700 block mb-2">Configured Slots</span>
              <div className="flex flex-wrap gap-1.5">
                {timeSlots.map((slot) => (
                  <span key={slot} className="px-2 py-1 bg-slate-100 text-slate-700 rounded-md text-[10px] font-mono">
                    {slot}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
