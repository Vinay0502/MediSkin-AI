import React, { useState } from 'react';
import {
  Shield,
  ShieldCheck,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Building2,
  Users,
  Calendar,
  Activity,
  Plus,
  FileText,
  Search,
} from 'lucide-react';
import { UserProfile, DoctorVerificationStatus, HospitalFacility } from '../types/index.ts';
import { db } from '../services/db.ts';

interface Props {
  currentUser: UserProfile;
}

export const AdminDashboardView: React.FC<Props> = ({ currentUser }) => {
  const [doctors, setDoctors] = useState(db.getDoctors());
  const [facilities, setFacilities] = useState(db.getHospitals());
  const [auditLogs, setAuditLogs] = useState(db.getAuditLogs());
  const appointments = db.getAppointments();
  const feedbacks = db.getFeedbacks();

  const [activeTab, setActiveTab] = useState<'verification' | 'facilities' | 'audit' | 'analytics'>('verification');
  const [feedbackNotice, setFeedbackNotice] = useState<string | null>(null);

  // Facility creation modal
  const [showAddFacility, setShowAddFacility] = useState(false);
  const [newFacName, setNewFacName] = useState('');
  const [newFacCity, setNewFacCity] = useState('');
  const [newFacType, setNewFacType] = useState<HospitalFacility['facilityType']>('Specialized Dermatology Center');
  const [newFacPhone, setNewFacPhone] = useState('');

  const handleUpdateDoctorStatus = (doctorId: string, status: DoctorVerificationStatus) => {
    const ok = db.updateDoctorVerification(doctorId, status, currentUser.email);
    if (ok) {
      setDoctors(db.getDoctors());
      setAuditLogs(db.getAuditLogs());
      setFeedbackNotice(`Doctor credentials updated to "${status}". Audit record written.`);
    }
  };

  const handleCreateFacility = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFacName || !newFacCity) return;

    db.addHospital(
      {
        id: `hosp-${Date.now()}`,
        name: newFacName,
        facilityType: newFacType,
        address: '100 Medical Center Blvd',
        city: newFacCity,
        state: 'CA',
        phone: newFacPhone || '(415) 555-0100',
        emergencyCare: true,
        dermatologyDepartment: true,
        rating: 4.8,
        lat: 37.7749,
        lng: -122.4194,
        operatingHours: 'Mon - Fri: 8:00 AM - 6:00 PM',
        acceptedInsurances: ['Blue Cross', 'Medicare', 'Aetna'],
      },
      currentUser.email
    );

    setFacilities(db.getHospitals());
    setAuditLogs(db.getAuditLogs());
    setShowAddFacility(false);
    setNewFacName('');
    setNewFacCity('');
    setFeedbackNotice('New medical facility published to public directory.');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Admin Title Strip */}
      <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 text-white shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-teal-400" />
            <span className="text-xs font-bold uppercase tracking-wider text-teal-300">
              System Administration & Clinical Governance
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black">Admin Command Center</h1>
          <p className="text-xs text-slate-400 max-w-xl">
            Audit clinical access logs, verify medical practitioner credentials against state licensing boards, and monitor patient consultation analytics.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-3 text-center text-xs">
          <div className="bg-slate-800/80 px-4 py-2.5 rounded-xl border border-slate-700">
            <span className="text-lg font-bold text-teal-400 block">{doctors.length}</span>
            <span className="text-[10px] text-slate-400 uppercase">Specialists</span>
          </div>
          <div className="bg-slate-800/80 px-4 py-2.5 rounded-xl border border-slate-700">
            <span className="text-lg font-bold text-teal-400 block">{appointments.length}</span>
            <span className="text-[10px] text-slate-400 uppercase">Bookings</span>
          </div>
          <div className="bg-slate-800/80 px-4 py-2.5 rounded-xl border border-slate-700">
            <span className="text-lg font-bold text-teal-400 block">{auditLogs.length}</span>
            <span className="text-[10px] text-slate-400 uppercase">Audit Logs</span>
          </div>
        </div>
      </div>

      {feedbackNotice && (
        <div className="p-3.5 bg-teal-50 border border-teal-200 rounded-xl text-teal-900 text-xs flex items-center justify-between">
          <span>{feedbackNotice}</span>
          <button onClick={() => setFeedbackNotice(null)} className="text-teal-700 font-bold hover:underline">
            Dismiss
          </button>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setActiveTab('verification')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'verification' ? 'bg-teal-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Doctor Verification Queue ({doctors.filter((d) => d.verificationStatus !== 'Verified').length} Pending)
        </button>
        <button
          onClick={() => setActiveTab('facilities')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'facilities' ? 'bg-teal-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Clinic Directory ({facilities.length})
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          className={`px-3.5 py-2 text-xs font-bold rounded-xl transition ${
            activeTab === 'audit' ? 'bg-teal-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Security Audit Trail
        </button>
      </div>

      {/* TAB 1: DOCTOR VERIFICATION */}
      {activeTab === 'verification' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Physician License & Credential Verification</h3>
              <p className="text-xs text-slate-500">Cross-examine state board medical council registrations</p>
            </div>
          </div>

          <div className="space-y-4">
            {doctors.map((doc) => (
              <div
                key={doc.id}
                className="p-4 rounded-2xl border border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs"
              >
                <div className="flex items-center gap-3.5">
                  <img
                    src={doc.avatarUrl}
                    alt={doc.name}
                    className="w-12 h-12 rounded-xl object-cover ring-2 ring-slate-200 shrink-0"
                  />
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900 text-sm">{doc.name}</span>
                      <span className={`text-[10px] font-bold px-2 py-0.2 rounded ${
                        doc.verificationStatus === 'Verified'
                          ? 'bg-emerald-100 text-emerald-800'
                          : doc.verificationStatus === 'Pending Review'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}>
                        {doc.verificationStatus}
                      </span>
                    </div>
                    <p className="text-slate-500">{doc.title} • {doc.specialty}</p>
                    <p className="text-[11px] text-teal-800 font-mono font-semibold">
                      Board License ID: {doc.licenseNumber}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-center">
                  {doc.verificationStatus !== 'Verified' && (
                    <button
                      onClick={() => handleUpdateDoctorStatus(doc.id, 'Verified')}
                      className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition shadow-xs"
                    >
                      Approve & Verify
                    </button>
                  )}
                  {doc.verificationStatus !== 'Needs More Info' && (
                    <button
                      onClick={() => handleUpdateDoctorStatus(doc.id, 'Needs More Info')}
                      className="px-3 py-1.5 border border-slate-300 hover:bg-slate-100 text-slate-700 rounded-xl font-semibold transition"
                    >
                      Request Info
                    </button>
                  )}
                  {doc.verificationStatus !== 'Rejected' && (
                    <button
                      onClick={() => handleUpdateDoctorStatus(doc.id, 'Rejected')}
                      className="px-3 py-1.5 text-rose-600 hover:bg-rose-50 rounded-xl font-semibold transition"
                    >
                      Reject
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: FACILITIES MANAGEMENT */}
      {activeTab === 'facilities' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Healthcare Facility Directory</h3>
              <p className="text-xs text-slate-500">Manage hospitals and urgent dermatology centers</p>
            </div>
            <button
              onClick={() => setShowAddFacility(true)}
              className="px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Add Facility</span>
            </button>
          </div>

          <div className="space-y-3">
            {facilities.map((fac) => (
              <div key={fac.id} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between text-xs">
                <div>
                  <h4 className="font-bold text-slate-900">{fac.name}</h4>
                  <p className="text-slate-500">{fac.address}, {fac.city}, {fac.state} • {fac.phone}</p>
                </div>
                <span className="text-[10px] font-semibold bg-white border border-slate-200 px-2.5 py-1 rounded-lg text-slate-700">
                  {fac.facilityType}
                </span>
              </div>
            ))}
          </div>

          {/* Add Facility Modal */}
          {showAddFacility && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
              <form onSubmit={handleCreateFacility} className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <h3 className="font-bold text-slate-900 text-sm">Add Healthcare Center</h3>
                  <button type="button" onClick={() => setShowAddFacility(false)} className="text-slate-400">✕</button>
                </div>

                <div className="space-y-3 text-xs">
                  <div>
                    <label className="font-bold block mb-1">Facility Name</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Pacific Coast Dermatology Center"
                      value={newFacName}
                      onChange={(e) => setNewFacName(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="font-bold block mb-1">City</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. San Francisco"
                      value={newFacCity}
                      onChange={(e) => setNewFacCity(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                  <div>
                    <label className="font-bold block mb-1">Facility Phone</label>
                    <input
                      type="text"
                      placeholder="(415) 555-0199"
                      value={newFacPhone}
                      onChange={(e) => setNewFacPhone(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl"
                    />
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowAddFacility(false)}
                    className="flex-1 py-2.5 border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 bg-teal-600 text-white text-xs font-bold rounded-xl"
                  >
                    Save Facility
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: AUDIT TRAIL */}
      {activeTab === 'audit' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Security & Operational Audit Log</h3>
              <p className="text-xs text-slate-500">Immutable trail of critical state transitions and access events</p>
            </div>
            <span className="text-xs font-mono text-slate-400">{auditLogs.length} events logged</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 text-slate-500 border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">Timestamp</th>
                  <th className="py-2.5 px-3">Actor & Role</th>
                  <th className="py-2.5 px-3">Event Action</th>
                  <th className="py-2.5 px-3">Audit Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-slate-50/50">
                    <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString()}
                    </td>
                    <td className="py-2.5 px-3 whitespace-nowrap">
                      <span className="font-semibold text-slate-900">{log.actorEmail}</span>
                      <span className="ml-1.5 text-[10px] uppercase font-bold text-teal-700">({log.actorRole})</span>
                    </td>
                    <td className="py-2.5 px-3 font-mono text-[11px] font-bold text-teal-800 whitespace-nowrap">
                      {log.action}
                    </td>
                    <td className="py-2.5 px-3 text-slate-600">
                      {log.details}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
