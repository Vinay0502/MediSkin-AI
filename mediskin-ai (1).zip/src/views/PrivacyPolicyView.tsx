import React from 'react';
import { ShieldCheck, Lock, Eye, FileText, ArrowLeft } from 'lucide-react';

interface Props {
  onBack: () => void;
}

export const PrivacyPolicyView: React.FC<Props> = ({ onBack }) => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Return to Application</span>
      </button>

      <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 shadow-sm space-y-6 text-xs text-slate-600 leading-relaxed">
        <div className="space-y-1 pb-4 border-b border-slate-100">
          <span className="text-[10px] font-bold uppercase tracking-wider text-teal-600">
            Compliance & Transparency
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900">
            MediSkin AI Privacy Policy
          </h1>
          <p className="text-xs text-slate-400">Last Revised: October 20, 2026</p>
        </div>

        <section className="space-y-2">
          <h2 className="text-sm font-bold text-slate-900">1. Patient-First Privacy Commitment</h2>
          <p>
            MediSkin AI is committed to upholding the highest standards of digital health data privacy, including alignment with the Health Insurance Portability and Accountability Act (HIPAA) principles and the General Data Protection Regulation (GDPR) patient rights.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-bold text-slate-900">2. Processing of Skin Lesion Photographs</h2>
          <p>
            When you upload or capture a skin lesion photograph, image decoding, blur analysis, luminance checks, and feature extraction take place in your browser’s local execution memory. We do not transmit or sell user-uploaded biometric or medical images to third-party commercial marketing networks.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-bold text-slate-900">3. Row-Level Security (RLS) & Record Isolation</h2>
          <p>
            All appointment records, patient notes, and saved screening histories are strictly sandboxed via Row-Level Security policies. Patients can only query and manage their own consultations; healthcare providers can only view patients with whom they have an active scheduled consultation.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-bold text-slate-900">4. Right to Erasure (Account & Data Deletion)</h2>
          <p>
            Patients retain full control over their health data. You may export an encrypted database backup snapshot at any time from your Account Settings, or execute an irreversible account and record purge via the "Delete Account" option.
          </p>
        </section>

        <section className="space-y-2">
          <h2 className="text-sm font-bold text-slate-900">5. Contacting the Clinical Data Protection Officer</h2>
          <p>
            For privacy compliance inquiries or data subject access requests, please contact our data governance team at <strong className="text-slate-900">privacy@mediskin.health</strong>.
          </p>
        </section>
      </div>
    </div>
  );
};
