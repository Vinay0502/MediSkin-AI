import React, { useState } from 'react';
import {
  Activity,
  BarChart3,
  AlertTriangle,
  CheckCircle,
  Eye,
  RefreshCw,
  Trash2,
  Calendar,
  Smartphone,
  Shield,
} from 'lucide-react';
import { analytics } from '../services/analyticsService.ts';
import { errorTracker } from '../services/errorTrackingService.ts';

export const AnalyticsView: React.FC = () => {
  const [summary, setSummary] = useState(analytics.getSummary());
  const [events, setEvents] = useState(analytics.getEvents());
  const [errors, setErrors] = useState(errorTracker.getErrors());

  const handleRefresh = () => {
    setSummary(analytics.getSummary());
    setEvents(analytics.getEvents());
    setErrors(errorTracker.getErrors());
  };

  const handleClearErrors = () => {
    errorTracker.clearErrors();
    setErrors([]);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-teal-600 block mb-1">
            Clinical Telemetry & Reliability
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            Platform Analytics & Error Telemetry
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Real-time event logging, screening-to-booking funnel conversion, and exception tracking.
          </p>
        </div>

        <button
          onClick={handleRefresh}
          className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Metrics</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase">Total Page Views</span>
          <p className="text-2xl font-black text-slate-900">{summary.pageViews}</p>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase">Screenings Run</span>
          <p className="text-2xl font-black text-teal-600">{summary.screenings}</p>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase">Appointments Booked</span>
          <p className="text-2xl font-black text-sky-600">{summary.bookings}</p>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200 shadow-xs space-y-1">
          <span className="text-[10px] text-slate-400 font-bold uppercase">Triage-to-Consult Funnel</span>
          <p className="text-2xl font-black text-emerald-600">{summary.conversionRate}%</p>
        </div>
      </div>

      {/* 2-Column: Event Stream & Error Telemetry */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: Recent Analytics Events */}
        <div className="lg:col-span-6 bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-teal-600" />
              <span>Event Stream ({events.length})</span>
            </h3>
            <span className="text-[10px] text-slate-400">Client-Side Anonymized</span>
          </div>

          <div className="max-h-96 overflow-y-auto space-y-2 text-xs">
            {events.length === 0 ? (
              <p className="text-center text-slate-400 py-8">No analytics events recorded yet.</p>
            ) : (
              events.slice(0, 20).map((ev) => (
                <div key={ev.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between gap-2">
                  <div className="space-y-0.5">
                    <span className="font-mono font-bold text-slate-800 text-[11px] block">{ev.type}</span>
                    <span className="text-[10px] text-slate-400">
                      {new Date(ev.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  {ev.metadata && (
                    <span className="text-[10px] font-mono bg-white px-2 py-0.5 rounded border border-slate-200 text-slate-600 truncate max-w-48">
                      {JSON.stringify(ev.metadata)}
                    </span>
                  )}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Column: Error Telemetry Logs */}
        <div className="lg:col-span-6 bg-white rounded-3xl border border-slate-200 shadow-sm p-6 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              <span>Exception Telemetry ({errors.length})</span>
            </h3>
            {errors.length > 0 && (
              <button
                onClick={handleClearErrors}
                className="text-xs text-rose-600 hover:underline font-semibold flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear Logs</span>
              </button>
            )}
          </div>

          <div className="max-h-96 overflow-y-auto space-y-2 text-xs">
            {errors.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400 bg-slate-50 rounded-2xl">
                <CheckCircle className="w-6 h-6 text-emerald-500 mx-auto mb-1" />
                <span>Zero uncaught exceptions logged. System operating nominally.</span>
              </div>
            ) : (
              errors.map((err) => (
                <div key={err.id} className="p-3 bg-rose-50/50 rounded-xl border border-rose-100 space-y-1">
                  <div className="flex justify-between text-[11px]">
                    <span className="font-bold text-rose-950 truncate max-w-xs">{err.message}</span>
                    <span className="text-slate-400">{new Date(err.timestamp).toLocaleTimeString()}</span>
                  </div>
                  {err.stack && (
                    <pre className="text-[9px] text-slate-600 font-mono bg-white p-2 rounded max-h-24 overflow-x-auto">
                      {err.stack.slice(0, 300)}...
                    </pre>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
