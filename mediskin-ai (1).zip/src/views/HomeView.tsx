import React from 'react';
import {
  Scan,
  Users,
  Building2,
  BookOpen,
  ShieldCheck,
  HeartPulse,
  Sparkles,
  ArrowRight,
  Activity,
  CheckCircle2,
  CalendarCheck,
  Eye,
  AlertCircle,
  Clock,
  Award,
} from 'lucide-react';
import { DoctorProfile } from '../types/index.ts';

interface Props {
  onNavigate: (view: string, params?: Record<string, any>) => void;
  featuredDoctors: DoctorProfile[];
  onOpenDisclaimer: () => void;
}

export const HomeView: React.FC<Props> = ({
  onNavigate,
  featuredDoctors,
  onOpenDisclaimer,
}) => {
  return (
    <div className="space-y-16 pb-16">
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden bg-gradient-to-b from-teal-50/70 via-white to-slate-50 pt-8 pb-16 sm:pb-20 px-4 sm:px-6 lg:px-8 border-b border-slate-200/60">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Headline and Actions */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-100/80 border border-teal-200/80 text-teal-800 text-xs font-bold tracking-wide shadow-xs">
                <Sparkles className="w-3.5 h-3.5 text-teal-600" />
                <span>Preliminary AI Lesion Triage & Specialist Booking</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-[1.15]">
                Intelligent Skin Health Screening, <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-600 to-sky-600">Verified Specialist Care.</span>
              </h1>

              <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
                Capture or upload high-resolution skin lesion photos for instant deep-learning screening, optical quality checks, and Explainable AI attention heatmaps. Seamlessly discover accredited dermatologists and book appointments in under two minutes.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 pt-2">
                <button
                  onClick={() => onNavigate('analysis')}
                  className="w-full sm:w-auto px-7 py-3.5 bg-gradient-to-r from-teal-600 to-teal-700 hover:from-teal-700 hover:to-teal-800 text-white font-bold text-sm rounded-xl shadow-lg shadow-teal-600/25 transition active:scale-98 flex items-center justify-center gap-2"
                >
                  <Scan className="w-4 h-4" />
                  <span>Analyze Skin Image</span>
                  <ArrowRight className="w-4 h-4 ml-1" />
                </button>

                <button
                  onClick={() => onNavigate('doctors')}
                  className="w-full sm:w-auto px-6 py-3.5 bg-white hover:bg-slate-50 text-slate-800 font-semibold text-sm rounded-xl border border-slate-300 shadow-xs transition active:scale-98 flex items-center justify-center gap-2"
                >
                  <Users className="w-4 h-4 text-teal-600" />
                  <span>Find a Dermatologist</span>
                </button>
              </div>

              {/* Safety Disclaimers & Accreditation note */}
              <div className="pt-3 flex flex-wrap items-center justify-center lg:justify-start gap-4 text-xs text-slate-500">
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-teal-600" />
                  <span>HAM10000 Trained Model</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-teal-600" />
                  <span>Board-Certified Specialists</span>
                </span>
                <button
                  onClick={onOpenDisclaimer}
                  className="text-teal-700 hover:underline font-semibold flex items-center gap-1"
                >
                  <span>Non-Diagnostic Scope</span>
                  <AlertCircle className="w-3.5 h-3.5 text-amber-500" />
                </button>
              </div>
            </div>

            {/* Right Column: Interactive Diagnostic Card Preview */}
            <div className="lg:col-span-5">
              <div className="bg-white rounded-2xl shadow-xl border border-slate-200/80 p-5 sm:p-6 space-y-4 relative overflow-hidden">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2.5">
                    <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-700">Live AI Vision Pipeline</span>
                  </div>
                  <span className="text-[11px] px-2 py-0.5 bg-teal-50 text-teal-700 font-mono font-medium rounded-md border border-teal-200">
                    MobileNetV3 Ensemble
                  </span>
                </div>

                {/* Sample Lesion Preview Row */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="relative rounded-xl overflow-hidden border border-slate-200 aspect-square group">
                    <img
                      src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&q=80&w=400"
                      alt="Dermoscopy scan"
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent flex items-end p-2.5">
                      <span className="text-[11px] font-semibold text-white">Dermoscopic View</span>
                    </div>
                  </div>

                  <div className="relative rounded-xl overflow-hidden border border-slate-200 aspect-square bg-slate-900 flex items-center justify-center p-2 text-center">
                    <div className="space-y-1">
                      <Eye className="w-6 h-6 text-teal-400 mx-auto" />
                      <p className="text-[11px] font-bold text-white">Grad-CAM Heatmap</p>
                      <p className="text-[10px] text-teal-200">Saliency Activation Map</p>
                      <div className="w-16 h-1.5 bg-gradient-to-r from-blue-500 via-yellow-400 to-red-500 rounded-full mx-auto mt-1" />
                    </div>
                  </div>
                </div>

                {/* Mocked Live Metric Results */}
                <div className="space-y-2 bg-slate-50 p-3.5 rounded-xl border border-slate-200/60 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-medium">Quality Inspection:</span>
                    <span className="font-bold text-emerald-700 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> High Clarity (Laplacian 184)
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-medium">Preliminary Match:</span>
                    <span className="font-bold text-slate-800">Melanocytic Nevus (94% Conf.)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 font-medium">Clinical Urgency:</span>
                    <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 rounded font-semibold text-[10px]">
                      Low (Routine Check)
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => onNavigate('analysis')}
                  className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition"
                >
                  <Scan className="w-3.5 h-3.5 text-teal-400" />
                  <span>Try Sample Screening Now</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. STATS & CLINICAL TRUST STRIP */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-slate-900 rounded-2xl p-6 sm:p-8 text-white shadow-xl">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            <div>
              <p className="text-2xl sm:text-3xl font-black text-teal-400">10,015+</p>
              <p className="text-xs text-slate-400 mt-1">ISIC Dermoscopy Archive</p>
            </div>
            <div>
              <p className="text-2xl sm:text-3xl font-black text-teal-400">7 Classes</p>
              <p className="text-xs text-slate-400 mt-1">HAM10000 Pathology Taxonomy</p>
            </div>
            <div>
              <p className="text-2xl sm:text-3xl font-black text-teal-400">100%</p>
              <p className="text-xs text-slate-400 mt-1">Verified Medical Licenses</p>
            </div>
            <div>
              <p className="text-2xl sm:text-3xl font-black text-teal-400">&lt; 2 Mins</p>
              <p className="text-xs text-slate-400 mt-1">Direct Slot Reservation</p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. HOW IT WORKS (4 STEPS) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <h2 className="text-xs uppercase tracking-wider font-bold text-teal-600 mb-1">Standardized Workflow</h2>
          <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900">How MediSkin AI Works</h3>
          <p className="text-sm text-slate-500 mt-2">
            A medically defensible, four-step pipeline connecting computer vision screening to accredited dermatological care.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3 relative">
            <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold text-sm">
              01
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Image Upload & Quality</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Upload or snap a lesion photograph. Automated Laplacian blur variance and exposure checks ensure the image is optically suitable.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3 relative">
            <div className="w-10 h-10 rounded-xl bg-sky-50 text-sky-700 flex items-center justify-center font-bold text-sm">
              02
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Deep Learning Inference</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Ensemble convolutional classification model maps lesion characteristics to ISIC classes with calibrated uncertainty thresholds.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3 relative">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold text-sm">
              03
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Grad-CAM Heatmap</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Inspect model focal regions with Explainable AI heatmap overlays, accompanied by ABCDE asymmetry and border analysis.
            </p>
          </div>

          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3 relative">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-sm">
              04
            </div>
            <h4 className="font-bold text-slate-900 text-sm">Specialist Consultation</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Review verified dermatologists, select in-person or video consultation, and lock in your appointment with instant confirmation.
            </p>
          </div>
        </div>
      </section>

      {/* 4. ABCDE CRITERIA INFOGRAPHIC */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-teal-900 to-slate-900 rounded-3xl p-6 sm:p-10 text-white shadow-xl">
          <div className="max-w-3xl mb-8">
            <span className="text-xs uppercase font-bold tracking-widest text-teal-400">Clinical Skin Self-Check</span>
            <h3 className="text-2xl sm:text-3xl font-extrabold mt-1">The ABCDEs of Melanoma Detection</h3>
            <p className="text-sm text-slate-300 mt-2">
              The American Academy of Dermatology recommends regularly examining skin lesions using the standardized ABCDE criteria:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/10">
              <span className="text-2xl font-black text-teal-300">A</span>
              <h5 className="font-bold text-sm mt-1">Asymmetry</h5>
              <p className="text-xs text-slate-300 mt-1">One half of the spot does not match the other half.</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/10">
              <span className="text-2xl font-black text-teal-300">B</span>
              <h5 className="font-bold text-sm mt-1">Border</h5>
              <p className="text-xs text-slate-300 mt-1">Edges are irregular, scalloped, notched, or poorly defined.</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/10">
              <span className="text-2xl font-black text-teal-300">C</span>
              <h5 className="font-bold text-sm mt-1">Color</h5>
              <p className="text-xs text-slate-300 mt-1">Color varies from one area to another: tan, brown, black, white, red, blue.</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/10">
              <span className="text-2xl font-black text-teal-300">D</span>
              <h5 className="font-bold text-sm mt-1">Diameter</h5>
              <p className="text-xs text-slate-300 mt-1">Usually greater than 6mm (pencil eraser), though melanomas can be smaller.</p>
            </div>
            <div className="bg-white/10 backdrop-blur-md p-4 rounded-xl border border-white/10">
              <span className="text-2xl font-black text-teal-300">E</span>
              <h5 className="font-bold text-sm mt-1">Evolving</h5>
              <p className="text-xs text-slate-300 mt-1">The mole is changing in size, shape, color, or symptoms like bleeding or itch.</p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. FEATURED DERMATOLOGISTS PREVIEW */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <h2 className="text-xs uppercase tracking-wider font-bold text-teal-600 mb-1">Accredited Specialists</h2>
            <h3 className="text-2xl font-extrabold text-slate-900">Featured Board-Certified Dermatologists</h3>
            <p className="text-sm text-slate-500">Every doctor profile is verified against state medical licensing boards.</p>
          </div>
          <button
            onClick={() => onNavigate('doctors')}
            className="text-xs font-bold text-teal-700 hover:text-teal-800 flex items-center gap-1 self-start sm:self-auto"
          >
            <span>View All Specialists ({featuredDoctors.length})</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {featuredDoctors.slice(0, 3).map((doctor) => (
            <div
              key={doctor.id}
              className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs hover:shadow-md transition flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start gap-3.5 mb-3">
                  <img
                    src={doctor.avatarUrl}
                    alt={doctor.name}
                    className="w-14 h-14 rounded-xl object-cover ring-2 ring-slate-100 shrink-0"
                  />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h4 className="font-bold text-slate-900 text-sm">{doctor.name}</h4>
                      {doctor.verificationStatus === 'Verified' && (
                        <span title="Board Verified" className="inline-flex items-center">
                          <CheckCircle2 className="w-4 h-4 text-teal-600" />
                        </span>
                      )}
                    </div>
                    <p className="text-xs font-medium text-teal-700">{doctor.title} • {doctor.specialty}</p>
                    <p className="text-[11px] text-slate-500 mt-0.5">{doctor.hospitalAffiliation}</p>
                  </div>
                </div>

                <p className="text-xs text-slate-600 line-clamp-2 mb-4 leading-relaxed">{doctor.bio}</p>

                <div className="flex flex-wrap gap-1.5 mb-4">
                  {doctor.modes.map((mode) => (
                    <span key={mode} className="text-[10px] font-semibold bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">
                      {mode}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-[10px] text-slate-400 block">Consultation Fee</span>
                  <span className="text-sm font-bold text-slate-900">${doctor.consultationFee}</span>
                </div>
                <button
                  onClick={() => onNavigate('booking', { doctorId: doctor.id })}
                  className="px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-semibold shadow-xs transition"
                >
                  Book Slot
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 6. CALL TO ACTION STRIP */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-teal-600 to-sky-600 rounded-3xl p-8 sm:p-12 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="max-w-xl text-center md:text-left space-y-2">
            <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Notice a concerning mole or changing spot?
            </h3>
            <p className="text-sm text-teal-100 leading-relaxed">
              Early detection is critical for high-risk cutaneous conditions. Upload a photo now for instant AI analysis and consultation scheduling.
            </p>
          </div>
          <button
            onClick={() => onNavigate('analysis')}
            className="px-8 py-4 bg-white text-teal-800 hover:bg-teal-50 rounded-2xl font-bold text-sm shadow-lg transition shrink-0 active:scale-95 flex items-center gap-2"
          >
            <Scan className="w-5 h-5 text-teal-600" />
            <span>Launch Skin Screening</span>
          </button>
        </div>
      </section>
    </div>
  );
};
