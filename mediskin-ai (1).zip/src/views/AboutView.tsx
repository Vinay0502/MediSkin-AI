import React from 'react';
import {
  ShieldCheck,
  HeartPulse,
  BrainCircuit,
  FileCode,
  Smartphone,
  ExternalLink,
  Lock,
  Layers,
} from 'lucide-react';

export const AboutView: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Title */}
      <div className="max-w-2xl">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-600 block mb-1">
          Architecture & Methodology
        </span>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          About MediSkin AI
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2 leading-relaxed">
          MediSkin AI is an AI-assisted dermatological preliminary screening and healthcare discovery platform designed to reduce delays in early lesion detection and connect patients with board-certified physicians.
        </p>
      </div>

      <div className="space-y-6 text-xs text-slate-600 leading-relaxed">
        {/* Card 1: Machine Learning Architecture */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-4">
          <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
            <div className="w-10 h-10 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center font-bold">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">AI Model & Dataset Provenance</h2>
              <p className="text-xs text-slate-400">HAM10000 / ISIC Dermoscopic Archive</p>
            </div>
          </div>

          <p>
            The classification pipeline utilizes deep transfer learning architectures (MobileNetV3 and ResNet backbones) benchmarked on the <strong>HAM10000 ("Human Against Machine with 10,000 training images")</strong> dermatoscopic dataset published by the International Skin Imaging Collaboration (ISIC).
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1">
              <span className="font-bold text-slate-800 block text-xs">Supported Pathologies</span>
              <p className="text-[11px] text-slate-500">
                Melanoma (MEL), Melanocytic Nevus (NV), Basal Cell Carcinoma (BCC), Actinic Keratoses (AKIEC), Benign Keratoses (BKL), Dermatofibroma (DF), and inflammatory dermatoses.
              </p>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 space-y-1">
              <span className="font-bold text-slate-800 block text-xs">Calibrated Uncertainty</span>
              <p className="text-[11px] text-slate-500">
                To prevent false certainty, the engine incorporates rejection thresholds: ambiguous margins or borderline optical quality trigger an explicit uncertainty recommendation to consult a doctor.
              </p>
            </div>
          </div>
        </div>

        {/* Card 2: Google Play Store & Mobile PWA Readiness */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-4">
          <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
            <div className="w-10 h-10 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center font-bold">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Google Play Store & Mobile Integration</h2>
              <p className="text-xs text-slate-400">Ready for Trusted Web Activity (TWA) & Expo wrapper</p>
            </div>
          </div>

          <p>
            The MediSkin AI frontend is architected as an installable Progressive Web App (PWA) with complete offline caching, web app manifest, maskable SVG icons, and responsive mobile-first viewports.
          </p>

          <div className="p-4 bg-sky-50/70 border border-sky-200 rounded-2xl space-y-2 text-sky-950">
            <span className="font-bold text-xs">Steps to publish to Google Play Store:</span>
            <ol className="list-decimal list-inside space-y-1 text-xs">
              <li>Use Google's official <strong>Bubblewrap CLI</strong> (`npx @bubblewrap/cli init --manifest=...`) to package this app into an Android App Bundle (.aab).</li>
              <li>Configure digital asset links (`.well-known/assetlinks.json`) with your keystore SHA-256 fingerprint for full-screen chrome-less launch.</li>
              <li>Upload the generated `.aab` directly to the Google Play Console under the Medical / Health category.</li>
            </ol>
          </div>
        </div>

        {/* Card 3: Medical Ethics & Data Privacy */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-4">
          <div className="flex items-center gap-3 pb-3 border-b border-slate-100">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900">Privacy & Clinical Ethics</h2>
              <p className="text-xs text-slate-400">Patient-First Data Governance</p>
            </div>
          </div>

          <p>
            Uploaded photos are processed locally in memory for feature extraction and are not retained on remote servers without explicit user consent. Appointment records, doctor verifications, and audit trails are persisted securely in local browser storage, offering users full control to export or delete records at any time.
          </p>
        </div>
      </div>
    </div>
  );
};
