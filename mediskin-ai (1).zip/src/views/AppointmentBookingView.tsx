import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  User,
  Phone,
  Mail,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Video,
  ArrowRight,
  ArrowLeft,
  Building,
  Check,
} from 'lucide-react';
import { DoctorProfile, UserProfile } from '../types/index.ts';
import { db } from '../services/db.ts';
import { getAvailableSlotsForDate, ConsultationMode } from '../utils/appointmentRules.ts';

interface Props {
  doctorId: string;
  currentUser: UserProfile;
  prefilledReason?: string;
  onNavigate: (view: string, params?: Record<string, any>) => void;
  onBack: () => void;
}

export const AppointmentBookingView: React.FC<Props> = ({
  doctorId,
  currentUser,
  prefilledReason,
  onNavigate,
  onBack,
}) => {
  const doctor = db.getDoctorById(doctorId) || db.getDoctors()[0];

  // Booking states
  const [selectedMode, setSelectedMode] = useState<ConsultationMode>(
    doctor.modes[0] as ConsultationMode || 'In-Person'
  );
  const getNextAvailableDate = () => {
    const today = new Date();
    for (let i = 1; i <= 14; i++) {
      const candidate = new Date(today);
      candidate.setDate(today.getDate() + i);
      const day = candidate.getDay();
      if (doctor.availableDays.includes(day)) {
        return candidate.toISOString().split('T')[0];
      }
    }
    return new Date(today.getTime() + 86400000).toISOString().split('T')[0];
  };

  const [selectedDate, setSelectedDate] = useState<string>(getNextAvailableDate());
  const [selectedSlot, setSelectedSlot] = useState<string>('');
  const [patientName, setPatientName] = useState(currentUser.id === 'guest' ? '' : currentUser.name);
  const [patientEmail, setPatientEmail] = useState(currentUser.id === 'guest' ? '' : currentUser.email);
  const [patientPhone, setPatientPhone] = useState(currentUser.phone || '');
  const [clinicalReason, setClinicalReason] = useState(prefilledReason || '');
  const [bookingConfirmed, setBookingConfirmed] = useState<any | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Get available slots for the selected date
  const existingAppointments = db.getAppointments();
  const availableSlots = getAvailableSlotsForDate(
    doctor.id,
    selectedDate,
    doctor.timeSlots,
    existingAppointments
  );

  const handleSubmitBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!selectedSlot) {
      setErrorMessage('Please select an available consultation time slot.');
      return;
    }
    if (!patientName.trim() || !patientEmail.trim()) {
      setErrorMessage('Please fill in your name and email address.');
      return;
    }

    setIsSubmitting(true);
    await new Promise((r) => setTimeout(r, 600));

    const result = db.createAppointment({
      doctorId: doctor.id,
      patientId: currentUser.id,
      patientName,
      patientEmail,
      patientPhone,
      date: selectedDate,
      timeSlot: selectedSlot,
      mode: selectedMode,
      reason: clinicalReason || 'Routine dermatological screening evaluation.',
    });

    setIsSubmitting(false);

    if (!result.success) {
      setErrorMessage(result.error || 'Failed to reserve appointment slot.');
      return;
    }

    setBookingConfirmed(result.appointment);
  };

  // Confirmation view
  if (bookingConfirmed) {
    return (
      <div className="max-w-xl mx-auto px-4 sm:px-6 py-10 sm:py-16">
        <div className="bg-white rounded-3xl border border-slate-200 shadow-xl p-8 text-center space-y-6">
          <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full">
              Booking Reserved
            </span>
            <h1 className="text-2xl font-black text-slate-900 mt-2">
              Appointment Confirmed
            </h1>
            <p className="text-xs text-slate-500">
              Booking Reference: <strong className="font-mono text-slate-900">{bookingConfirmed.referenceCode}</strong>
            </p>
          </div>

          <div className="bg-slate-50 rounded-2xl p-4 text-xs text-slate-600 space-y-2 border border-slate-100 text-left">
            <div className="flex justify-between py-1 border-b border-slate-200/60">
              <span className="text-slate-400">Specialist:</span>
              <span className="font-bold text-slate-900">{doctor.name} ({doctor.title})</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-200/60">
              <span className="text-slate-400">Consultation Date:</span>
              <span className="font-bold text-slate-900">{bookingConfirmed.date}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-200/60">
              <span className="text-slate-400">Time Slot:</span>
              <span className="font-bold text-slate-900">{bookingConfirmed.timeSlot}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-slate-200/60">
              <span className="text-slate-400">Mode:</span>
              <span className="font-semibold text-teal-700">{bookingConfirmed.mode}</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-slate-400">Location:</span>
              <span className="font-semibold text-slate-700">{doctor.hospitalAffiliation}</span>
            </div>
          </div>

          <p className="text-[11px] text-slate-400">
            A confirmation notification has been sent. Your doctor has received the booking request and clinical reason.
          </p>

          <div className="flex flex-col sm:flex-row gap-3 pt-2">
            <button
              onClick={() => onNavigate('appointments')}
              className="flex-1 py-3 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-md shadow-teal-600/20 transition"
            >
              View In My Appointments
            </button>
            <button
              onClick={() => onNavigate('home')}
              className="py-3 px-5 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold transition"
            >
              Return Home
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Change Specialist</span>
      </button>

      {/* Specialist Summary Header */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <img
            src={doctor.avatarUrl}
            alt={doctor.name}
            className="w-14 h-14 rounded-xl object-cover ring-2 ring-slate-100 shrink-0"
          />
          <div>
            <h2 className="text-base font-bold text-slate-900">{doctor.name}</h2>
            <p className="text-xs text-teal-700 font-medium">{doctor.title} • {doctor.specialty}</p>
            <p className="text-[11px] text-slate-400">{doctor.hospitalAffiliation}</p>
          </div>
        </div>
        <div className="text-right shrink-0">
          <span className="text-[10px] text-slate-400 uppercase font-semibold block">Fee</span>
          <span className="text-lg font-black text-slate-900">${doctor.consultationFee}</span>
        </div>
      </div>

      {errorMessage && (
        <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-rose-800 text-xs animate-in fade-in">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Booking Form */}
      <form onSubmit={handleSubmitBooking} className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6">
        {/* 1. Consultation Mode */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
            1. Select Consultation Mode
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {doctor.modes.map((mode) => (
              <button
                type="button"
                key={mode}
                onClick={() => setSelectedMode(mode as ConsultationMode)}
                className={`p-3 rounded-xl border text-left text-xs font-semibold transition flex items-center justify-between ${
                  selectedMode === mode
                    ? 'border-teal-600 bg-teal-50/70 text-teal-900 ring-2 ring-teal-500/20'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700'
                }`}
              >
                <span>{mode}</span>
                {selectedMode === mode && <Check className="w-3.5 h-3.5 text-teal-600" />}
              </button>
            ))}
          </div>
        </div>

        {/* 2. Date Picker */}
        <div className="space-y-2">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
            2. Choose Appointment Date
          </label>
          <input
            type="date"
            value={selectedDate}
            min="2026-10-21"
            onChange={(e) => {
              setSelectedDate(e.target.value);
              setSelectedSlot('');
            }}
            className="w-full sm:w-64 px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:ring-2 focus:ring-teal-500 outline-none"
          />
          <span className="text-[11px] text-slate-400 block">
            Specialist takes consultations on working days (Mon - Fri).
          </span>
        </div>

        {/* 3. Live Time Slot Picker */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-700">
              3. Available Time Slots for {selectedDate}
            </label>
            <span className="text-[11px] text-slate-400">{availableSlots.length} open slots</span>
          </div>

          {availableSlots.length === 0 ? (
            <div className="p-4 bg-slate-50 rounded-xl text-center text-xs text-slate-500 border border-slate-200">
              No available slots for this date. Please choose another date or working day.
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {availableSlots.map((slot) => {
                const isSelected = selectedSlot === slot;
                return (
                  <button
                    type="button"
                    key={slot}
                    onClick={() => setSelectedSlot(slot)}
                    className={`py-2.5 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                      isSelected
                        ? 'bg-teal-600 text-white shadow-xs'
                        : 'bg-slate-50 border border-slate-200 hover:border-teal-400 text-slate-700'
                    }`}
                  >
                    <Clock className="w-3 h-3" />
                    <span>{slot}</span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* 4. Patient Contact Details & Reason */}
        <div className="space-y-4 pt-4 border-t border-slate-100">
          <label className="text-xs font-bold uppercase tracking-wider text-slate-700 block">
            4. Patient Details & Clinical Visit Reason
          </label>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <span className="text-[11px] font-semibold text-slate-600 block mb-1">Full Name</span>
              <input
                type="text"
                required
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-teal-500 outline-none"
              />
            </div>

            <div>
              <span className="text-[11px] font-semibold text-slate-600 block mb-1">Email Address</span>
              <input
                type="email"
                required
                value={patientEmail}
                onChange={(e) => setPatientEmail(e.target.value)}
                className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-teal-500 outline-none"
              />
            </div>
          </div>

          <div>
            <span className="text-[11px] font-semibold text-slate-600 block mb-1">Phone Number</span>
            <input
              type="tel"
              required
              value={patientPhone}
              onChange={(e) => setPatientPhone(e.target.value)}
              className="w-full sm:w-1/2 px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-teal-500 outline-none"
            />
          </div>

          <div>
            <span className="text-[11px] font-semibold text-slate-600 block mb-1">
              Reason for Visit / AI Screening Notes
            </span>
            <textarea
              rows={3}
              value={clinicalReason}
              onChange={(e) => setClinicalReason(e.target.value)}
              placeholder="Describe symptoms, lesion location, or copy AI screening summary..."
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-teal-500 outline-none leading-relaxed"
            />
          </div>
        </div>

        {/* Submit */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isSubmitting || !selectedSlot}
            className="w-full py-4 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold text-sm rounded-xl shadow-md shadow-teal-600/20 transition active:scale-98 flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>Confirm & Reserve Appointment</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
