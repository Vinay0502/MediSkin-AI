import React from 'react';
import { FileQuestion, Home, Scan, Users, ArrowLeft } from 'lucide-react';

interface Props {
  onNavigate: (view: string) => void;
}

export const NotFoundView: React.FC<Props> = ({ onNavigate }) => {
  return (
    <div className="max-w-2xl mx-auto px-4 py-16 text-center space-y-6">
      <div className="w-20 h-20 rounded-3xl bg-teal-50 text-teal-600 flex items-center justify-center mx-auto border border-teal-100 shadow-sm">
        <FileQuestion className="w-10 h-10" />
      </div>

      <div className="space-y-2">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-600 bg-teal-50 px-2.5 py-1 rounded-full">
          HTTP 404 — Clinical Route Not Found
        </span>
        <h1 className="text-3xl font-black text-slate-900">
          Page or Record Unavailable
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 max-w-md mx-auto leading-relaxed">
          The requested page, patient record ID, or route could not be located in the MediSkin AI clinical directory.
        </p>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
        <button
          onClick={() => onNavigate('home')}
          className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold flex items-center gap-2 shadow-xs transition"
        >
          <Home className="w-3.5 h-3.5" />
          <span>Return to Home</span>
        </button>

        <button
          onClick={() => onNavigate('analysis')}
          className="px-5 py-2.5 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-2 transition"
        >
          <Scan className="w-3.5 h-3.5 text-teal-600" />
          <span>Launch Skin Screening</span>
        </button>

        <button
          onClick={() => onNavigate('doctors')}
          className="px-5 py-2.5 bg-white hover:bg-slate-50 border border-slate-300 text-slate-700 rounded-xl text-xs font-semibold flex items-center gap-2 transition"
        >
          <Users className="w-3.5 h-3.5 text-teal-600" />
          <span>Browse Specialists</span>
        </button>
      </div>
    </div>
  );
};
