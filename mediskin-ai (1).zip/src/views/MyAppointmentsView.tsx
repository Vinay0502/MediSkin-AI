import React, { useState } from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  Video,
  FileText,
  XCircle,
  RotateCcw,
  CheckCircle,
  AlertTriangle,
  Plus,
  Shield,
  Download,
  Check,
} from 'lucide-react';
import { UserProfile } from '../types/index.ts';
import { db } from '../services/db.ts';
import { AppointmentRecord, AppointmentStatus } from '../utils/appointmentRules.ts';

interface Props {
  currentUser: UserProfile;
  onNavigate: (view: string, params?: Record<string, any>) => void;
}

export const MyAppointmentsView: React.FC<Props> = ({ currentUser, onNavigate }) => {
  const [appointments, setAppointments] = useState<AppointmentRecord[]>(
    db.getAppointments({ userId: currentUser.id, role: currentUser.role })
  );
  const [filterTab, setFilterTab] = useState<'all' | 'upcoming' | 'completed'>('all');
  const [reschedulingApp, setReschedulingApp] = useState<AppointmentRecord | null>(null);
  const [cancellingApp, setCancellingApp] = useState<AppointmentRecord | null>(null);
  const [newDate, setNewDate] = useState<string>(
    new Date(Date.now() + 86400000).toISOString().split('T')[0]
  );
  const [newSlot, setNewSlot] = useState<string>('');
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  const refreshList = () => {
    setAppointments(db.getAppointments({ userId: currentUser.id, role: currentUser.role }));
  };

  const handleConfirmCancel = () => {
    if (!cancellingApp) return;

    const res = db.updateAppointmentStatus(
      cancellingApp.id,
      'Cancelled',
      currentUser.email,
      currentUser.role,
      'Cancelled by patient via portal'
    );

    if (res.success) {
      setActionFeedback(`Appointment ${cancellingApp.referenceCode} has been cancelled.`);
      setCancellingApp(null);
      refreshList();
    } else {
      setActionFeedback(res.error || 'Unable to cancel appointment.');
    }
  };

  const handleConfirmReschedule = () => {
    if (!reschedulingApp || !newSlot) return;

    const res = db.rescheduleAppointment(
      reschedulingApp.id,
      newDate,
      newSlot,
      currentUser.email,
      currentUser.role
    );

    if (res.success) {
      setActionFeedback(`Appointment ${reschedulingApp.referenceCode} successfully rescheduled to ${newDate} at ${newSlot}.`);
      setReschedulingApp(null);
      refreshList();
    } else {
      setActionFeedback(res.error || 'Reschedule request failed.');
    }
  };

  const handleDownloadSlip = (app: AppointmentRecord) => {
    const slipText = `
=============================================
MEDISKIN AI - CLINICAL CONSULTATION SLIP
=============================================
Reference Code: ${app.referenceCode}
Patient Name:   ${app.patientName}
Patient Email:  ${app.patientEmail}
Doctor:         ${app.doctorName} (${app.specialty})
Date & Time:    ${app.date} at ${app.timeSlot}
Mode:           ${app.mode}
Clinic Center:  ${app.clinicName || 'Bay Area Skin Pavilion'}
Reason:         ${app.reason}
Status:         ${app.status}
Issued:         ${new Date().toISOString()}
=============================================
Please present this verification slip upon clinic arrival.
    `.trim();

    const blob = new Blob([slipText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Consultation_Slip_${app.referenceCode}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    setActionFeedback(`Consultation slip downloaded for ${app.referenceCode}.`);
  };

  const filtered = appointments.filter((app) => {
    if (filterTab === 'upcoming') {
      return app.status === 'Confirmed' || app.status === 'Pending';
    }
    if (filterTab === 'completed') {
      return app.status === 'Completed' || app.status === 'Cancelled';
    }
    return true;
  });

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-teal-600 block mb-1">
            Care Management
          </span>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight">
            My Medical Consultations
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Review confirmed clinic appointments, video telehealth calls, and doctor intake instructions.
          </p>
        </div>

        <button
          onClick={() => onNavigate('doctors')}
          className="px-4 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1.5 active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Book New Visit</span>
        </button>
      </div>

      {/* Action Notification Alert */}
      {actionFeedback && (
        <div className="p-3.5 bg-teal-50 border border-teal-200 rounded-2xl text-teal-900 text-xs flex items-center justify-between">
          <span className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-teal-600 shrink-0" />
            {actionFeedback}
          </span>
          <button
            onClick={() => setActionFeedback(null)}
            className="text-teal-700 font-bold hover:underline"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        <button
          onClick={() => setFilterTab('all')}
          className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition ${
            filterTab === 'all'
              ? 'bg-teal-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          All Consultations ({appointments.length})
        </button>
        <button
          onClick={() => setFilterTab('upcoming')}
          className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition ${
            filterTab === 'upcoming'
              ? 'bg-teal-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Upcoming ({appointments.filter((a) => a.status === 'Confirmed' || a.status === 'Pending').length})
        </button>
        <button
          onClick={() => setFilterTab('completed')}
          className={`px-3.5 py-1.5 text-xs font-bold rounded-xl transition ${
            filterTab === 'completed'
              ? 'bg-teal-600 text-white shadow-xs'
              : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          Past / Cancelled ({appointments.filter((a) => a.status === 'Completed' || a.status === 'Cancelled').length})
        </button>
      </div>

      {/* Appointments List */}
      <div className="space-y-4">
        {filtered.length === 0 ? (
          <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-4">
            <div className="w-14 h-14 bg-teal-50 text-teal-600 rounded-2xl flex items-center justify-center mx-auto">
              <Calendar className="w-7 h-7" />
            </div>
            <div className="space-y-1">
              <h3 className="font-bold text-slate-900 text-base">No Consultations Found</h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                {filterTab === 'all'
                  ? 'You have not booked any dermatology consultations yet.'
                  : `No ${filterTab} appointments match your active tab filter.`}
              </p>
            </div>
            <button
              onClick={() => onNavigate('doctors')}
              className="px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition"
            >
              Browse Available Dermatologists
            </button>
          </div>
        ) : (
          filtered.map((app) => (
            <div
              key={app.id}
              className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition space-y-4"
            >
              {/* Top row */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center font-bold text-xs">
                    {app.mode === 'Video Call' ? <Video className="w-5 h-5" /> : <MapPin className="w-5 h-5" />}
                  </div>
                  <div>
                    <h3 className="font-black text-slate-900 text-sm sm:text-base">{app.doctorName}</h3>
                    <p className="text-xs text-slate-500">{app.specialty} • {app.mode}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-mono font-semibold px-2.5 py-1 bg-slate-100 rounded-lg text-slate-700">
                    Ref: {app.referenceCode}
                  </span>
                  <span
                    className={`text-[10px] uppercase font-bold px-2.5 py-1 rounded-full ${
                      app.status === 'Confirmed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : app.status === 'Pending'
                        ? 'bg-amber-100 text-amber-800'
                        : app.status === 'Completed'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {app.status}
                  </span>
                </div>
              </div>

              {/* Middle row: Schedule and Location */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                <div>
                  <span className="text-[10px] text-slate-400 font-semibold uppercase block mb-0.5">Scheduled Slot</span>
                  <p className="font-bold text-slate-900 flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-teal-600" />
                    <span>{app.date}</span>
                  </p>
                  <p className="text-slate-600 flex items-center gap-1.5 mt-0.5">
                    <Clock className="w-3.5 h-3.5 text-teal-600" />
                    <span>{app.timeSlot}</span>
                  </p>
                </div>

                {/* Reason / Notes */}
                <div>
                  <span className="text-[10px] text-slate-400 font-semibold uppercase block mb-0.5">Visit Purpose</span>
                  <p className="text-slate-600 line-clamp-2 italic bg-slate-50 p-2 rounded-lg text-[11px]">
                    "{app.reason}"
                  </p>
                  {app.notes && (
                    <p className="text-[11px] text-teal-800 font-medium mt-1">Doctor note: {app.notes}</p>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                <button
                  onClick={() => handleDownloadSlip(app)}
                  className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Slip</span>
                </button>

                <div className="flex items-center gap-2">
                  {(app.status === 'Confirmed' || app.status === 'Pending') && (
                    <>
                      <button
                        onClick={() => {
                          setReschedulingApp(app);
                          setNewDate(app.date);
                          setNewSlot('');
                        }}
                        className="px-3 py-1.5 border border-slate-200 hover:bg-slate-50 text-slate-700 rounded-xl text-xs font-semibold transition"
                      >
                        Reschedule
                      </button>

                      <button
                        onClick={() => setCancellingApp(app)}
                        className="px-3 py-1.5 text-rose-600 hover:bg-rose-50 rounded-xl text-xs font-semibold transition"
                      >
                        Cancel
                      </button>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Cancel Confirmation Modal */}
      {cancellingApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-100 text-rose-600 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="font-bold text-slate-900 text-base">Cancel Consultation?</h3>
              <p className="text-xs text-slate-500">
                Are you sure you want to cancel your consultation ({cancellingApp.referenceCode}) with <strong>{cancellingApp.doctorName}</strong> on {cancellingApp.date}?
              </p>
            </div>
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setCancellingApp(null)}
                className="flex-1 py-2.5 border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
              >
                Keep Appointment
              </button>
              <button
                onClick={handleConfirmCancel}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold rounded-xl transition"
              >
                Yes, Cancel Visit
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reschedule Modal */}
      {reschedulingApp && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-slate-900 text-sm">Reschedule Consultation</h3>
              <button
                onClick={() => setReschedulingApp(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Select a new date and open time slot with <strong>{reschedulingApp.doctorName}</strong>:
            </p>

            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">New Date</label>
                <input
                  type="date"
                  value={newDate}
                  min={new Date().toISOString().split('T')[0]}
                  onChange={(e) => {
                    setNewDate(e.target.value);
                    setNewSlot('');
                  }}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs outline-none"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-slate-700 block mb-1">Available Slots</label>
                <div className="grid grid-cols-2 gap-2">
                  {['09:00 AM', '10:00 AM', '01:30 PM', '03:00 PM'].map((slot) => (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => setNewSlot(slot)}
                      className={`p-2 rounded-xl text-xs font-semibold border transition ${
                        newSlot === slot ? 'bg-teal-600 text-white border-teal-600' : 'bg-slate-50 border-slate-200 text-slate-700'
                      }`}
                    >
                      {slot}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={() => setReschedulingApp(null)}
                className="flex-1 py-2.5 border border-slate-200 text-slate-700 text-xs font-semibold rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmReschedule}
                disabled={!newSlot}
                className="flex-1 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 text-white text-xs font-bold rounded-xl transition"
              >
                Save New Slot
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
