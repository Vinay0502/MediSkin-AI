import React, { useState } from 'react';
import {
  Search,
  Filter,
  CheckCircle2,
  Star,
  MapPin,
  Calendar,
  Video,
  Phone,
  ShieldCheck,
  Building,
  ArrowRight,
  Clock,
} from 'lucide-react';
import { DoctorProfile } from '../types/index.ts';

interface Props {
  doctors: DoctorProfile[];
  onNavigate: (view: string, params?: Record<string, any>) => void;
  prefilledReason?: string;
}

export const DoctorDirectoryView: React.FC<Props> = ({
  doctors,
  onNavigate,
  prefilledReason,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedSpecialty, setSelectedSpecialty] = useState('all');
  const [selectedMode, setSelectedMode] = useState('all');
  const [onlyVerified, setOnlyVerified] = useState(false);

  const specialties = ['all', ...Array.from(new Set(doctors.map((d) => d.specialty)))];

  const filteredDoctors = doctors.filter((doc) => {
    const matchesSearch =
      doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.specialty.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doc.hospitalAffiliation.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesSpecialty = selectedSpecialty === 'all' || doc.specialty === selectedSpecialty;
    const matchesMode = selectedMode === 'all' || doc.modes.includes(selectedMode as any);
    const matchesVerified = !onlyVerified || doc.verificationStatus === 'Verified';

    return matchesSearch && matchesSpecialty && matchesMode && matchesVerified;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="max-w-3xl">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-600 block mb-1">
          Dermatologist Discovery & Booking
        </span>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          Find Board-Certified Dermatologists
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2">
          Connect with vetted dermatologists, cutaneous surgeons, and pediatric skin specialists for in-person clinic visits or telehealth video consultations.
        </p>

        {prefilledReason && (
          <div className="mt-4 p-3 bg-teal-50 border border-teal-200 rounded-xl text-xs text-teal-900 flex items-center justify-between">
            <span>Clinical notes from your AI Screening are ready to attach to your appointment.</span>
            <span className="font-bold text-teal-700">Triage Active</span>
          </div>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          {/* Search Input */}
          <div className="md:col-span-5 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search by specialist name, hospital, or city..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-teal-500 focus:bg-white outline-none"
            />
          </div>

          {/* Specialty Dropdown */}
          <div className="md:col-span-3">
            <select
              value={selectedSpecialty}
              onChange={(e) => setSelectedSpecialty(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-teal-500 outline-none font-medium text-slate-700"
            >
              <option value="all">All Specialties</option>
              {specialties.filter((s) => s !== 'all').map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>

          {/* Consultation Mode */}
          <div className="md:col-span-2">
            <select
              value={selectedMode}
              onChange={(e) => setSelectedMode(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-teal-500 outline-none font-medium text-slate-700"
            >
              <option value="all">All Modes</option>
              <option value="In-Person">In-Person Only</option>
              <option value="Video Call">Video Telehealth</option>
              <option value="Audio Consultation">Audio Call</option>
            </select>
          </div>

          {/* Verified Toggle */}
          <div className="md:col-span-2 flex items-center">
            <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={onlyVerified}
                onChange={(e) => setOnlyVerified(e.target.checked)}
                className="rounded text-teal-600 focus:ring-teal-500"
              />
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
                Verified Only
              </span>
            </label>
          </div>
        </div>
      </div>

      {/* Doctor Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredDoctors.length === 0 ? (
          <div className="col-span-full bg-slate-50 rounded-2xl border border-slate-200 p-12 text-center text-slate-500 text-xs">
            No doctors matched your criteria. Try loosening your filter settings.
          </div>
        ) : (
          filteredDoctors.map((doc) => (
            <div
              key={doc.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition p-5 flex flex-col justify-between"
            >
              <div>
                {/* Header row */}
                <div className="flex items-start gap-3.5 mb-3">
                  <img
                    src={doc.avatarUrl}
                    alt={doc.name}
                    className="w-16 h-16 rounded-2xl object-cover ring-2 ring-slate-100 shrink-0"
                  />
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h3 className="font-bold text-slate-900 text-sm">{doc.name}</h3>
                      {doc.verificationStatus === 'Verified' ? (
                        <span className="inline-flex items-center gap-0.5 px-1.5 py-0.2 bg-teal-50 text-teal-700 text-[10px] font-bold rounded-md border border-teal-200">
                          <CheckCircle2 className="w-3 h-3 text-teal-600" /> Verified
                        </span>
                      ) : (
                        <span className="px-1.5 py-0.2 bg-amber-50 text-amber-700 text-[10px] font-bold rounded-md">
                          {doc.verificationStatus}
                        </span>
                      )}
                    </div>
                    <p className="text-xs font-medium text-teal-700 mt-0.5">{doc.title} • {doc.specialty}</p>
                    <p className="text-[11px] text-slate-400">{doc.experienceYears} Years Experience</p>
                  </div>
                </div>

                {/* Rating & Location */}
                <div className="flex items-center gap-3 text-xs text-slate-600 mb-3 bg-slate-50 p-2.5 rounded-xl">
                  <div className="flex items-center gap-1 font-bold text-amber-600">
                    <Star className="w-3.5 h-3.5 fill-amber-400 stroke-amber-500" />
                    <span>{doc.rating}</span>
                    <span className="text-[10px] font-normal text-slate-400">({doc.reviewCount})</span>
                  </div>
                  <span className="text-slate-300">•</span>
                  <div className="flex items-center gap-1 text-[11px] truncate">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{doc.city}, {doc.state}</span>
                  </div>
                </div>

                {/* Hospital Affiliation & Bio */}
                <div className="space-y-1.5 mb-4 text-xs text-slate-600">
                  <div className="flex items-center gap-1.5 text-[11px] font-medium text-slate-700">
                    <Building className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                    <span className="truncate">{doc.hospitalAffiliation}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed">
                    {doc.bio}
                  </p>
                </div>

                {/* Modes */}
                <div className="flex flex-wrap gap-1.5 mb-4">
                  {doc.modes.map((mode) => (
                    <span
                      key={mode}
                      className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-[10px] font-semibold"
                    >
                      {mode}
                    </span>
                  ))}
                </div>
              </div>

              {/* Bottom Card Actions */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <div>
                  <span className="text-[10px] text-slate-400 block font-medium">Standard Fee</span>
                  <span className="text-sm font-extrabold text-slate-900">${doc.consultationFee}</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onNavigate('doctor-profile', { doctorId: doc.id })}
                    className="px-3 py-2 text-slate-700 hover:bg-slate-100 rounded-xl text-xs font-semibold transition"
                  >
                    Profile
                  </button>
                  <button
                    onClick={() => onNavigate('booking', { doctorId: doc.id, prefilledReason })}
                    className="px-3.5 py-2 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs transition"
                  >
                    Book Slot
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
