import React, { useState, useRef } from 'react';
import {
  Upload,
  Camera,
  AlertTriangle,
  CheckCircle,
  HelpCircle,
  Sparkles,
  ArrowRight,
  Shield,
  FileText,
  RotateCcw,
  Zap,
} from 'lucide-react';
import { SAMPLE_LESION_CASES, runSkinScreeningInference, CompleteScreeningReport } from '../services/aiVisionEngine.ts';
import { db } from '../services/db.ts';
import { UserProfile } from '../types/index.ts';

interface Props {
  onAnalysisComplete: (report: CompleteScreeningReport, rawImageUrl: string) => void;
  currentUser: UserProfile;
  onOpenDisclaimer: () => void;
}

export const AnalysisView: React.FC<Props> = ({
  onAnalysisComplete,
  currentUser,
  onOpenDisclaimer,
}) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedFileName, setSelectedFileName] = useState<string | null>(null);
  const [isEvolving, setIsEvolving] = useState<boolean>(false);
  const [hasSymptoms, setHasSymptoms] = useState<boolean>(false);
  const [consentAgreed, setConsentAgreed] = useState<boolean>(true);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisStep, setAnalysisStep] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    setErrorMessage(null);
    const file = e.target.files?.[0];
    if (!file) return;

    // Format check
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      setErrorMessage('Unsupported file format. Please upload a JPEG, PNG, or WEBP image.');
      return;
    }

    // Size limit check (max 10MB)
    if (file.size > 10 * 1024 * 1024) {
      setErrorMessage('File size exceeds 10MB limit. Please provide a compressed photo.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      setSelectedImage(event.target?.result as string);
      setSelectedFileName(file.name);
    };
    reader.onerror = () => {
      setErrorMessage('Could not read the selected image file.');
    };
    reader.readAsDataURL(file);
  };

  const handleSelectSample = (sample: (typeof SAMPLE_LESION_CASES)[0]) => {
    setErrorMessage(null);
    setSelectedImage(sample.imageUrl);
    setSelectedFileName(`${sample.name} (${sample.category})`);
  };

  const handleStartAnalysis = async () => {
    if (!selectedImage) {
      setErrorMessage('Please select or upload an image of the skin spot to proceed.');
      return;
    }
    if (!consentAgreed) {
      setErrorMessage('Please check the acknowledgment box indicating understanding of non-diagnostic preliminary scope.');
      return;
    }

    setErrorMessage(null);
    setIsAnalyzing(true);

    try {
      setAnalysisStep('1/4 - Verifying optical clarity and Laplacian blur variance...');
      await new Promise((r) => setTimeout(r, 600));

      setAnalysisStep('2/4 - Calculating ABCDE asymmetry, border irregularity, and pigment distribution...');
      await new Promise((r) => setTimeout(r, 650));

      setAnalysisStep('3/4 - Running MobileNetV3 + HAM10000 classification ensemble...');
      const report = await runSkinScreeningInference(selectedImage, isEvolving);

      setAnalysisStep('4/4 - Generating Grad-CAM attention heatmap & uncertainty policy...');
      await new Promise((r) => setTimeout(r, 500));

      // Save to patient screening history if consented
      if (currentUser.medicalHistoryConsent && report.screeningResult.primaryCondition) {
        db.saveScreeningRecord({
          patientId: currentUser.id,
          imageUrl: selectedImage,
          conditionId: report.screeningResult.primaryCondition.conditionId,
          conditionName: report.screeningResult.primaryCondition.conditionName,
          category: report.screeningResult.primaryCondition.category,
          confidence: report.screeningResult.calibratedConfidence,
          urgency: report.screeningResult.clinicalUrgency,
          uncertaintyFlag: report.screeningResult.uncertaintyFlag,
          notes: isEvolving ? 'Patient indicated recent changes in lesion size/shape.' : undefined,
        });
      }

      setIsAnalyzing(false);
      onAnalysisComplete(report, selectedImage);
    } catch (err: any) {
      setIsAnalyzing(false);
      setErrorMessage(err.message || 'An unexpected error occurred during image processing. Please try another photo.');
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Title & Guidance Header */}
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 border border-teal-200 text-teal-800 text-xs font-bold mb-3">
          <Sparkles className="w-3.5 h-3.5 text-teal-600" />
          <span>Stage 1: Image Capture & Quality Assessment</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          AI Skin Lesion Screening
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2">
          Upload a clear, focused photograph of a mole, spot, or skin lesion. Our vision engine checks optical focus before running deep-learning classification.
        </p>
      </div>

      {/* Error Banner */}
      {errorMessage && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex items-start gap-3 text-rose-800 text-xs animate-in fade-in">
          <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-bold">Image Processing Notice</p>
            <p className="mt-0.5">{errorMessage}</p>
          </div>
        </div>
      )}

      {/* Main Upload Box */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-6 sm:p-8 space-y-6">
        {!selectedImage ? (
          <div>
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-teal-300 hover:border-teal-500 bg-teal-50/30 hover:bg-teal-50/60 rounded-2xl p-8 sm:p-12 text-center cursor-pointer transition flex flex-col items-center justify-center space-y-3 group"
            >
              <div className="w-16 h-16 rounded-2xl bg-teal-100 text-teal-700 flex items-center justify-center group-hover:scale-105 transition">
                <Upload className="w-8 h-8" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-bold text-slate-800">
                  Click to browse or drag and drop image here
                </p>
                <p className="text-xs text-slate-500">
                  Supported formats: JPEG, PNG, WEBP (Maximum size: 10MB)
                </p>
              </div>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-semibold text-slate-700 shadow-xs">
                <Camera className="w-3.5 h-3.5 text-teal-600" />
                Select from Device / Camera
              </span>
            </div>
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
            />
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row items-center gap-6 p-4 bg-slate-50 rounded-2xl border border-slate-200">
              <div className="w-48 h-48 rounded-xl overflow-hidden border border-slate-200 bg-black shrink-0 relative group">
                <img
                  src={selectedImage}
                  alt="Selected skin spot"
                  className="w-full h-full object-cover"
                />
                <button
                  onClick={() => { setSelectedImage(null); setSelectedFileName(null); }}
                  className="absolute bottom-2 right-2 px-2 py-1 bg-slate-900/80 hover:bg-slate-900 text-white rounded text-[10px] font-semibold flex items-center gap-1 backdrop-blur-xs"
                >
                  <RotateCcw className="w-3 h-3" />
                  Change
                </button>
              </div>

              <div className="space-y-2 text-xs flex-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 text-sm">{selectedFileName || 'Captured Skin Spot'}</span>
                  <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 font-semibold rounded text-[10px]">
                    Ready for analysis
                  </span>
                </div>
                <p className="text-slate-500 text-[11px]">
                  Image loaded into client-side evaluation canvas. Optical sharpness, illumination balance, and feature extraction will execute locally.
                </p>

                <div className="pt-2 border-t border-slate-200 flex flex-wrap gap-2 text-[11px] text-slate-600">
                  <span className="flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5 text-teal-600" /> Formats validated
                  </span>
                  <span className="flex items-center gap-1">
                    <CheckCircle className="w-3.5 h-3.5 text-teal-600" /> Private in-memory buffer
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 1-Click Interactive Sample Images Strip */}
        <div className="pt-2">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-500" />
              Or Test Instant Dermoscopy Samples
            </span>
            <span className="text-[11px] text-slate-400">Click any card to load</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {SAMPLE_LESION_CASES.map((sample) => (
              <button
                key={sample.id}
                onClick={() => handleSelectSample(sample)}
                className={`p-2.5 rounded-xl border text-left transition flex flex-col justify-between ${
                  selectedImage === sample.imageUrl
                    ? 'border-teal-500 bg-teal-50/50 ring-2 ring-teal-500/20'
                    : 'border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50'
                }`}
              >
                <div className="aspect-video w-full rounded-lg overflow-hidden mb-2 bg-slate-100">
                  <img
                    src={sample.imageUrl}
                    alt={sample.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <p className="font-bold text-[11px] text-slate-800 line-clamp-1">{sample.name}</p>
                  <p className="text-[10px] text-teal-700 font-semibold mt-0.5">{sample.category}</p>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Clinical History & Consent Form */}
        <div className="space-y-4 pt-4 border-t border-slate-100">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">Clinical History Checklist</h4>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
            <label className="flex items-start gap-2.5 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
              <input
                type="checkbox"
                checked={isEvolving}
                onChange={(e) => setIsEvolving(e.target.checked)}
                className="mt-0.5 text-teal-600 rounded focus:ring-teal-500"
              />
              <div>
                <span className="font-semibold text-slate-800 block">Lesion is Evolving (E)</span>
                <span className="text-[11px] text-slate-500">Noticeable change in size, shape, surface elevation, or color in past 3 months.</span>
              </div>
            </label>

            <label className="flex items-start gap-2.5 p-3 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer">
              <input
                type="checkbox"
                checked={hasSymptoms}
                onChange={(e) => setHasSymptoms(e.target.checked)}
                className="mt-0.5 text-teal-600 rounded focus:ring-teal-500"
              />
              <div>
                <span className="font-semibold text-slate-800 block">Associated Symptoms</span>
                <span className="text-[11px] text-slate-500">Persistent itching, bleeding, crusting, stinging, or localized pain.</span>
              </div>
            </label>
          </div>

          {/* Mandatory Non-Diagnostic Acknowledgment */}
          <div className="p-3.5 bg-amber-50/70 rounded-xl border border-amber-200/80 text-xs">
            <label className="flex items-start gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={consentAgreed}
                onChange={(e) => setConsentAgreed(e.target.checked)}
                className="mt-0.5 text-teal-600 rounded focus:ring-teal-500"
              />
              <span className="text-amber-900 leading-relaxed text-[11px]">
                <strong>Clinical Disclosure:</strong> I understand that MediSkin AI provides educational, preliminary screening heuristics. It is <strong>not</strong> a medical diagnosis. Concerning or changing lesions require timely evaluation by a qualified healthcare professional.
              </span>
            </label>
          </div>
        </div>

        {/* Progress or Submit Action */}
        <div className="pt-2">
          {isAnalyzing ? (
            <div className="p-6 bg-teal-50 rounded-2xl border border-teal-200 text-center space-y-3">
              <div className="w-8 h-8 border-3 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto" />
              <div>
                <p className="font-bold text-teal-900 text-sm">Processing Dermoscopic Scan</p>
                <p className="text-xs text-teal-700 mt-1 font-mono">{analysisStep}</p>
              </div>
              <div className="w-48 h-1.5 bg-teal-200 rounded-full mx-auto overflow-hidden">
                <div className="h-full bg-teal-600 animate-pulse w-3/4 rounded-full" />
              </div>
            </div>
          ) : (
            <button
              onClick={handleStartAnalysis}
              disabled={!selectedImage || !consentAgreed}
              className="w-full py-4 bg-teal-600 hover:bg-teal-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white font-bold text-sm rounded-xl shadow-md shadow-teal-600/20 transition active:scale-98 flex items-center justify-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>Run AI Skin Analysis</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
