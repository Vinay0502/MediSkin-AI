import React, { useState } from 'react';
import {
  Search,
  Building2,
  MapPin,
  Phone,
  Clock,
  ShieldCheck,
  HeartPulse,
  Navigation,
  Star,
  ExternalLink,
} from 'lucide-react';
import { HospitalFacility } from '../types/index.ts';

interface Props {
  facilities: HospitalFacility[];
  onNavigate: (view: string, params?: Record<string, any>) => void;
}

export const HospitalSearchView: React.FC<Props> = ({ facilities, onNavigate }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterEmergency, setFilterEmergency] = useState(false);
  const [filterDermOnly, setFilterDermOnly] = useState(false);
  const [selectedFacility, setSelectedFacility] = useState<HospitalFacility | null>(facilities[0] || null);

  const filteredFacilities = facilities.filter((f) => {
    const matchesSearch =
      f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.facilityType.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesEmergency = !filterEmergency || f.emergencyCare;
    const matchesDerm = !filterDermOnly || f.dermatologyDepartment;

    return matchesSearch && matchesEmergency && matchesDerm;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="max-w-3xl">
        <span className="text-xs font-bold uppercase tracking-wider text-teal-600 block mb-1">
          Healthcare Facility & Clinic Directory
        </span>
        <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
          Hospitals & Dermatology Centers
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 mt-2">
          Locate certified cutaneous oncology institutes, hospital dermatology clinics, and urgent skin care centers for in-person evaluations and surgical biopsies.
        </p>
      </div>

      {/* Filter / Search Controls */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3">
          <div className="md:col-span-6 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="Search by facility name, city, or specialty..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:ring-2 focus:ring-teal-500 focus:bg-white outline-none"
            />
          </div>

          <div className="md:col-span-3 flex items-center">
            <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={filterEmergency}
                onChange={(e) => setFilterEmergency(e.target.checked)}
                className="rounded text-teal-600 focus:ring-teal-500"
              />
              <span className="flex items-center gap-1">
                <HeartPulse className="w-3.5 h-3.5 text-rose-500" />
                24/7 Emergency Care
              </span>
            </label>
          </div>

          <div className="md:col-span-3 flex items-center">
            <label className="flex items-center gap-2 text-xs font-semibold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={filterDermOnly}
                onChange={(e) => setFilterDermOnly(e.target.checked)}
                className="rounded text-teal-600 focus:ring-teal-500"
              />
              <span>Dermatology Department</span>
            </label>
          </div>
        </div>
      </div>

      {/* 2-Column Layout: Facility List & Interactive Map Visualizer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Facilities List */}
        <div className="lg:col-span-7 space-y-4">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
            Available Clinics ({filteredFacilities.length})
          </span>

          {filteredFacilities.length === 0 ? (
            <div className="bg-slate-50 rounded-2xl border border-slate-200 p-8 text-center text-xs text-slate-500">
              No medical facilities matched your search parameters.
            </div>
          ) : (
            filteredFacilities.map((facility) => {
              const isSelected = selectedFacility?.id === facility.id;
              return (
                <div
                  key={facility.id}
                  onClick={() => setSelectedFacility(facility)}
                  className={`p-5 rounded-2xl border transition cursor-pointer ${
                    isSelected
                      ? 'border-teal-500 bg-teal-50/30 shadow-md ring-2 ring-teal-500/10'
                      : 'border-slate-200 bg-white hover:border-slate-300 shadow-xs'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-[10px] font-bold px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md">
                        {facility.facilityType}
                      </span>
                      <h3 className="text-base font-bold text-slate-900 mt-1">{facility.name}</h3>
                    </div>

                    <div className="flex items-center gap-1 font-bold text-xs text-amber-600 bg-amber-50 px-2 py-1 rounded-lg">
                      <Star className="w-3.5 h-3.5 fill-amber-400 stroke-amber-500" />
                      <span>{facility.rating}</span>
                    </div>
                  </div>

                  <div className="mt-3 space-y-1.5 text-xs text-slate-600">
                    <div className="flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{facility.address}, {facility.city}, {facility.state}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{facility.phone}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span>{facility.operatingHours}</span>
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex flex-wrap gap-1">
                      {facility.acceptedInsurances.slice(0, 3).map((ins) => (
                        <span key={ins} className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded">
                          {ins}
                        </span>
                      ))}
                    </div>

                    <a
                      href={`https://maps.google.com/?q=${encodeURIComponent(`${facility.name} ${facility.address} ${facility.city}`)}`}
                      target="_blank"
                      rel="noreferrer"
                      onClick={(e) => e.stopPropagation()}
                      className="text-xs font-semibold text-teal-700 hover:text-teal-800 flex items-center gap-1"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>Directions</span>
                    </a>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Right Column: Interactive Simulated Map & Selected Details */}
        <div className="lg:col-span-5 sticky top-20 space-y-4">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-5 space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center justify-between">
              <span>Facility Geographic Pin</span>
              <span className="text-[10px] text-teal-600 font-normal">Real Lat/Lng Mapping</span>
            </h3>

            {/* Simulated Map Canvas View */}
            <div className="relative aspect-4/3 w-full rounded-2xl overflow-hidden bg-slate-900 border border-slate-200 flex items-center justify-center p-4 text-center">
              {/* Stylized Map Grid Background */}
              <div
                className="absolute inset-0 opacity-20"
                style={{
                  backgroundImage: 'radial-gradient(#38bdf8 1px, transparent 1px), radial-gradient(#38bdf8 1px, #0f172a 1px)',
                  backgroundSize: '24px 24px',
                }}
              />

              {/* Map Road Lines */}
              <svg className="absolute inset-0 w-full h-full opacity-30 stroke-sky-400" fill="none">
                <path d="M0,80 Q150,120 300,50 T600,100" strokeWidth="3" />
                <path d="M120,0 Q180,180 200,350" strokeWidth="2" strokeDasharray="4 4" />
                <path d="M250,0 Q260,140 380,300" strokeWidth="2" />
              </svg>

              {/* Pinpoint Markers */}
              {filteredFacilities.map((fac, idx) => {
                const isSelected = selectedFacility?.id === fac.id;
                // Distributed relative positions for interactive pins
                const topPercent = 25 + (idx * 14);
                const leftPercent = 20 + ((idx * 18) % 65);
                return (
                  <button
                    key={fac.id}
                    onClick={() => setSelectedFacility(fac)}
                    style={{ top: `${topPercent}%`, left: `${leftPercent}%` }}
                    className={`absolute transform -translate-x-1/2 -translate-y-1/2 p-2 rounded-full transition-all ${
                      isSelected
                        ? 'bg-teal-500 text-white scale-125 z-10 shadow-lg ring-4 ring-teal-400/40 animate-bounce'
                        : 'bg-slate-800 text-teal-300 hover:scale-110 border border-teal-500/50'
                    }`}
                    title={fac.name}
                  >
                    <Building2 className="w-4 h-4" />
                  </button>
                );
              })}

              <div className="absolute bottom-3 left-3 right-3 p-2.5 bg-slate-950/80 backdrop-blur-md rounded-xl text-left text-white border border-slate-800">
                <p className="text-[11px] font-bold text-teal-400 truncate">{selectedFacility?.name}</p>
                <p className="text-[10px] text-slate-300 truncate">{selectedFacility?.address}, {selectedFacility?.city}</p>
              </div>
            </div>

            {/* Selected Facility Details */}
            {selectedFacility && (
              <div className="space-y-3 pt-2 text-xs">
                <div className="p-3 bg-slate-50 rounded-xl space-y-1.5 border border-slate-100">
                  <div className="flex justify-between text-slate-500">
                    <span>Emergency Services:</span>
                    <span className="font-semibold text-slate-800">
                      {selectedFacility.emergencyCare ? 'Available 24/7' : 'Scheduled Hours'}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Dermatology Department:</span>
                    <span className="font-semibold text-slate-800">
                      {selectedFacility.dermatologyDepartment ? 'Specialized Outpatient Wing' : 'Consultative Only'}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-500">
                    <span>Direct Desk Contact:</span>
                    <span className="font-bold text-teal-700">{selectedFacility.phone}</span>
                  </div>
                </div>

                <a
                  href={`tel:${selectedFacility.phone.replace(/[^0-9]/g, '')}`}
                  className="w-full py-2.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call Hospital Intake Desk</span>
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
