import test from 'node:test';
import assert from 'node:assert/strict';
import {
  evaluateImageQuality,
  applyClinicalUncertaintyPolicy,
  calculateAbcdeRisk,
  PredictionCandidate,
} from './visionRules.ts';

test('evaluateImageQuality flags severe blur and underexposure', () => {
  const badImage = {
    width: 250,
    height: 250,
    blurVariance: 30, // heavy blur
    brightnessMean: 35, // dark
  };

  const report = evaluateImageQuality(badImage);
  assert.equal(report.isAcceptable, false);
  assert.ok(report.issues.some((i) => i.includes('blur')));
  assert.ok(report.issues.some((i) => i.includes('underexposed')));
});

test('evaluateImageQuality passes crisp, well-lit image', () => {
  const goodImage = {
    width: 500,
    height: 500,
    blurVariance: 180,
    brightnessMean: 135,
  };

  const report = evaluateImageQuality(goodImage);
  assert.equal(report.isAcceptable, true);
  assert.equal(report.issues.length, 0);
  assert.equal(report.score, 100);
});

test('applyClinicalUncertaintyPolicy flags ambiguity when margin between top predictions is small', () => {
  const candidates: PredictionCandidate[] = [
    {
      conditionId: 'mel',
      conditionName: 'Melanoma',
      category: 'Malignant',
      probability: 0.46,
      severityLevel: 'urgent',
    },
    {
      conditionId: 'bkl',
      conditionName: 'Benign Keratosis',
      category: 'Benign',
      probability: 0.42,
      severityLevel: 'low',
    },
  ];

  const evalResult = applyClinicalUncertaintyPolicy(candidates, 85);
  assert.equal(evalResult.status, 'uncertain');
  assert.equal(evalResult.uncertaintyFlag, true);
  assert.match(evalResult.uncertaintyMessage || '', /Unable to provide a reliable preliminary classification/i);
  assert.equal(evalResult.clinicalUrgency, 'urgent'); // Safety principle: Malignant candidate elevates urgency!
});

test('calculateAbcdeRisk accumulates points and classifies high risk', () => {
  const highRiskLesion = {
    isAsymmetric: true,
    hasIrregularBorder: true,
    colorCount: 4,
    diameterMm: 7.5,
    isEvolving: true,
  };

  const result = calculateAbcdeRisk(highRiskLesion);
  assert.equal(result.riskRating, 'High');
  assert.ok(result.totalScore >= 6);
  assert.equal(result.flaggedItems.length, 5);
});
