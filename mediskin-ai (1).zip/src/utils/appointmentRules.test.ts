import test from 'node:test';
import assert from 'node:assert/strict';
import {
  validateBookingRequest,
  getAvailableSlotsForDate,
  canTransitionAppointmentStatus,
  generateBookingReference,
  AppointmentRecord,
  DoctorSchedule,
} from './appointmentRules.ts';

const mockSchedule: DoctorSchedule = {
  doctorId: 'doc-1',
  availableDays: [1, 2, 3, 4, 5], // Mon - Fri
  slots: ['09:00 AM', '10:00 AM', '11:00 AM', '02:00 PM', '03:00 PM'],
  vacationDates: ['2026-10-25'],
};

const existingAppointments: AppointmentRecord[] = [
  {
    id: 'app-1',
    referenceCode: 'MSK-2026-1001',
    patientId: 'pat-1',
    patientName: 'Jane Doe',
    patientEmail: 'jane@example.com',
    patientPhone: '+1-555-0100',
    doctorId: 'doc-1',
    doctorName: 'Dr. Sarah Lin',
    specialty: 'Dermatology & Dermato-Oncology',
    date: '2026-10-22', // Thursday
    timeSlot: '09:00 AM',
    mode: 'In-Person',
    reason: 'Suspicious mole on back',
    status: 'Confirmed',
    createdAt: '2026-10-20T10:00:00Z',
    updatedAt: '2026-10-20T10:00:00Z',
  },
  {
    id: 'app-2',
    referenceCode: 'MSK-2026-1002',
    patientId: 'pat-2',
    patientName: 'Carlos Ray',
    patientEmail: 'carlos@example.com',
    patientPhone: '+1-555-0102',
    doctorId: 'doc-1',
    doctorName: 'Dr. Sarah Lin',
    specialty: 'Dermatology & Dermato-Oncology',
    date: '2026-10-22',
    timeSlot: '11:00 AM',
    mode: 'Video Call',
    reason: 'Follow-up consultation',
    status: 'Pending',
    createdAt: '2026-10-20T11:00:00Z',
    updatedAt: '2026-10-20T11:00:00Z',
  },
];

test('booking validation accepts valid available slot on working day', () => {
  const result = validateBookingRequest(
    {
      doctorId: 'doc-1',
      date: '2026-10-22', // Thursday
      timeSlot: '10:00 AM', // Unbooked
    },
    existingAppointments,
    mockSchedule,
    '2026-10-20'
  );

  assert.equal(result.isValid, true);
  assert.equal(result.error, undefined);
});

test('booking validation rejects already booked slots (conflict prevention)', () => {
  const result = validateBookingRequest(
    {
      doctorId: 'doc-1',
      date: '2026-10-22',
      timeSlot: '09:00 AM', // Already confirmed
    },
    existingAppointments,
    mockSchedule,
    '2026-10-20'
  );

  assert.equal(result.isValid, false);
  assert.match(result.error || '', /already been reserved/i);
});

test('booking validation rejects past dates', () => {
  const result = validateBookingRequest(
    {
      doctorId: 'doc-1',
      date: '2026-10-18', // Past
      timeSlot: '10:00 AM',
    },
    existingAppointments,
    mockSchedule,
    '2026-10-20'
  );

  assert.equal(result.isValid, false);
  assert.match(result.error || '', /past dates/i);
});

test('booking validation rejects non-working days (Sunday)', () => {
  const result = validateBookingRequest(
    {
      doctorId: 'doc-1',
      date: '2026-10-25', // Sunday
      timeSlot: '10:00 AM',
    },
    existingAppointments,
    mockSchedule,
    '2026-10-20'
  );

  assert.equal(result.isValid, false);
});

test('getAvailableSlotsForDate correctly excludes booked slots', () => {
  const openSlots = getAvailableSlotsForDate('doc-1', '2026-10-22', mockSchedule.slots, existingAppointments);
  assert.deepEqual(openSlots, ['10:00 AM', '02:00 PM', '03:00 PM']);
});

test('role-based status transitions enforce patient permissions', () => {
  // Patient can cancel their pending or confirmed appointment
  assert.equal(canTransitionAppointmentStatus('Pending', 'Cancelled', 'patient'), true);
  assert.equal(canTransitionAppointmentStatus('Confirmed', 'Cancelled', 'patient'), true);
  // Patient CANNOT mark their appointment Completed or Confirm it
  assert.equal(canTransitionAppointmentStatus('Pending', 'Confirmed', 'patient'), false);
  assert.equal(canTransitionAppointmentStatus('Confirmed', 'Completed', 'patient'), false);
});

test('role-based status transitions enforce doctor permissions', () => {
  // Doctor can confirm a pending appointment
  assert.equal(canTransitionAppointmentStatus('Pending', 'Confirmed', 'doctor'), true);
  // Doctor can complete a confirmed appointment
  assert.equal(canTransitionAppointmentStatus('Confirmed', 'Completed', 'doctor'), true);
  // Completed is a terminal state
  assert.equal(canTransitionAppointmentStatus('Completed', 'Pending', 'doctor'), false);
  assert.equal(canTransitionAppointmentStatus('Cancelled', 'Confirmed', 'doctor'), false);
});

test('generateBookingReference formats standard code', () => {
  const ref = generateBookingReference(123456);
  assert.match(ref, /^MSK-2026-\d{4}$/);
});
