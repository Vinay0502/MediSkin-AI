/**
 * MediSkin AI - Authentication, Rate Limiting, and RLS Rules
 */

export interface PasswordStrengthResult {
  score: number; // 0 - 4
  level: 'Weak' | 'Fair' | 'Good' | 'Strong';
  hasMinLength: boolean;
  hasUpper: boolean;
  hasLower: boolean;
  hasNumber: boolean;
  hasSpecial: boolean;
}

export function evaluatePasswordStrength(password: string): PasswordStrengthResult {
  const hasMinLength = password.length >= 8;
  const hasUpper = /[A-Z]/.test(password);
  const hasLower = /[a-z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecial = /[^A-Za-z0-9]/.test(password);

  let score = 0;
  if (hasMinLength) score++;
  if (hasUpper && hasLower) score++;
  if (hasNumber) score++;
  if (hasSpecial) score++;

  const levels: PasswordStrengthResult['level'][] = ['Weak', 'Weak', 'Fair', 'Good', 'Strong'];
  const level = levels[score] || 'Weak';

  return {
    score,
    level,
    hasMinLength,
    hasUpper,
    hasLower,
    hasNumber,
    hasSpecial,
  };
}

export function validateEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

/**
 * Rate Limiter for Login / Sensitive Operations
 * Locks account after 4 consecutive failures for 60 seconds
 */
export function checkRateLimit(
  failedAttempts: number,
  lastFailedTimestamp: number,
  now: number = Date.now(),
  maxAttempts: number = 4,
  lockoutDurationMs: number = 60000
): { isLocked: boolean; remainingSeconds: number } {
  if (failedAttempts >= maxAttempts) {
    const elapsed = now - lastFailedTimestamp;
    if (elapsed < lockoutDurationMs) {
      const remainingSeconds = Math.ceil((lockoutDurationMs - elapsed) / 1000);
      return { isLocked: true, remainingSeconds };
    }
  }
  return { isLocked: false, remainingSeconds: 0 };
}

/**
 * Row Level Security (RLS) Policy Engine
 * Enforces database isolation rules per HIPAA / security guidelines:
 * - Patients can only access their own appointments, screenings, and private data.
 * - Doctors can only access appointments assigned to them.
 * - Admins can access all records for compliance and audit.
 */
export function enforceRLS(
  actor: { id: string; role: 'patient' | 'doctor' | 'admin' },
  resourceOwnerId: string,
  operation: 'SELECT' | 'INSERT' | 'UPDATE' | 'DELETE'
): { allowed: boolean; reason?: string } {
  if (actor.role === 'admin') {
    return { allowed: true };
  }

  if (actor.role === 'patient') {
    if (actor.id === resourceOwnerId) {
      return { allowed: true };
    }
    return {
      allowed: false,
      reason: `RLS Access Denied: Patient ${actor.id} cannot perform ${operation} on resource owned by ${resourceOwnerId}.`,
    };
  }

  if (actor.role === 'doctor') {
    if (actor.id === resourceOwnerId) {
      return { allowed: true };
    }
    return {
      allowed: false,
      reason: `RLS Access Denied: Doctor ${actor.id} is not authorized for resource of ${resourceOwnerId}.`,
    };
  }

  return { allowed: false, reason: 'RLS Access Denied: Unknown actor role.' };
}
