/**
 * MediSkin AI - AI Vision & Clinical Uncertainty Policies
 * Handles image quality verification (blur, illumination, resolution),
 * calibrated confidence metrics, and out-of-distribution uncertainty flags.
 */

export interface ImageQualityMetrics {
  width: number;
  height: number;
  blurVariance: number; // Laplacian variance (higher = sharper, < 80 = blurry)
  brightnessMean: number; // 0-255 scale (ideal: 70 - 200)
}

export interface ImageQualityReport {
  isAcceptable: boolean;
  score: number; // 0 - 100
  issues: string[];
  recommendations: string[];
}

export interface PredictionCandidate {
  conditionId: string;
  conditionName: string;
  category: 'Benign' | 'Pre-Malignant' | 'Malignant' | 'Inflammatory';
  probability: number; // 0.0 to 1.0
  severityLevel: 'low' | 'moderate' | 'high' | 'urgent';
}

export interface ScreeningEvaluationResult {
  status: 'conclusive' | 'uncertain' | 'rejected_quality';
  primaryCondition?: PredictionCandidate;
  topDifferentials: PredictionCandidate[];
  calibratedConfidence: number; // percentage 0-100
  uncertaintyFlag: boolean;
  uncertaintyMessage?: string;
  clinicalUrgency: 'low' | 'moderate' | 'high' | 'urgent';
  recommendedAction: string;
}

/**
 * Validates optical quality of skin lesion image.
 * Fails fast if image is too small, dark, blown out, or severely blurred.
 */
export function evaluateImageQuality(metrics: ImageQualityMetrics): ImageQualityReport {
  const issues: string[] = [];
  const recommendations: string[] = [];
  let score = 100;

  // 1. Resolution check
  if (metrics.width < 180 || metrics.height < 180) {
    score -= 40;
    issues.push(`Resolution is low (${metrics.width}x${metrics.height}px). Minimum recommended is 200x200px.`);
    recommendations.push('Capture a closer or higher-resolution photo of the skin lesion.');
  }

  // 2. Lighting / Exposure check
  if (metrics.brightnessMean < 50) {
    score -= 35;
    issues.push('Image is severely underexposed (too dark).');
    recommendations.push('Ensure even, indirect lighting without heavy shadows.');
  } else if (metrics.brightnessMean > 225) {
    score -= 35;
    issues.push('Image is overexposed / flash washout detected.');
    recommendations.push('Turn off direct camera flash to prevent glare on the skin.');
  }

  // 3. Blur detection (Laplacian variance)
  if (metrics.blurVariance < 75) {
    score -= 45;
    issues.push('Significant motion blur or focus softness detected.');
    recommendations.push('Hold the device steady or tap to focus directly on the lesion center.');
  }

  const finalScore = Math.max(0, score);
  const isAcceptable = finalScore >= 50;

  return {
    isAcceptable,
    score: finalScore,
    issues,
    recommendations,
  };
}

/**
 * Evaluates predictions under the medical safety uncertainty policy:
 * - If top probability < 0.45 or margin to runner-up is tiny, mark as uncertain
 * - High-risk classes (Melanoma, Basal Cell Carcinoma) trigger urgent/high clinical guidance regardless of model softmax
 * - Never claims disease diagnosis confirmation
 */
export function applyClinicalUncertaintyPolicy(
  rawCandidates: PredictionCandidate[],
  qualityScore: number
): ScreeningEvaluationResult {
  if (qualityScore < 50 || rawCandidates.length === 0) {
    return {
      status: 'rejected_quality',
      topDifferentials: [],
      calibratedConfidence: 0,
      uncertaintyFlag: true,
      uncertaintyMessage: 'Unable to provide a reliable preliminary classification for this image due to insufficient image clarity. Please consult a qualified healthcare professional.',
      clinicalUrgency: 'moderate',
      recommendedAction: 'Retake the photo in good lighting or schedule an in-person dermatology check.',
    };
  }

  // Sort descending by probability
  const sorted = [...rawCandidates].sort((a, b) => b.probability - a.probability);
  const top = sorted[0];
  const runnerUp = sorted[1];

  // Softmax confidence can be overconfident, calibrate with quality score
  const calibratedConfidence = Math.min(98, Math.round(top.probability * 100 * (0.8 + (qualityScore / 500))));

  // Uncertainty criteria:
  // 1. Top probability under 48%
  // 2. Margin between top 2 is under 8%
  const isAmbiguous = top.probability < 0.48 || (runnerUp && (top.probability - runnerUp.probability) < 0.08);

  const isMalignantOrUrgent = top.category === 'Malignant' || top.severityLevel === 'urgent';

  let urgency: 'low' | 'moderate' | 'high' | 'urgent' = 'low';
  if (top.severityLevel === 'urgent') {
    urgency = 'urgent';
  } else if (isMalignantOrUrgent) {
    urgency = top.probability > 0.60 ? 'urgent' : 'high';
  } else if (top.category === 'Pre-Malignant' || top.severityLevel === 'high') {
    urgency = 'high';
  } else if (top.severityLevel === 'moderate' || isAmbiguous) {
    urgency = 'moderate';
  }

  let recommendedAction = 'Routine self-monitoring and annual skin wellness examination.';
  if (urgency === 'urgent') {
    recommendedAction = 'Prompt evaluation by a board-certified dermatologist within 1-2 weeks is strongly advised.';
  } else if (urgency === 'high') {
    recommendedAction = 'Schedule a consultation with a dermatologist for dermoscopic evaluation.';
  } else if (urgency === 'moderate') {
    recommendedAction = 'Consult a general physician or dermatologist if lesion changes size, shape, or color.';
  }

  if (isAmbiguous) {
    return {
      status: 'uncertain',
      primaryCondition: top,
      topDifferentials: sorted.slice(0, 3),
      calibratedConfidence,
      uncertaintyFlag: true,
      uncertaintyMessage: 'Unable to provide a reliable preliminary classification for this image. Several differential classifications have overlapping features. Please consult a qualified healthcare professional.',
      clinicalUrgency: urgency,
      recommendedAction,
    };
  }

  return {
    status: 'conclusive',
    primaryCondition: top,
    topDifferentials: sorted.slice(0, 3),
    calibratedConfidence,
    uncertaintyFlag: false,
    clinicalUrgency: urgency,
    recommendedAction,
  };
}

/**
 * Calculates standard ABCDE dermoscopy risk score:
 * A - Asymmetry
 * B - Border irregularity
 * C - Color variegation (number of distinct hues)
 * D - Diameter (> 6mm = pencil eraser size)
 * E - Evolution / elevated
 */
export function calculateAbcdeRisk(criteria: {
  isAsymmetric: boolean;
  hasIrregularBorder: boolean;
  colorCount: number;
  diameterMm: number;
  isEvolving: boolean;
}): { totalScore: number; riskRating: 'Low' | 'Moderate' | 'High'; flaggedItems: string[] } {
  let score = 0;
  const flaggedItems: string[] = [];

  if (criteria.isAsymmetric) {
    score += 2;
    flaggedItems.push('Asymmetry (A): One half does not match the other half.');
  }
  if (criteria.hasIrregularBorder) {
    score += 2;
    flaggedItems.push('Border (B): Edges are scalloped, ragged, or poorly defined.');
  }
  if (criteria.colorCount >= 3) {
    score += 2;
    flaggedItems.push(`Color (C): Contains multiple shades (${criteria.colorCount} hues detected).`);
  }
  if (criteria.diameterMm >= 6) {
    score += 1.5;
    flaggedItems.push(`Diameter (D): Measured ${criteria.diameterMm}mm (≥ 6mm guideline).`);
  }
  if (criteria.isEvolving) {
    score += 2.5;
    flaggedItems.push('Evolving (E): Changes reported in size, shape, elevation, or symptoms.');
  }

  let riskRating: 'Low' | 'Moderate' | 'High' = 'Low';
  if (score >= 4.5) {
    riskRating = 'High';
  } else if (score >= 2) {
    riskRating = 'Moderate';
  }

  return {
    totalScore: score,
    riskRating,
    flaggedItems,
  };
}
