import test from 'node:test';
import assert from 'node:assert/strict';
import {
  evaluatePasswordStrength,
  validateEmail,
  checkRateLimit,
  enforceRLS,
} from './authRules.ts';

test('validateEmail checks standard email patterns', () => {
  assert.equal(validateEmail('patient@example.com'), true);
  assert.equal(validateEmail('dr.lin@mediskin.health'), true);
  assert.equal(validateEmail('invalid-email'), false);
  assert.equal(validateEmail('user@domain'), false);
  assert.equal(validateEmail(''), false);
});

test('evaluatePasswordStrength rates complexity properly', () => {
  const weak = evaluatePasswordStrength('short');
  assert.equal(weak.level, 'Weak');
  assert.equal(weak.hasMinLength, false);

  const strong = evaluatePasswordStrength('SecureP@ssw0rd2026!');
  assert.equal(strong.level, 'Strong');
  assert.equal(strong.hasMinLength, true);
  assert.equal(strong.hasUpper, true);
  assert.equal(strong.hasLower, true);
  assert.equal(strong.hasNumber, true);
  assert.equal(strong.hasSpecial, true);
});

test('checkRateLimit triggers lockout after 4 failed attempts within window', () => {
  const now = 100000;
  // 3 attempts: not locked
  const attempt3 = checkRateLimit(3, now - 5000, now);
  assert.equal(attempt3.isLocked, false);

  // 4 attempts 10 seconds ago: locked with ~50s remaining
  const attempt4 = checkRateLimit(4, now - 10000, now);
  assert.equal(attempt4.isLocked, true);
  assert.equal(attempt4.remainingSeconds, 50);

  // 4 attempts 65 seconds ago: lockout expired
  const expiredLockout = checkRateLimit(4, now - 65000, now);
  assert.equal(expiredLockout.isLocked, false);
});

test('enforceRLS blocks cross-patient access while granting own-resource and admin access', () => {
  const patientA = { id: 'patient-1', role: 'patient' as const };
  const patientBId = 'patient-2';
  const admin = { id: 'admin-1', role: 'admin' as const };

  // Patient A accessing own record -> allowed
  assert.equal(enforceRLS(patientA, 'patient-1', 'SELECT').allowed, true);

  // Patient A attempting to access Patient B's private screening -> blocked!
  const crossAccess = enforceRLS(patientA, patientBId, 'SELECT');
  assert.equal(crossAccess.allowed, false);
  assert.match(crossAccess.reason || '', /RLS Access Denied/);

  // Admin accessing any resource -> allowed
  assert.equal(enforceRLS(admin, patientBId, 'SELECT').allowed, true);
});
