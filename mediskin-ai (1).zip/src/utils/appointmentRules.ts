/**
 * MediSkin AI - Appointment Rules and Validation Engine
 * Decoupled business logic for schedule integrity, conflict prevention,
 * and role-based status state machine.
 */

export type AppointmentStatus = 'Pending' | 'Confirmed' | 'Rejected' | 'Cancelled' | 'Completed';
export type UserRole = 'patient' | 'doctor' | 'admin';
export type ConsultationMode = 'In-Person' | 'Video Call' | 'Audio Consultation';

export interface AppointmentRecord {
  id: string;
  referenceCode: string;
  patientId: string;
  patientName: string;
  patientEmail: string;
  patientPhone: string;
  doctorId: string;
  doctorName: string;
  specialty: string;
  clinicId?: string;
  clinicName?: string;
  date: string; // YYYY-MM-DD
  timeSlot: string; // e.g. "09:00 AM"
  mode: ConsultationMode;
  reason: string;
  status: AppointmentStatus;
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface DoctorSchedule {
  doctorId: string;
  availableDays: number[]; // 0=Sunday, 1=Monday ... 6=Saturday
  slots: string[]; // ["09:00 AM", "09:30 AM", ...]
  vacationDates?: string[]; // ["2026-11-01"]
}

export interface BookingValidationResult {
  isValid: boolean;
  error?: string;
}

/**
 * Validates if an appointment request satisfies all scheduling rules:
 * - Date must not be in the past
 * - Date must be on a working day for the doctor
 * - Doctor must not be on vacation
 * - Time slot must be within doctor's standard schedule
 * - Time slot must not already be booked (Confirmed or Pending)
 */
export function validateBookingRequest(
  request: {
    doctorId: string;
    date: string;
    timeSlot: string;
    patientEmail?: string;
  },
  existingAppointments: AppointmentRecord[],
  schedule: DoctorSchedule,
  currentDateIso: string = '2026-10-20'
): BookingValidationResult {
  if (!request.doctorId || !request.date || !request.timeSlot) {
    return { isValid: false, error: 'Doctor, appointment date, and time slot are required.' };
  }

  // 1. Past date check
  if (request.date < currentDateIso) {
    return { isValid: false, error: 'Cannot book appointments for past dates.' };
  }

  // 2. Doctor working day check
  const [year, month, day] = request.date.split('-').map(Number);
  const targetDateObj = new Date(Date.UTC(year, month - 1, day, 12, 0, 0));
  const dayOfWeek = targetDateObj.getUTCDay();

  if (!schedule.availableDays.includes(dayOfWeek)) {
    return { isValid: false, error: 'The selected doctor does not offer consultations on this day of the week.' };
  }

  // 3. Vacation / Leave check
  if (schedule.vacationDates && schedule.vacationDates.includes(request.date)) {
    return { isValid: false, error: 'The specialist is on scheduled medical leave on this date.' };
  }

  // 4. Valid slot check
  if (!schedule.slots.includes(request.timeSlot)) {
    return { isValid: false, error: `Invalid time slot: ${request.timeSlot}. Please choose a valid slot.` };
  }

  // 5. Duplicate slot booking conflict
  const isConflict = existingAppointments.some(
    (app) =>
      app.doctorId === request.doctorId &&
      app.date === request.date &&
      app.timeSlot === request.timeSlot &&
      (app.status === 'Confirmed' || app.status === 'Pending')
  );

  if (isConflict) {
    return { isValid: false, error: 'This appointment slot has already been reserved. Please select another time.' };
  }

  return { isValid: true };
}

/**
 * Filter out already reserved slots to return only open slots for a specific doctor & date.
 */
export function getAvailableSlotsForDate(
  doctorId: string,
  date: string,
  doctorSlots: string[],
  existingAppointments: AppointmentRecord[]
): string[] {
  const bookedSet = new Set(
    existingAppointments
      .filter(
        (app) =>
          app.doctorId === doctorId &&
          app.date === date &&
          (app.status === 'Confirmed' || app.status === 'Pending')
      )
      .map((app) => app.timeSlot)
  );

  return doctorSlots.filter((slot) => !bookedSet.has(slot));
}

/**
 * Enforces allowed status transitions based on actor role.
 * Security & workflow state machine rules:
 * - Patient: can cancel their own 'Pending' or 'Confirmed' appointments. Cannot mark 'Completed'.
 * - Doctor: can 'Confirm' or 'Reject' Pending appointments. Can mark 'Completed' or 'Cancelled'.
 * - Admin: can override or transition any non-terminal state.
 * - 'Completed' and 'Cancelled' are terminal states.
 */
export function canTransitionAppointmentStatus(
  currentStatus: AppointmentStatus,
  targetStatus: AppointmentStatus,
  actorRole: UserRole
): boolean {
  if (currentStatus === targetStatus) return false;

  // Terminal states cannot be changed once completed
  if (currentStatus === 'Completed') return false;
  if (currentStatus === 'Cancelled') return false;
  if (currentStatus === 'Rejected' && targetStatus === 'Completed') return false;

  if (actorRole === 'patient') {
    // Patients can only cancel their upcoming appointments
    return (
      (currentStatus === 'Pending' || currentStatus === 'Confirmed') &&
      targetStatus === 'Cancelled'
    );
  }

  if (actorRole === 'doctor') {
    if (currentStatus === 'Pending') {
      return targetStatus === 'Confirmed' || targetStatus === 'Rejected' || targetStatus === 'Cancelled';
    }
    if (currentStatus === 'Confirmed') {
      return targetStatus === 'Completed' || targetStatus === 'Cancelled';
    }
    return false;
  }

  if (actorRole === 'admin') {
    return true;
  }

  return false;
}

/**
 * Generates an auditable, human-readable appointment reference code.
 * Example: MSK-2026-7842
 */
export function generateBookingReference(seed: number = Date.now()): string {
  const suffix = Math.floor(1000 + (seed % 9000));
  return `MSK-2026-${suffix}`;
}
