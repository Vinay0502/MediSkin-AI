import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import crypto from 'node:crypto';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { serverDb } from './src/server/db.ts';

dotenv.config();

const app = express();
const PORT = parseInt(process.env.PORT || '3000', 10);
const isProd = process.env.NODE_ENV === 'production';

// Body parsers - allow generous limit for base64 dermoscopy scans
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Security Headers Middleware
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

// Audit logger helper
function logAuditEvent(actorEmail: string, actorRole: string, action: string, details: string, actorId?: string) {
  try {
    const id = `audit-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
    serverDb.db.prepare(`
      INSERT INTO audit_logs (id, timestamp, actor_id, actor_email, actor_role, action, details)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(id, new Date().toISOString(), actorId || null, actorEmail, actorRole, action, details);
  } catch (err) {
    console.error('Failed to log audit event:', err);
  }
}

// Authentication token verification middleware
interface AuthRequest extends Request {
  user?: {
    id: string;
    email: string;
    role: string;
    name: string;
    phone?: string;
    avatar_url?: string;
    is_email_verified: boolean;
    created_at: string;
  };
}

function authenticateToken(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Authentication required. No session token provided.' });
  }

  try {
    const session = serverDb.db.prepare(`
      SELECT s.token, s.expires_at, u.id, u.email, u.role, u.name, u.phone, u.avatar_url, u.is_email_verified, u.created_at
      FROM sessions s
      JOIN users u ON s.user_id = u.id
      WHERE s.token = ?
    `).get(token) as any;

    if (!session) {
      return res.status(401).json({ error: 'Invalid or expired session. Please log in again.' });
    }

    if (Date.now() > session.expires_at) {
      serverDb.db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
      return res.status(401).json({ error: 'Session expired. Please log in again.' });
    }

    req.user = {
      id: session.id,
      email: session.email,
      role: session.role,
      name: session.name,
      phone: session.phone,
      avatar_url: session.avatar_url,
      is_email_verified: Boolean(session.is_email_verified),
      created_at: session.created_at,
    };
    next();
  } catch (err: any) {
    return res.status(500).json({ error: 'Authentication check failed: ' + err.message });
  }
}

// Optional Auth (populates req.user if token valid, continues if not)
function optionalAuth(req: AuthRequest, _res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (token) {
    try {
      const session = serverDb.db.prepare(`
        SELECT s.token, s.expires_at, u.id, u.email, u.role, u.name, u.phone, u.avatar_url, u.is_email_verified, u.created_at
        FROM sessions s
        JOIN users u ON s.user_id = u.id
        WHERE s.token = ?
      `).get(token) as any;

      if (session && Date.now() <= session.expires_at) {
        req.user = {
          id: session.id,
          email: session.email,
          role: session.role,
          name: session.name,
          phone: session.phone,
          avatar_url: session.avatar_url,
          is_email_verified: Boolean(session.is_email_verified),
          created_at: session.created_at,
        };
      }
    } catch {
      // Ignore
    }
  }
  next();
}

// -------------------------------------------------------------
// API ROUTES
// -------------------------------------------------------------

// 1. Health & Status
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'MediSkin AI Production API',
    database: 'SQLite (ACID / WAL)',
  });
});

// 2. Authentication: Register
app.post('/api/auth/register', (req, res) => {
  const { name, email, password, phone, role } = req.body;

  if (!email || !password || !name) {
    return res.status(400).json({ error: 'Name, email, and password are required.' });
  }

  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ error: 'Invalid email address format.' });
  }

  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
  }

  const normalizedEmail = email.trim().toLowerCase();
  const existingUser = serverDb.db.prepare('SELECT id FROM users WHERE email = ?').get(normalizedEmail);
  if (existingUser) {
    return res.status(409).json({ error: 'An account with this email address already exists.' });
  }

  try {
    const userId = `usr-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
    const { salt, hash } = serverDb.hashPassword(password);
    const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
    const userRole = role === 'doctor' || role === 'admin' ? role : 'patient';
    const now = new Date().toISOString();

    serverDb.db.prepare(`
      INSERT INTO users (id, name, email, password_hash, password_salt, role, phone, avatar_url, is_email_verified, verification_code, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?, ?)
    `).run(
      userId,
      name.trim(),
      normalizedEmail,
      hash,
      salt,
      userRole,
      phone || null,
      `https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200`,
      verificationCode,
      now
    );

    // Create session
    const token = crypto.randomBytes(32).toString('hex');
    const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000; // 30 days
    serverDb.db.prepare(`
      INSERT INTO sessions (token, user_id, expires_at, created_at)
      VALUES (?, ?, ?, ?)
    `).run(token, userId, expiresAt, now);

    logAuditEvent(normalizedEmail, userRole, 'USER_REGISTERED', `New ${userRole} account created: ${name}`, userId);

    return res.status(201).json({
      success: true,
      token,
      verificationCodeDemo: verificationCode,
      user: {
        id: userId,
        name: name.trim(),
        email: normalizedEmail,
        role: userRole,
        phone: phone || '',
        avatarUrl: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200`,
        isEmailVerified: false,
        createdAt: now,
      },
    });
  } catch (err: any) {
    return res.status(500).json({ error: 'Failed to create user account: ' + err.message });
  }
});

// 3. Authentication: Login with Rate Limiting
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const normalizedEmail = email.trim().toLowerCase();

  // Rate Limiting Check: max 5 failed attempts per email / IP
  const rateLimitKey = `login:${normalizedEmail}`;
  const rateLimit = serverDb.db.prepare('SELECT * FROM rate_limits WHERE identifier = ?').get(rateLimitKey) as any;
  const now = Date.now();

  if (rateLimit && rateLimit.locked_until > now) {
    const remainingSeconds = Math.ceil((rateLimit.locked_until - now) / 1000);
    return res.status(429).json({
      error: `Too many failed login attempts. Account temporarily locked for ${remainingSeconds} seconds.`,
      remainingSeconds,
    });
  }

  const user = serverDb.db.prepare('SELECT * FROM users WHERE email = ?').get(normalizedEmail) as any;
  if (!user) {
    // Record failed attempt
    const failedAttempts = (rateLimit?.failed_attempts || 0) + 1;
    const lockedUntil = failedAttempts >= 5 ? now + 60000 : 0;
    serverDb.db.prepare(`
      INSERT INTO rate_limits (identifier, failed_attempts, last_attempt_at, locked_until)
      VALUES (?, ?, ?, ?)
      ON CONFLICT(identifier) DO UPDATE SET
        failed_attempts = excluded.failed_attempts,
        last_attempt_at = excluded.last_attempt_at,
        locked_until = excluded.locked_until
    `).run(rateLimitKey, failedAttempts, now, lockedUntil);

    logAuditEvent(normalizedEmail, 'unknown', 'LOGIN_FAILED', 'User not found');
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  // Verify password
  const isValid = serverDb.verifyPassword(password, user.password_salt, user.password_hash);
  if (!isValid) {
    const failedAttempts = (rateLimit?.failed_attempts || 0) + 1;
    const lockedUntil = failedAttempts >= 5 ? now + 60000 : 0;
    serverDb.db.prepare(`
      INSERT INTO rate_limits (identifier, failed_attempts, last_attempt_at, locked_until)
      VALUES (?, ?, ?, ?)
      ON CONFLICT(identifier) DO UPDATE SET
        failed_attempts = excluded.failed_attempts,
        last_attempt_at = excluded.last_attempt_at,
        locked_until = excluded.locked_until
    `).run(rateLimitKey, failedAttempts, now, lockedUntil);

    logAuditEvent(normalizedEmail, user.role, 'LOGIN_FAILED', 'Incorrect password', user.id);
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  // Login succeeded: reset rate limit
  serverDb.db.prepare('DELETE FROM rate_limits WHERE identifier = ?').run(rateLimitKey);

  // Generate session token
  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = now + 30 * 24 * 60 * 60 * 1000;
  serverDb.db.prepare(`
    INSERT INTO sessions (token, user_id, expires_at, created_at)
    VALUES (?, ?, ?, ?)
  `).run(token, user.id, expiresAt, new Date().toISOString());

  logAuditEvent(user.email, user.role, 'LOGIN_SUCCESS', 'Successful authentication', user.id);

  return res.json({
    success: true,
    token,
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      role: user.role,
      phone: user.phone || '',
      avatarUrl: user.avatar_url || '',
      isEmailVerified: Boolean(user.is_email_verified),
      createdAt: user.created_at,
    },
  });
});

// 4. Authentication: Logout
app.post('/api/auth/logout', authenticateToken, (req: AuthRequest, res) => {
  const token = req.headers['authorization']?.split(' ')[1];
  if (token) {
    serverDb.db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
  }
  if (req.user) {
    logAuditEvent(req.user.email, req.user.role, 'LOGOUT', 'User signed out', req.user.id);
  }
  res.json({ success: true, message: 'Logged out successfully.' });
});

// 5. Authentication: Current User (/api/auth/me)
app.get('/api/auth/me', authenticateToken, (req: AuthRequest, res) => {
  res.json({ success: true, user: req.user });
});

// 6. Authentication: Verify Email
app.post('/api/auth/verify-email', authenticateToken, (req: AuthRequest, res) => {
  const { code } = req.body;
  if (!code) {
    return res.status(400).json({ error: 'Verification code is required.' });
  }

  const user = serverDb.db.prepare('SELECT verification_code FROM users WHERE id = ?').get(req.user!.id) as any;
  if (user && user.verification_code === code.trim()) {
    serverDb.db.prepare('UPDATE users SET is_email_verified = 1 WHERE id = ?').run(req.user!.id);
    logAuditEvent(req.user!.email, req.user!.role, 'EMAIL_VERIFIED', 'Email verified successfully', req.user!.id);
    return res.json({ success: true, message: 'Email address verified successfully.' });
  }

  return res.status(400).json({ error: 'Invalid verification code. Please check and try again.' });
});

// 7. Authentication: Request Password Reset
app.post('/api/auth/request-reset', (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Email address is required.' });
  }

  const normalizedEmail = email.trim().toLowerCase();
  const user = serverDb.db.prepare('SELECT id, name FROM users WHERE email = ?').get(normalizedEmail) as any;

  if (!user) {
    // Return success to avoid email enumeration
    return res.json({
      success: true,
      message: 'If an account exists with this email, a reset code has been sent.',
    });
  }

  const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
  const resetExpiresAt = Date.now() + 15 * 60 * 1000; // 15 minutes

  serverDb.db.prepare('UPDATE users SET reset_code = ?, reset_expires_at = ? WHERE id = ?').run(
    resetCode,
    resetExpiresAt,
    user.id
  );

  logAuditEvent(normalizedEmail, 'patient', 'PASSWORD_RESET_REQUESTED', 'Password reset code generated', user.id);

  return res.json({
    success: true,
    message: 'Reset code sent to your email address.',
    resetCodeDemo: resetCode, // Useful for immediate testing in AI Studio
  });
});

// 8. Authentication: Complete Password Reset
app.post('/api/auth/reset-password', (req, res) => {
  const { email, code, newPassword } = req.body;
  if (!email || !code || !newPassword) {
    return res.status(400).json({ error: 'Email, code, and new password are required.' });
  }

  if (newPassword.length < 8) {
    return res.status(400).json({ error: 'New password must be at least 8 characters long.' });
  }

  const normalizedEmail = email.trim().toLowerCase();
  const user = serverDb.db.prepare('SELECT * FROM users WHERE email = ?').get(normalizedEmail) as any;

  if (!user || user.reset_code !== code.trim()) {
    return res.status(400).json({ error: 'Invalid or expired password reset code.' });
  }

  if (Date.now() > user.reset_expires_at) {
    return res.status(400).json({ error: 'Reset code has expired. Please request a new code.' });
  }

  const { salt, hash } = serverDb.hashPassword(newPassword);
  serverDb.db.prepare('UPDATE users SET password_hash = ?, password_salt = ?, reset_code = NULL, reset_expires_at = NULL WHERE id = ?').run(
    hash,
    salt,
    user.id
  );

  // Invalidate all existing sessions for this user
  serverDb.db.prepare('DELETE FROM sessions WHERE user_id = ?').run(user.id);

  logAuditEvent(normalizedEmail, user.role, 'PASSWORD_RESET_COMPLETED', 'Password changed via verification code', user.id);

  return res.json({ success: true, message: 'Password has been successfully updated. You may now log in.' });
});

// 9. Authentication: Permanent Account Deletion (HIPAA / GDPR Right to Erasure)
app.delete('/api/auth/account', authenticateToken, (req: AuthRequest, res) => {
  const { password } = req.body;
  if (!password) {
    return res.status(400).json({ error: 'Account password required to confirm deletion.' });
  }

  const user = serverDb.db.prepare('SELECT * FROM users WHERE id = ?').get(req.user!.id) as any;
  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  const isValid = serverDb.verifyPassword(password, user.password_salt, user.password_hash);
  if (!isValid) {
    return res.status(401).json({ error: 'Incorrect password. Account deletion aborted.' });
  }

  // Delete all appointments, screenings, sessions, and user record
  serverDb.db.prepare('DELETE FROM appointments WHERE patient_id = ?').run(user.id);
  serverDb.db.prepare('DELETE FROM screenings WHERE user_id = ?').run(user.id);
  serverDb.db.prepare('DELETE FROM sessions WHERE user_id = ?').run(user.id);
  serverDb.db.prepare('DELETE FROM users WHERE id = ?').run(user.id);

  logAuditEvent(user.email, user.role, 'ACCOUNT_PURGED', 'User account and clinical data permanently deleted');

  return res.json({ success: true, message: 'Your account and all associated health records have been permanently purged.' });
});

// 10. Doctors Directory
app.get('/api/doctors', (_req, res) => {
  try {
    const rows = serverDb.db.prepare('SELECT * FROM doctors ORDER BY rating DESC').all() as any[];
    const doctors = rows.map((d) => ({
      id: d.id,
      name: d.name,
      title: d.title,
      specialty: d.specialty,
      subSpecialties: JSON.parse(d.sub_specialties || '[]'),
      licenseNumber: d.license_number,
      experienceYears: d.experience_years,
      hospitalAffiliation: d.hospital_affiliation,
      clinicAddress: d.clinic_address,
      city: d.city,
      state: d.state,
      consultationFee: d.consultation_fee,
      rating: d.rating,
      reviewCount: d.review_count,
      modes: JSON.parse(d.modes || '[]'),
      verificationStatus: d.verification_status,
      availableDays: JSON.parse(d.available_days || '[]'),
      timeSlots: JSON.parse(d.time_slots || '[]'),
      bio: d.bio,
      education: d.education,
      avatarUrl: d.avatar_url,
    }));
    res.json({ success: true, doctors });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch doctors: ' + err.message });
  }
});

app.get('/api/doctors/:id', (req, res) => {
  try {
    const d = serverDb.db.prepare('SELECT * FROM doctors WHERE id = ?').get(req.params.id) as any;
    if (!d) return res.status(404).json({ error: 'Doctor not found.' });
    res.json({
      success: true,
      doctor: {
        id: d.id,
        name: d.name,
        title: d.title,
        specialty: d.specialty,
        subSpecialties: JSON.parse(d.sub_specialties || '[]'),
        licenseNumber: d.license_number,
        experienceYears: d.experience_years,
        hospitalAffiliation: d.hospital_affiliation,
        clinicAddress: d.clinic_address,
        city: d.city,
        state: d.state,
        consultationFee: d.consultation_fee,
        rating: d.rating,
        reviewCount: d.review_count,
        modes: JSON.parse(d.modes || '[]'),
        verificationStatus: d.verification_status,
        availableDays: JSON.parse(d.available_days || '[]'),
        timeSlots: JSON.parse(d.time_slots || '[]'),
        bio: d.bio,
        education: d.education,
        avatarUrl: d.avatar_url,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch doctor: ' + err.message });
  }
});

// Update doctor verification (Admin)
app.patch('/api/admin/doctors/:id/status', authenticateToken, (req: AuthRequest, res) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: 'Forbidden. Admin credentials required.' });
  }

  const { status } = req.body;
  if (!['Verified', 'Pending Review', 'Needs More Info', 'Rejected'].includes(status)) {
    return res.status(400).json({ error: 'Invalid verification status.' });
  }

  serverDb.db.prepare('UPDATE doctors SET verification_status = ? WHERE id = ?').run(status, req.params.id);
  logAuditEvent(req.user.email, 'admin', 'DOCTOR_VERIFICATION_UPDATED', `Doctor ${req.params.id} updated to ${status}`, req.user.id);

  res.json({ success: true, message: `Doctor status updated to ${status}.` });
});

// Update doctor schedule (Doctor)
app.put('/api/doctors/:id/schedule', authenticateToken, (req: AuthRequest, res) => {
  const { availableDays, timeSlots } = req.body;
  if (!Array.isArray(availableDays) || !Array.isArray(timeSlots)) {
    return res.status(400).json({ error: 'Invalid schedule parameters.' });
  }

  serverDb.db.prepare('UPDATE doctors SET available_days = ?, time_slots = ? WHERE id = ?').run(
    JSON.stringify(availableDays),
    JSON.stringify(timeSlots),
    req.params.id
  );

  logAuditEvent(req.user!.email, req.user!.role, 'DOCTOR_SCHEDULE_UPDATED', `Schedule updated for doctor ${req.params.id}`, req.user!.id);
  res.json({ success: true, message: 'Schedule updated successfully.' });
});

// 11. Hospitals Directory
app.get('/api/hospitals', (_req, res) => {
  try {
    const rows = serverDb.db.prepare('SELECT * FROM hospitals ORDER BY rating DESC').all() as any[];
    const hospitals = rows.map((h) => ({
      id: h.id,
      name: h.name,
      facilityType: h.facility_type,
      address: h.address,
      city: h.city,
      state: h.state,
      phone: h.phone,
      emergencyCare: Boolean(h.emergency_care),
      dermatologyDepartment: Boolean(h.dermatology_department),
      rating: h.rating,
      lat: h.lat,
      lng: h.lng,
      operatingHours: h.operating_hours,
      acceptedInsurances: JSON.parse(h.accepted_insurances || '[]'),
    }));
    res.json({ success: true, hospitals });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch facilities: ' + err.message });
  }
});

app.post('/api/hospitals', authenticateToken, (req: AuthRequest, res) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: 'Only administrators can register facilities.' });
  }

  const { name, facilityType, address, city, state, phone, operatingHours } = req.body;
  if (!name || !city || !address) {
    return res.status(400).json({ error: 'Name, address, and city are required.' });
  }

  const id = `hosp-${Date.now()}`;
  serverDb.db.prepare(`
    INSERT INTO hospitals (id, name, facility_type, address, city, state, phone, operating_hours, accepted_insurances, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    name,
    facilityType || 'Specialized Dermatology Center',
    address,
    city,
    state || 'CA',
    phone || '(415) 555-0100',
    operatingHours || 'Mon - Fri: 8:00 AM - 5:00 PM',
    JSON.stringify(['Medicare', 'Blue Shield', 'Aetna']),
    new Date().toISOString()
  );

  logAuditEvent(req.user.email, 'admin', 'FACILITY_CREATED', `Registered facility: ${name}`, req.user.id);
  res.status(201).json({ success: true, message: 'Facility registered successfully.' });
});

// 12. Appointments (Row-Level Security Enforced)
app.get('/api/appointments', optionalAuth, (req: AuthRequest, res) => {
  try {
    if (!req.user || req.user.id === 'guest') {
      return res.json({ success: true, appointments: [] });
    }

    let rows: any[] = [];
    if (req.user.role === 'admin') {
      rows = serverDb.db.prepare('SELECT * FROM appointments ORDER BY date DESC, time_slot ASC').all() as any[];
    } else if (req.user.role === 'doctor') {
      rows = serverDb.db.prepare('SELECT * FROM appointments WHERE doctor_id = ? ORDER BY date ASC, time_slot ASC').all(req.user.id) as any[];
    } else {
      // Patient sees only their appointments
      rows = serverDb.db.prepare('SELECT * FROM appointments WHERE patient_id = ? ORDER BY date DESC, time_slot ASC').all(req.user.id) as any[];
    }

    const appointments = rows.map((a) => ({
      id: a.id,
      referenceCode: a.reference_code,
      patientId: a.patient_id,
      patientName: a.patient_name,
      patientEmail: a.patient_email,
      patientPhone: a.patient_phone,
      doctorId: a.doctor_id,
      doctorName: a.doctor_name,
      specialty: a.specialty,
      date: a.date,
      timeSlot: a.time_slot,
      mode: a.mode,
      reason: a.reason,
      status: a.status,
      triagePriority: a.triage_priority,
      consultationFee: a.consultation_fee,
      screeningId: a.screening_id,
      doctorNotes: a.doctor_notes,
      cancellationReason: a.cancellation_reason,
      createdAt: a.created_at,
    }));

    res.json({ success: true, appointments });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to retrieve appointments: ' + err.message });
  }
});

// Book an appointment (supports authenticated users and guest consultations)
app.post('/api/appointments', optionalAuth, (req: AuthRequest, res) => {
  const { doctorId, date, timeSlot, mode, reason, screeningId, patientName, patientEmail, patientPhone } = req.body;

  if (!doctorId || !date || !timeSlot) {
    return res.status(400).json({ error: 'Doctor, date, and time slot are required.' });
  }

  // Check doctor existence
  const doctor = serverDb.db.prepare('SELECT * FROM doctors WHERE id = ?').get(doctorId) as any;
  if (!doctor) {
    return res.status(404).json({ error: 'Selected doctor not found in directory.' });
  }

  // Conflict check: is slot already taken?
  const existing = serverDb.db.prepare(`
    SELECT id FROM appointments
    WHERE doctor_id = ? AND date = ? AND time_slot = ? AND status != 'Cancelled'
  `).get(doctorId, date, timeSlot);

  if (existing) {
    return res.status(409).json({ error: 'This appointment slot has already been booked. Please choose another time.' });
  }

  // Generate Reference Code: MED-YYYYMMDD-XXXX
  const dateCompact = date.replace(/-/g, '');
  const randSuffix = crypto.randomBytes(2).toString('hex').toUpperCase();
  const referenceCode = `MED-${dateCompact}-${randSuffix}`;
  const appointmentId = `app-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
  const now = new Date().toISOString();

  const patientId = req.user?.id || 'guest';
  const finalEmail = req.user?.email || patientEmail || 'guest@mediskin.health';
  const finalName = req.user?.name || patientName || 'Patient';

  serverDb.db.prepare(`
    INSERT INTO appointments (
      id, reference_code, patient_id, patient_name, patient_email, patient_phone,
      doctor_id, doctor_name, specialty, date, time_slot, mode, reason, status,
      triage_priority, consultation_fee, screening_id, created_at, updated_at
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Confirmed', 'Routine', ?, ?, ?, ?
    )
  `).run(
    appointmentId,
    referenceCode,
    patientId,
    finalName,
    finalEmail,
    patientPhone || req.user?.phone || '',
    doctor.id,
    doctor.name,
    doctor.specialty,
    date,
    timeSlot,
    mode || 'In-Person',
    reason || 'Routine dermatological consultation',
    doctor.consultation_fee || 160,
    screeningId || null,
    now,
    now
  );

  logAuditEvent(finalEmail, req.user?.role || 'patient', 'APPOINTMENT_BOOKED', `Booked ${referenceCode} with ${doctor.name} on ${date} at ${timeSlot}`, patientId);

  res.status(201).json({
    success: true,
    message: 'Consultation reserved successfully.',
    appointment: {
      id: appointmentId,
      referenceCode,
      doctorId: doctor.id,
      doctorName: doctor.name,
      specialty: doctor.specialty,
      date,
      timeSlot,
      mode: mode || 'In-Person',
      status: 'Confirmed',
      consultationFee: doctor.consultation_fee,
    },
  });
});

// Update appointment status (Cancel, Complete, etc.)
app.patch('/api/appointments/:id/status', authenticateToken, (req: AuthRequest, res) => {
  const { status, cancellationReason, doctorNotes } = req.body;
  const appointment = serverDb.db.prepare('SELECT * FROM appointments WHERE id = ?').get(req.params.id) as any;

  if (!appointment) {
    return res.status(404).json({ error: 'Appointment not found.' });
  }

  // Row-Level Security: Only the patient, the assigned doctor, or an admin can touch this appointment
  const isPatientOwner = req.user!.id === appointment.patient_id;
  const isAssignedDoctor = req.user!.id === appointment.doctor_id;
  const isAdmin = req.user!.role === 'admin';

  if (!isPatientOwner && !isAssignedDoctor && !isAdmin) {
    return res.status(403).json({ error: 'Forbidden. You do not have permission to modify this appointment.' });
  }

  if (isPatientOwner && status !== 'Cancelled') {
    return res.status(403).json({ error: 'Patients may only cancel consultations.' });
  }

  serverDb.db.prepare(`
    UPDATE appointments
    SET status = ?, cancellation_reason = COALESCE(?, cancellation_reason), doctor_notes = COALESCE(?, doctor_notes), updated_at = ?
    WHERE id = ?
  `).run(
    status,
    cancellationReason || null,
    doctorNotes || null,
    new Date().toISOString(),
    req.params.id
  );

  logAuditEvent(req.user!.email, req.user!.role, 'APPOINTMENT_STATUS_CHANGED', `Appointment ${appointment.reference_code} changed to ${status}`, req.user!.id);

  res.json({ success: true, message: `Appointment status updated to ${status}.` });
});

// 13. Screenings CRUD (RLS Enforced)
app.get('/api/screenings', optionalAuth, (req: AuthRequest, res) => {
  try {
    if (!req.user || req.user.id === 'guest') {
      return res.json({ success: true, screenings: [] });
    }

    let rows: any[] = [];
    if (req.user.role === 'admin') {
      rows = serverDb.db.prepare('SELECT * FROM screenings ORDER BY timestamp DESC').all() as any[];
    } else {
      rows = serverDb.db.prepare('SELECT * FROM screenings WHERE user_id = ? ORDER BY timestamp DESC').all(req.user.id) as any[];
    }

    const screenings = rows.map((s) => ({
      id: s.id,
      userId: s.user_id,
      imageUrl: s.image_url,
      qualityScore: s.quality_score,
      conditionId: s.condition_id,
      conditionName: s.condition_name,
      category: s.category,
      confidence: s.confidence,
      urgency: s.urgency,
      uncertaintyFlag: Boolean(s.uncertainty_flag),
      uncertaintyMessage: s.uncertainty_message,
      features: JSON.parse(s.features_json || '{}'),
      abcdeAnalysis: JSON.parse(s.abcde_json || '{}'),
      report: JSON.parse(s.report_json || '{}'),
      doctorNotes: s.doctor_notes,
      timestamp: s.timestamp,
    }));

    res.json({ success: true, screenings });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to fetch screenings: ' + err.message });
  }
});

app.post('/api/screenings', optionalAuth, (req: AuthRequest, res) => {
  const { report, imageUrl } = req.body;
  if (!report || !report.screeningResult) {
    return res.status(400).json({ error: 'Valid complete screening report is required.' });
  }

  const id = `scr-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
  const condition = report.screeningResult.primaryCondition || {};
  const now = report.timestamp || new Date().toISOString();
  const userId = req.user?.id || 'guest';
  const email = req.user?.email || 'guest@mediskin.health';
  const role = req.user?.role || 'patient';

  serverDb.db.prepare(`
    INSERT INTO screenings (
      id, user_id, image_url, quality_score, condition_id, condition_name,
      category, confidence, urgency, uncertainty_flag, uncertainty_message,
      features_json, abcde_json, report_json, timestamp
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )
  `).run(
    id,
    userId,
    imageUrl || null,
    report.qualityReport?.score || 85,
    condition.conditionId || 'unknown',
    condition.conditionName || 'Unspecified Lesion',
    condition.category || 'Screening Required',
    report.screeningResult.calibratedConfidence || 80,
    report.screeningResult.clinicalUrgency || 'routine',
    report.screeningResult.uncertaintyFlag ? 1 : 0,
    report.screeningResult.uncertaintyMessage || null,
    JSON.stringify(report.features || {}),
    JSON.stringify(report.abcdeAnalysis || {}),
    JSON.stringify(report),
    now
  );

  logAuditEvent(email, role, 'SCREENING_SAVED', `Saved screening for ${condition.conditionName}`, userId);

  res.status(201).json({ success: true, id, message: 'Screening evaluation saved to medical record.' });
});

app.delete('/api/screenings/:id', authenticateToken, (req: AuthRequest, res) => {
  const screening = serverDb.db.prepare('SELECT user_id FROM screenings WHERE id = ?').get(req.params.id) as any;
  if (!screening) {
    return res.status(404).json({ error: 'Screening record not found.' });
  }

  if (req.user!.role !== 'admin' && req.user!.id !== screening.user_id) {
    return res.status(403).json({ error: 'Forbidden. You cannot delete this record.' });
  }

  serverDb.db.prepare('DELETE FROM screenings WHERE id = ?').run(req.params.id);
  logAuditEvent(req.user!.email, req.user!.role, 'SCREENING_DELETED', `Deleted screening record ${req.params.id}`, req.user!.id);

  res.json({ success: true, message: 'Screening report deleted.' });
});

// 14. Feedbacks
app.post('/api/feedback', optionalAuth, (req: AuthRequest, res) => {
  const { rating, category, message, userName, userEmail } = req.body;
  if (!rating || !message) {
    return res.status(400).json({ error: 'Rating and message are required.' });
  }

  const id = `fb-${Date.now()}`;
  serverDb.db.prepare(`
    INSERT INTO feedbacks (id, user_id, user_name, user_email, rating, category, message, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    req.user?.id || null,
    req.user?.name || userName || 'Anonymous Patient',
    req.user?.email || userEmail || 'anonymous@patient.local',
    rating,
    category || 'General Experience',
    message,
    new Date().toISOString()
  );

  res.status(201).json({ success: true, message: 'Thank you for your clinical feedback!' });
});

// 15. Admin Stats & Audit Logs
app.get('/api/admin/stats', authenticateToken, (req: AuthRequest, res) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required.' });
  }

  const userCount = (serverDb.db.prepare('SELECT COUNT(*) as count FROM users').get() as any).count;
  const doctorCount = (serverDb.db.prepare('SELECT COUNT(*) as count FROM doctors').get() as any).count;
  const hospitalCount = (serverDb.db.prepare('SELECT COUNT(*) as count FROM hospitals').get() as any).count;
  const appointmentCount = (serverDb.db.prepare('SELECT COUNT(*) as count FROM appointments').get() as any).count;
  const screeningCount = (serverDb.db.prepare('SELECT COUNT(*) as count FROM screenings').get() as any).count;
  const pendingDoctors = (serverDb.db.prepare("SELECT COUNT(*) as count FROM doctors WHERE verification_status != 'Verified'").get() as any).count;

  res.json({
    success: true,
    stats: {
      users: userCount,
      doctors: doctorCount,
      hospitals: hospitalCount,
      appointments: appointmentCount,
      screenings: screeningCount,
      pendingVerifications: pendingDoctors,
    },
  });
});

app.get('/api/admin/audit-logs', authenticateToken, (req: AuthRequest, res) => {
  if (req.user?.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required.' });
  }

  const logs = serverDb.db.prepare('SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 200').all() as any[];
  res.json({
    success: true,
    logs: logs.map((l) => ({
      id: l.id,
      timestamp: l.timestamp,
      actorEmail: l.actor_email,
      actorRole: l.actor_role,
      action: l.action,
      details: l.details,
    })),
  });
});

// 16. Database Backup & Restore
app.get('/api/backup', authenticateToken, (req: AuthRequest, res) => {
  // Allow user to download their own records or admin to backup entire DB
  const isAdmin = req.user?.role === 'admin';

  let data: any = {};
  if (isAdmin) {
    data = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      type: 'full-system-backup',
      users: serverDb.db.prepare('SELECT id, name, email, role, phone, is_email_verified, created_at FROM users').all(),
      doctors: serverDb.db.prepare('SELECT * FROM doctors').all(),
      hospitals: serverDb.db.prepare('SELECT * FROM hospitals').all(),
      appointments: serverDb.db.prepare('SELECT * FROM appointments').all(),
      screenings: serverDb.db.prepare('SELECT * FROM screenings').all(),
      auditLogs: serverDb.db.prepare('SELECT * FROM audit_logs').all(),
    };
  } else {
    data = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      type: 'patient-health-records',
      user: req.user,
      appointments: serverDb.db.prepare('SELECT * FROM appointments WHERE patient_id = ?').all(req.user!.id),
      screenings: serverDb.db.prepare('SELECT * FROM screenings WHERE user_id = ?').all(req.user!.id),
    };
  }

  logAuditEvent(req.user!.email, req.user!.role, 'BACKUP_EXPORTED', `Exported ${data.type}`, req.user!.id);
  res.setHeader('Content-Type', 'application/json');
  res.setHeader('Content-Disposition', `attachment; filename=mediskin-backup-${Date.now()}.json`);
  res.json(data);
});

// -------------------------------------------------------------
// VITE / STATIC SERVING
// -------------------------------------------------------------
async function startServer() {
  if (!isProd) {
    // Development mode: Vite middleware
    // Explicitly set hmr: false to prevent WebSocket connection failures behind cloud proxy
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production mode: Serve dist folder
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[MediSkin AI] Full-stack Server listening on port ${PORT} (mode: ${isProd ? 'production' : 'development'})`);
  });
}

startServer().catch((err) => {
  console.error('[MediSkin AI] Fatal server startup error:', err);
  process.exit(1);
});
